# AGENTS.md — Guidance for AI Coding Agents

This file is the contract for AI agents (Cursor, Copilot, custom IDE agents,
CI bots) working in the **AR Voice Controller** repo. Humans should read
[`CONTRIBUTING.md`](./CONTRIBUTING.md) first; agents should read both, but
the invariants here are **non-negotiable**.

## Repo one-liner

Real-time voice dialog service for Akinrobotics humanoids. Current role:
mic → VAD/AEC → ASR → streaming LLM policy → TTS, with barge-in and an
internal event bus. Target role (see [`ROADMAP_v2.md`](./docs/roadmaps/ROADMAP_v2.md)):
**embodied agent orchestrator** that also drives perception-triggered
turns, skill calls, world-snapshot-aware prompts, and safety-bridged
cancellation.

## Read before editing

1. [`README.md`](./README.md) — install, run, configuration layering.
2. [`ROADMAP.md`](./docs/roadmaps/ROADMAP.md) — v1 priorities (MCP / async / HTTP service
   migration). Items are tiered T1-T3 and FI-1…FI-10.
3. [`ROADMAP_v2.md`](./docs/roadmaps/ROADMAP_v2.md) — v2 embodied integration, grouped in
   phases A–F. Cross-references v1 items as `[T1-N]`, `[FI-N]`, `[EI-N]`.
4. This file, for hard constraints.

When asked to implement a change, **locate it on the roadmap first** (e.g.
"this is T1-2 / A3"). If it is not there, surface the gap before coding —
do not invent new top-level subsystems unilaterally.

## Non-negotiable invariants

Violating any of these is a bug even if tests pass:

1. **Provider `Protocol` typing.** `providers/sr.py`, `providers/llm.py`,
   `providers/tts.py` expose `Protocol`-based contracts. New providers
   implement the `Protocol`; callers never import concrete classes. This
   is the single biggest reason the service can migrate (FI-1, FI-2, FI-4).
2. **Interrupts are topic-driven.** All cancel-initiating signals publish
   to `/interrupt/requested` with a priority and an `InterruptCause`. Do
   **not** call `token.cancel()` from arbitrary sites; go through
   `InterruptArbiter`. New sources → new `InterruptCause` enum entry.
3. **Event-bus fan-out over method calls.** New cross-cutting features
   (tool events, safety, world snapshots, skill events, presence) publish
   dataclass events on the bus. `ar-voice-monitor` auto-renders them.
4. **Cancellation propagates through `CancellationToken`.** Always use
   `token.child()` for sub-operations; call `token.raise_if_cancelled()`
   between streaming chunks; never swallow `CancelledError`.
5. **Voice-controller is not real-time.** No servo loops, no low-level
   motion control in this process. Skills are dispatched as
   `goal + cancel` against actions (EI-1 adapter). RT stays in
   `ros_control` / embedded.
6. **LLM context is structured.** World snapshots, tool manifests, and
   history are JSON attached to the request (headers / `meta` field), not
   prose glued into prompts.
7. **Wire format is JSON dataclass payloads**, not ROS message types —
   must survive the ROS1 → ROS2 migration unchanged.
8. **Python 3.11 only.** The `aec-audio-processing` wheel is CPython 3.11
   Linux x86_64. Do not bump `requires-python` without replacing that wheel.

## Codebase map

| Path | Purpose |
|---|---|
| `src/ar_voice_controller/audio/` | Capture, VAD, interrupt detection, AEC |
| `src/ar_voice_controller/core/` | `TurnManager`, policies, cancellation, types — **orchestration lives here** |
| `src/ar_voice_controller/providers/` | `Protocol`-typed ASR/LLM/TTS clients |
| `src/ar_voice_controller/runtime/` | Event bus, ROS backends, event types |
| `src/ar_voice_controller/telemetry/` | FIFO sink, `ar-voice-monitor` CLI |
| `src/ar_voice_controller/pipeline.py` | Single wiring point |
| `config.yaml` + `src/.../config/` | Layered YAML + `AVC_` env overrides |
| `asr-api/`, `tts-api/`, `service-robot-chatbot/` | Sibling services the controller is migrating onto (roadmap Phase B / FI-*) |
| `ui/`, `examples/`, `vendor/` | Web UI, demos, pinned wheels |

## Where to add what

- **New interrupt source** → extend `InterruptCause`, publish to
  `/interrupt/requested`, wire a bridge under `runtime/`. See
  `ExternalStopSource` and roadmap A2.
- **New telemetry event** → add a `@dataclass(slots=True)` in
  `runtime/event_types.py`, publish from the responsible module. No
  monitor changes needed.
- **New trigger type** (vision / scheduled / tool-return) → belongs under
  the `TurnTrigger` tagged union (roadmap C1). Do **not** overload
  `FinalTranscript`.
- **New provider backend** → implement the `Protocol` in
  `providers/<name>.py`, config in `config/<name>.py`, wire in
  `pipeline.py`. Keep the existing implementation available via config.
- **Skill / robot tool call** → goes through the `skill_adapter` surface
  (EI-1). Do not embed ROS actionlib calls in `core/policy.py`.
- **LLM prompt changes** → prompt text lives in `prompts/`; structured
  context (world snapshot, tools) goes as JSON headers / body fields.

## Tooling agents must use

- `uv sync --group dev` — install deps + dev hooks.
- `uv run ar-voice-controller` / `uv run ar-voice-monitor` — run.
- `uv run pre-commit run --all-files` — **must pass** before proposing a
  commit. Hooks: whitespace, EOF, YAML, large files, merge conflicts,
  debug statements, `ruff` (with `ANN401`), `ruff-format`, `complexipy`
  (max complexity 20, excluding `tests/`, `examples/`, `benchmark/`,
  `scripts/`).
- Type hints are required; avoid unannotated `Any`.

## Change workflow for agents

1. **Restate the task** and map it to a roadmap item.
2. **Read the affected files in full** (don't skim — state lives in enum
   dispatch and cancellation paths).
3. **Plan** before editing when the change spans ≥ 3 files or touches
   `core/` state machine, cancellation, or provider contracts.
4. **Edit** via the IDE's structured edit tools, not by rewriting files
   wholesale.
5. **Run linters** (`uv run pre-commit run --all-files`). Fix anything you
   introduced.
6. **Update `CHANGELOG.md`** under `[Unreleased]` for user-visible
   changes. Follow Keep-a-Changelog sections (Added/Changed/Fixed/…).
   On version bumps, promote `[Unreleased]` and refresh compare links.
7. **Write a Conventional Commit** (`type(scope): summary`). Suggested
   scopes: `audio`, `core`, `providers`, `runtime`, `telemetry`,
   `pipeline`, `config`, `ci`, `docs`.
8. **Summarize** for the human: what changed, which roadmap item, what to
   test manually, and any follow-ups you deferred.

## What NOT to do

- Do **not** create parallel state machines or shadow event buses.
- Do **not** add direct HTTP calls from `core/` — go through `providers/`.
- Do **not** add blocking calls on the main capture / playback threads.
- Do **not** persist history locally once Phase B / FI-6 is active — the
  LLM service owns it. Gate any local history behind a feature flag.
- Do **not** silently catch `CancelledError`. Propagate it.
- Do **not** introduce new Python versions, OSes, or architectures without
  also replacing the vendored AEC wheel.
- Do **not** commit secrets. `OPENAI_API_KEY` and similar live in `.env`.
- Do **not** push directly to `main`. Always use a merge request.

## Useful skills in this repo

`.cursor/skills/` ships skills that help with recurring tasks: commit
messages, PR descriptions, changelog writes, ADR creation, README /
env-setup refresh, refactor suggestions, security review, API docs, test
scaffolds. Prefer these over ad-hoc implementations when applicable.

## If in doubt

Open a clarifying question in the MR or chat rather than guessing. The
roadmap encodes load-bearing decisions; silent divergence creates drift
that is expensive to undo.
