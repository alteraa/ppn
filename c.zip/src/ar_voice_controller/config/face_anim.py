from __future__ import annotations

from pydantic import BaseModel


class FaceAnimCfg(BaseModel):
    enabled: bool = True
