from __future__ import annotations

from pydantic import BaseModel, Field

from .asr import AsrCfg
from .audio import AudioCfg, InterruptCfg, VadCfg
from .llm import LlmCfg
from .runtime import RuntimeCfg
from .tts import TtsCfg


class Settings(BaseModel):
    audio: AudioCfg = Field(default_factory=AudioCfg)
    vad: VadCfg = Field(default_factory=VadCfg)
    interrupt: InterruptCfg = Field(default_factory=InterruptCfg)
    asr: AsrCfg = Field(default_factory=AsrCfg)
    llm: LlmCfg = Field(default_factory=LlmCfg)
    tts: TtsCfg = Field(default_factory=TtsCfg)
    runtime: RuntimeCfg = Field(default_factory=RuntimeCfg)
