from __future__ import annotations

import queue
import signal
import sys
import time
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..audio.interrupt import AudioInterruptSource, InterruptArbiter
    from ..audio.io import AudioIO
    from ..audio.vad import VadDetector

from ..providers.sr import OpenAiAsrClient
from ..config import Settings
from ..runtime.event_types import (
    ServiceStateChanged,
    TurnStateChanged,
    UserSpeechDetected,
    UserSpeechEnded,
)
from ..runtime.events import EventBus
from .cancellation import CancellationToken, InterruptCause
from .capture import CaptureController, IdleDecision
from .types import DialogPolicy, TurnContext, TurnState
from .worker import AsrProcessingWorker


class TurnManager:
    def __init__(
        self,
        settings: Settings,
        audio_io: AudioIO,
        vad: VadDetector,
        asr_client: OpenAiAsrClient,
        policy: DialogPolicy,
        arbiter: InterruptArbiter,
        bus: EventBus,
        audio_interrupt: AudioInterruptSource,
    ) -> None:
        self.settings = settings
        self.audio_io = audio_io
        self.policy = policy
        self.arbiter = arbiter
        self.bus = bus
        self.audio_interrupt = audio_interrupt
        self.interrupt_detector = audio_interrupt.detector

        self.state = TurnState.IDLE
        self.exited = False
        self.next_turn_id = 0
        self.active_turn_id: int | None = None
        self.active_token: CancellationToken | None = None

        self.capture = CaptureController(settings, vad, self.interrupt_detector)
        self.asr_worker = AsrProcessingWorker(
            asr_client,
            policy,
            bus,
            channels=settings.audio.channels,
            sample_rate=settings.audio.sample_rate,
        )

    def emit_state(self, new_state: TurnState) -> None:
        previous = self.state
        self.state = new_state
        self.bus.publish(
            "/dialog/turn/state",
            TurnStateChanged(
                turn_id=self.active_turn_id,
                previous=previous.name.lower(),
                current=new_state.name.lower(),
                at=time.time(),
            ),
        )

    def _reset_to_idle(self) -> None:
        self.interrupt_detector.reset()
        self.audio_io.clear_input_queue()
        self.capture.reset()
        self.active_turn_id = None
        self.active_token = None
        self.arbiter.set_active(None, None)
        self.emit_state(TurnState.IDLE)

    def _begin_listening(self, first_chunk: bytes | None = None) -> None:
        started_at = self.capture.begin_listening(first_chunk)
        self.emit_state(TurnState.LISTENING)
        self.bus.publish(
            "/audio/speech_detected",
            UserSpeechDetected(turn_id=self.active_turn_id, at=started_at),
        )

    def tts_stop_and_reset(self) -> None:
        self.policy.tts_player.stop()
        self._reset_to_idle()

    def _consume_result_queue(self) -> None:
        for event_type, turn_id, payload in self.asr_worker.drain_results():
            if self.active_turn_id is None or turn_id != self.active_turn_id:
                continue
            if event_type == "done":
                if isinstance(payload, dict) and payload.get("spoken"):
                    if self.state != TurnState.SPEAKING:
                        self.emit_state(TurnState.SPEAKING)
                else:
                    self._reset_to_idle()
            elif event_type in {"cancelled", "error"}:
                self.tts_stop_and_reset()

    def _handle_cancelled_active_turn(self, raw: bytes) -> None:
        if self.active_token is None or not self.active_token.cancelled:
            return
        cause = self.active_token.cause
        self.policy.tts_player.stop()
        if cause == InterruptCause.VOICE_BARGE_IN:
            self.capture.barge_in_rewind(raw)
            self.active_turn_id = None
            self.active_token = None
            self.arbiter.set_active(None, None)
            self.emit_state(TurnState.LISTENING)
        else:
            self._reset_to_idle()

    def _install_signal_handlers(self) -> None:
        def exit_handler(signum, frame) -> None:
            del signum, frame
            self.exited = True
            if self.active_token is not None:
                self.active_token.cancel(InterruptCause.SHUTDOWN)
            self.policy.tts_player.stop()
            self.audio_io.close()
            self.bus.publish(
                "/service/state",
                ServiceStateChanged(previous="running", current="stopped"),
            )
            sys.exit(0)

        signal.signal(signal.SIGINT, exit_handler)
        signal.signal(signal.SIGTERM, exit_handler)

    def run(self) -> None:
        self.audio_interrupt.start(self.bus)
        self._install_signal_handlers()
        self.bus.publish(
            "/service/state",
            ServiceStateChanged(previous="booting", current="ready"),
        )
        self.emit_state(TurnState.IDLE)

        while not self.exited:
            if self.state in (TurnState.PROCESSING, TurnState.SPEAKING):
                self._consume_result_queue()

            try:
                raw = self.audio_io.read_chunk(timeout=0.2)
            except queue.Empty:
                raw = None

            if raw is None:
                continue

            if self.state == TurnState.PROCESSING:
                if self.active_token and self.active_token.cancelled:
                    self._handle_cancelled_active_turn(raw)
                continue

            if self.state == TurnState.IDLE:
                decision = self.capture.on_idle_chunk(raw)
                if decision == IdleDecision.SKIP:
                    continue
                if decision == IdleDecision.START_LISTENING:
                    self._begin_listening()

            elif self.state == TurnState.LISTENING:
                audio_buffer = self.capture.on_listening_chunk(raw)
                if audio_buffer is not None:
                    self.next_turn_id += 1
                    self.active_turn_id = self.next_turn_id
                    self.active_token = CancellationToken()
                    self.arbiter.set_active(self.active_turn_id, self.active_token)
                    self.bus.publish(
                        "/audio/speech_ended",
                        UserSpeechEnded(
                            turn_id=self.active_turn_id,
                            duration_ms=self.capture.capture_duration_ms(),
                        ),
                    )
                    self.asr_worker.submit(
                        self.active_turn_id, audio_buffer, self.active_token
                    )
                    self.emit_state(TurnState.PROCESSING)

            elif self.state == TurnState.SPEAKING:
                if self.active_turn_id is None or self.active_token is None:
                    self._reset_to_idle()
                    continue

                if self.active_token.cancelled:
                    self._handle_cancelled_active_turn(raw)
                    continue

                if not self.policy.tts_player.is_robot_speaking:
                    self._reset_to_idle()
                    continue

                elapsed = time.time() - self.policy.tts_player.get_start_time()
                if elapsed > self.settings.interrupt.grace_period_sec:
                    self.capture.freeze_baseline_once()
                    self.audio_interrupt.maybe_emit(raw)
                else:
                    self.interrupt_detector.feed_rolling(raw)
