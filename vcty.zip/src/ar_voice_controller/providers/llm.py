from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterator, Protocol

from openai import OpenAI

from ..core.cancellation import CancellationToken
from ..config import LlmCfg


@dataclass(slots=True)
class ContentDelta:
    text: str


@dataclass(slots=True)
class ToolCallDelta:
    raw: Any


@dataclass(slots=True)
class DoneDelta:
    pass


LlmDelta = ContentDelta | ToolCallDelta | DoneDelta
Message = dict[str, str]


class MessageHistory(Protocol):
    def add(self, message: Message) -> None: ...

    def snapshot(self) -> list[Message]: ...

    def clear(self) -> None: ...


class InMemoryHistory:
    def __init__(self, max_messages: int = 10):
        self.max_messages = max_messages
        self._messages: list[Message] = []

    def add(self, message: Message) -> None:
        self._messages.append(message)
        if len(self._messages) > self.max_messages:
            self._messages = self._messages[-self.max_messages :]

    def snapshot(self) -> list[Message]:
        return list(self._messages)

    def clear(self) -> None:
        self._messages.clear()


class LlmClient(Protocol):
    def chat_stream(
        self,
        messages: list[Message],
        *,
        token: CancellationToken,
        model: str | None = None,
        tools: list[dict[str, Any]] | None = None,
    ) -> Iterator[LlmDelta]: ...


class OpenAiLlmClient:
    def __init__(self, config: LlmCfg):
        self.config = config
        self.client = OpenAI(
            base_url=self.config.base_url,
            api_key=self.config.api_key or os.getenv("OPENAI_API_KEY") or "not-needed",
            timeout=self.config.timeout_sec,
        )
        self.system_prompt = (
            Path(self.config.system_prompt_path).read_text(encoding="utf-8").strip()
        )

    def chat_stream(
        self,
        messages: list[Message],
        *,
        token: CancellationToken,
        model: str | None = None,
        tools: list[dict[str, Any]] | None = None,
    ) -> Iterator[LlmDelta]:
        token.raise_if_cancelled()
        stream = self.client.chat.completions.create(
            model=model or self.config.model,
            messages=messages,
            stream=True,
            tools=tools or None,
        )
        try:
            for chunk in stream:
                token.raise_if_cancelled()
                choice = chunk.choices[0]
                delta = choice.delta
                content = delta.content or ""
                if content:
                    yield ContentDelta(text=content)
                tool_calls = getattr(delta, "tool_calls", None) or []
                for tool_call in tool_calls:
                    yield ToolCallDelta(raw=tool_call)
            yield DoneDelta()
        finally:
            if hasattr(stream, "close"):
                stream.close()


def build_messages(
    system_prompt: str,
    history: MessageHistory,
    user_text: str,
    *,
    language_tag: str,
) -> list[Message]:
    return [
        {"role": "system", "content": system_prompt},
        *history.snapshot(),
        {"role": "user", "content": f"[{language_tag}]: {user_text}"},
    ]
