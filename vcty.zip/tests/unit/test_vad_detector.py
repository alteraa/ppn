"""
Unit specs for the local VAD feature.

Feature under test: ``VadDetector.confidence`` — the orchestration around the
local Silero VAD ONNX model. We stub the ONNX runner (``_SileroOnnxVAD``) so
we can pin the observable contract without a real model file or inference:
  * ``int2float`` normalizes int16 PCM bytes to float32 in [-1, 1]
  * single-window inputs pass straight through to the model
  * multi-window inputs are chunked, padded, and aggregated
  * empty inputs short-circuit to 0.0

Source: ``ar_voice_controller.audio.vad``
"""

from __future__ import annotations

import pytest

pytestmark = pytest.mark.requires_onnx_model

pytest.importorskip("onnxruntime", reason="onnxruntime not installed")

import numpy as np  # noqa: E402

from ar_voice_controller.audio import vad as vad_module  # noqa: E402
from ar_voice_controller.audio.vad import VadDetector  # noqa: E402
from ar_voice_controller.config import VadCfg  # noqa: E402


class _ScriptedSileroVad:
    """Test double for ``_SileroOnnxVAD`` that returns scripted confidences."""

    def __init__(self, scores: list[float]) -> None:
        self._scores = list(scores)
        self.calls: list[tuple[int, int]] = []

    def forward_window(self, x: np.ndarray, sr: int) -> float:
        self.calls.append((int(x.shape[-1]), sr))
        if not self._scores:
            return 0.0
        return self._scores.pop(0)


@pytest.fixture
def vad_config() -> VadCfg:
    return VadCfg(model_path="ignored-for-tests")


@pytest.fixture
def detector(vad_config: VadCfg) -> VadDetector:
    return VadDetector(vad_config, sample_rate=16000)


def _install_fake_model(
    detector: VadDetector, scores: list[float]
) -> _ScriptedSileroVad:
    fake = _ScriptedSileroVad(scores)
    detector._model = fake  # type: ignore[assignment]
    return fake


class TestInt2Float:
    def test_empty_bytes_yields_zero_sized_array(self):
        arr = VadDetector.int2float(b"")
        assert arr.size == 0
        assert arr.dtype == np.float32

    def test_nonzero_pcm_is_scaled_into_unit_range(self):
        pcm = np.array([-32768, -16384, 0, 16384, 32767], dtype=np.int16).tobytes()
        arr = VadDetector.int2float(pcm)
        assert arr.dtype == np.float32
        assert np.all(arr >= -1.0 - 1e-6)
        assert np.all(arr <= 1.0 + 1e-6)

    def test_silence_stays_zero(self):
        pcm = np.zeros(8, dtype=np.int16).tobytes()
        arr = VadDetector.int2float(pcm)
        assert np.allclose(arr, 0.0)


class TestSingleWindowConfidence:
    def test_exactly_one_window_forwards_once(self, detector: VadDetector):
        fake = _install_fake_model(detector, [0.42])
        pcm = np.zeros(512, dtype=np.int16).tobytes()
        score = detector.confidence(pcm)
        assert score == pytest.approx(0.42)
        assert len(fake.calls) == 1
        assert fake.calls[0] == (512, 16000)

    def test_empty_buffer_short_circuits_to_zero(self, detector: VadDetector):
        fake = _install_fake_model(detector, [0.99])
        assert detector.confidence(b"") == 0.0
        assert fake.calls == []


class TestMultiWindowAggregation:
    def test_multi_window_runs_once_per_expected_chunk(self, detector: VadDetector):
        # 3 full windows of 512 samples each
        fake = _install_fake_model(detector, [0.1, 0.2, 0.3])
        pcm = np.zeros(512 * 3, dtype=np.int16).tobytes()
        detector.confidence(pcm)
        assert len(fake.calls) == 3

    def test_final_short_segment_is_padded_to_expected_window(
        self, detector: VadDetector
    ):
        fake = _install_fake_model(detector, [0.1, 0.2])
        pcm = np.zeros(512 + 100, dtype=np.int16).tobytes()
        detector.confidence(pcm)
        assert len(fake.calls) == 2
        for width, _ in fake.calls:
            assert width == 512

    def test_aggregate_score_is_at_least_the_mean(self, detector: VadDetector):
        scores = [0.1, 0.5, 0.9]
        _install_fake_model(detector, list(scores))
        pcm = np.zeros(512 * 3, dtype=np.int16).tobytes()
        result = detector.confidence(pcm)
        assert result >= np.mean(scores) - 1e-6

    def test_upper_quartile_boosts_score_above_plain_mean(self, detector: VadDetector):
        # When the upper quartile of windows is clearly speech, aggregation
        # must use max(mean, 75th percentile) so the hot tail is not diluted
        # by quieter windows. Pin: result dominated by the 75th percentile.
        scores = [0.1, 0.1, 0.8, 0.9]
        _install_fake_model(detector, list(scores))
        pcm = np.zeros(512 * 4, dtype=np.int16).tobytes()
        result = detector.confidence(pcm)
        assert result > float(np.mean(scores))
        assert result == pytest.approx(float(np.percentile(scores, 75)))


class TestModelResolution:
    def test_missing_model_path_raises_file_not_found(self, tmp_path, vad_config):
        vad_config.model_path = str(tmp_path)
        detector = VadDetector(vad_config, sample_rate=16000)
        pcm = np.zeros(512, dtype=np.int16).tobytes()
        with pytest.raises(FileNotFoundError):
            detector.confidence(pcm)

    def test_direct_onnx_path_is_accepted(self, tmp_path):
        onnx_file = tmp_path / "silero_vad.onnx"
        onnx_file.write_bytes(b"\x00")
        resolved = vad_module._resolve_silero_onnx(str(onnx_file))
        assert resolved == onnx_file
