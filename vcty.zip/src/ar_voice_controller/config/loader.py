from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import yaml

from .settings import Settings
from .._ansi import YELLOW
from ..telemetry.plain_logger import log_stage


def _deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    merged = dict(base)
    for key, value in override.items():
        if isinstance(value, dict) and key in merged and isinstance(merged[key], dict):
            merged[key] = _deep_merge(merged[key], value)
        else:
            merged[key] = value
    return merged


def _parse_env_value(raw: str) -> str | int | float | bool | None:
    lowered = raw.lower()
    if lowered in {"true", "false"}:
        return lowered == "true"
    if lowered == "none":
        return None
    try:
        if "." in raw:
            return float(raw)
        return int(raw)
    except ValueError:
        return raw


def _env_nested_dict(prefix: str = "AVC_") -> dict[str, Any]:
    data: dict[str, Any] = {}
    for key, value in os.environ.items():
        if not key.startswith(prefix):
            continue
        parts = key[len(prefix) :].lower().split("__")
        cursor = data
        for part in parts[:-1]:
            cursor = cursor.setdefault(part, {})
        cursor[parts[-1]] = _parse_env_value(value)
    return data


def load_settings(path: str | os.PathLike[str] = "config.yaml") -> Settings:
    config_path = Path(path)
    file_data: dict[str, Any] = {}
    if config_path.exists():
        loaded = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
        if not isinstance(loaded, dict):
            raise ValueError(f"Config file must contain a mapping: {config_path}")
        file_data = loaded
        log_stage("CONFIG", f"loaded from {config_path.resolve()}")
    else:
        log_stage(
            "CONFIG",
            f"config file not found at {config_path.resolve()!r}, using defaults",
            YELLOW,
        )

    env_overrides = _env_nested_dict()
    if env_overrides:
        log_stage(
            "CONFIG",
            f"applied {len(env_overrides)} top-level override(s) from AVC_* env vars",
        )

    merged = _deep_merge(file_data, env_overrides)
    settings = Settings.model_validate(merged)

    package_root = Path(__file__).resolve().parent
    if not Path(settings.llm.system_prompt_path).is_absolute():
        settings.llm.system_prompt_path = str(
            (
                package_root.parent.parent.parent / settings.llm.system_prompt_path
            ).resolve()
        )

    return settings
