from __future__ import annotations

import io
import os
from dataclasses import dataclass
from typing import Protocol

from openai import OpenAI

from ..core.cancellation import CancellationToken
from ..config import AsrCfg


@dataclass(slots=True)
class Transcription:
    text: str
    language: str


class AsrClient(Protocol):
    def transcribe(
        self,
        audio: bytes,
        *,
        token: CancellationToken,
        language: str | None = None,
    ) -> Transcription: ...


class OpenAiAsrClient:
    def __init__(self, config: AsrCfg):
        self.config = config
        self.client = OpenAI(
            base_url=self.config.base_url,
            api_key=self.config.api_key or os.getenv("OPENAI_API_KEY") or "not-needed",
            timeout=self.config.timeout_sec,
        )

    def transcribe(
        self,
        audio: bytes,
        *,
        token: CancellationToken,
        language: str | None = None,
    ) -> Transcription:
        token.raise_if_cancelled()
        file_obj = io.BytesIO(audio)
        file_obj.name = "audio.wav"
        response = self.client.audio.transcriptions.create(
            file=file_obj,
            model=self.config.model,
            language=language,
            response_format="verbose_json",
        )
        token.raise_if_cancelled()
        return Transcription(
            text=(getattr(response, "text", "") or "").strip(),
            language=(getattr(response, "language", "") or "").strip().lower(),
        )
