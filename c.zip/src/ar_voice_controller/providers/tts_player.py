from __future__ import annotations

import queue
import threading
import time
from dataclasses import dataclass

import numpy as np

from ..audio.io import AudioIO
from ..core.cancellation import CancellationError, CancellationToken
from ..runtime.event_types import (
    TtsAudioFrame,
    TtsPlaybackEnded,
    TtsPlaybackStarted,
    TtsSegmentStarted,
)
from ..runtime.events import EventBus
from .tts import TtsClient


@dataclass
class _SynthesisItem:
    turn_id: int
    token: CancellationToken
    text: str | None
    segment_index: int
    language: str
    is_end: bool


class TTSPlayer:
    def __init__(self, audio_io: AudioIO, tts_client: TtsClient, bus: EventBus):
        self.audio_io = audio_io
        self.tts_client = tts_client
        self.bus = bus
        self.tts_start_time = 0.0
        self.tts_lock = threading.Lock()
        self._playback_condition = threading.Condition(self.tts_lock)
        self.is_robot_speaking = False
        self._current_turn_id: int | None = None
        self._frame_index = 0
        self._synthesis_queue: queue.Queue[_SynthesisItem] = queue.Queue()
        self._playback_queue: queue.Queue[
            tuple[int, CancellationToken, str | None, int, np.ndarray | None, bool]
        ] = queue.Queue()
        self._synthesis_worker = threading.Thread(
            target=self._synthesis_loop, daemon=True
        )
        self._playback_worker = threading.Thread(target=self._playback_loop, daemon=True)
        self._segment_events_worker = threading.Thread(
            target=self._segment_events_loop, daemon=True
        )
        self._segment_marker_lock = threading.Lock()
        self._next_segment_marker_id = 1
        self._pending_segment_markers: dict[int, tuple[int, CancellationToken, str, int]] = {}
        self._synthesis_worker.start()
        self._playback_worker.start()
        self._segment_events_worker.start()

    def _segment_events_loop(self) -> None:
        while True:
            marker = self.audio_io.poll_started_segment()
            if marker is None:
                time.sleep(0.005)
                continue

            marker_id, started_at = marker
            with self._segment_marker_lock:
                pending = self._pending_segment_markers.pop(marker_id, None)
            if pending is None:
                continue

            turn_id, token, text, segment_index = pending
            if token.cancelled:
                continue

            self.bus.publish(
                "/tts/segment_started",
                TtsSegmentStarted(
                    turn_id=turn_id,
                    text=text,
                    index=segment_index,
                    at=started_at,
                ),
            )

    def _synthesis_loop(self) -> None:
        while True:
            item = self._synthesis_queue.get()
            try:
                item.token.raise_if_cancelled()
            except CancellationError:
                continue

            if item.is_end:
                self._playback_queue.put(
                    (item.turn_id, item.token, None, 0, None, True)
                )
                continue

            if not item.text:
                continue

            try:
                ref = self.tts_client.synthesize(
                    item.text,
                    token=item.token,
                    language=item.language,
                )
            except CancellationError:
                continue
            if ref is None:
                continue
            self._playback_queue.put(
                (item.turn_id, item.token, item.text, item.segment_index, ref, False)
            )

    def _playback_loop(self) -> None:
        while True:
            turn_id, token, text, segment_index, ref, is_end = self._playback_queue.get()
            if token.cancelled:
                continue

            if is_end:
                while self.audio_io.is_playing and not token.cancelled:
                    with self._playback_condition:
                        self._playback_condition.wait(timeout=0.05)
                if token.cancelled:
                    continue
                with self.tts_lock:
                    self.is_robot_speaking = False
                self.bus.publish(
                    "/tts/playback_ended",
                    TtsPlaybackEnded(turn_id=turn_id, at=time.time()),
                )
                continue

            if ref is None:
                continue

            with self.tts_lock:
                if token.cancelled:
                    continue
                if not self.audio_io.is_playing:
                    self.tts_start_time = time.time()
                    self.bus.publish(
                        "/tts/playback_started",
                        TtsPlaybackStarted(turn_id=turn_id, at=self.tts_start_time),
                    )
                self.is_robot_speaking = True
                self._current_turn_id = turn_id
            marker_id: int | None = None
            if text:
                with self._segment_marker_lock:
                    marker_id = self._next_segment_marker_id
                    self._next_segment_marker_id += 1
                    self._pending_segment_markers[marker_id] = (
                        turn_id,
                        token,
                        text,
                        segment_index,
                    )
            self.audio_io.enqueue_playback(ref, segment_id=marker_id)
            self.bus.publish(
                "/tts/audio_frame",
                TtsAudioFrame(
                    turn_id=turn_id,
                    rms=float(np.sqrt(np.mean(ref.astype(np.float32) ** 2))),
                    frame_index=self._frame_index,
                ),
            )
            self._frame_index += 1

    def start_stream(self, turn_id: int, token: CancellationToken) -> None:
        with self.tts_lock:
            self.is_robot_speaking = False
            self._current_turn_id = turn_id
        self.audio_io.clear_input_queue()
        if token.cancelled:
            self.stop()

    def enqueue_segment(
        self,
        turn_id: int,
        token: CancellationToken,
        text: str,
        *,
        index: int,
        language: str,
    ) -> None:
        segment = text.strip()
        if not segment or token.cancelled:
            return
        with self.tts_lock:
            self.is_robot_speaking = True
        self._synthesis_queue.put(
            _SynthesisItem(
                turn_id=turn_id,
                token=token,
                text=segment,
                segment_index=index,
                language=language,
                is_end=False,
            )
        )

    def finish_stream(
        self, turn_id: int, token: CancellationToken, *, language: str = ""
    ) -> None:
        self._synthesis_queue.put(
            _SynthesisItem(
                turn_id=turn_id,
                token=token,
                text=None,
                segment_index=0,
                language=language,
                is_end=True,
            )
        )

    def stop(self) -> None:
        with self.tts_lock:
            self.audio_io.stop_playback()
            self.is_robot_speaking = False
            self._current_turn_id = None
            self._playback_condition.notify_all()
        with self._segment_marker_lock:
            self._pending_segment_markers.clear()

    def get_start_time(self) -> float:
        with self.tts_lock:
            return self.tts_start_time
