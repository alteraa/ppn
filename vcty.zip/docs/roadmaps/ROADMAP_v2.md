# Roadmap v2 — Embodied Agent Integration

Bu belge, `voice-controller` repo'sunun **humanoid robot üzerindeki embodied agent** rolüne
evrimini kapsar. `ROADMAP.md` (v1), "voice-controller'ı MCP'ye ve asenkron tool'lara açmak"
odaklıydı; v2, aynı çekirdek üzerine robotun sensör / aktüatör / dünya modeli /
güvenlik katmanlarını bağlayan **entegrasyon yol haritasıdır**.

v1 hala geçerlidir; v2 onu yerine değil, **üzerine** koyar.

---

## 0. Robotun Mevcut Durumu — Sistem Özeti

Aşağıdaki tablo, karşı ekip tarafından geliştirilmiş robot stack'inin şu anki
yetenek envanterini gösterir. **"Var" olanlar entegrasyonun tüketicisidir**,
**"Yok"lar ise v2'nin yeni inşa kalemleridir**.

### 0.1 Platform

| Alan | Durum | Not |
|---|---|---|
| ROS sürümü | **ROS1 (migration halinde → ROS2)** | Yeni adapter node'lar ROS2-first yazılmalı; geçiş süresince `ros1_bridge` kullanılır |
| Real-time sınırı | **Mixed (RT + non-RT iç içe)** | Voice-controller *kesinlikle* RT katmanda olmayacak; sadece action goal / cancel gönderir |
| Repo / ekip sınırı | voice-controller + ASR/LLM/TTS bizim; robot stack ayrı ekip | Yeni ROS node'ları ekleyebiliyoruz (adapter pattern uygun) |
| Gömülü arayüz | **Sabit/sınırlı ROS komut seti** | Yeni motor komutu eklenemez; var olan action/service'lerin kompozisyonu yapılır |

### 0.2 Perception (tamamı hazır, topic yayını var)

- RGB-D kamera
- Yüz tespiti + **yüz tanıma** (embedding düzeyinde; kimlik kalıcılığı yok — session-only)
- İnsan iskelet/poz (2D/3D keypoints)
- Jest / el hareketi tanıma
- Genel nesne algılama (YOLO benzeri)
- **Ses kaynağı yönü (DOA)** — mic array var ama voice-controller şu an *kendi*
  mikrofonunu kullanıyor (EI-7'nin konusu)
- Konuşmacı tanıma / ses parmakizi

### 0.3 Proprioception & Localization (tamamı topic yayını)

- `joint_states`, tork, akım (gömülüden)
- IMU
- Odometry
- **AMCL/SLAM ile mevcut harita üzerinde 6-DoF poz**
- Batarya, termal
- **Tam TF ağacı**

### 0.4 Motion / Actuation Stack

| Yetenek | Durum | Arayüz |
|---|---|---|
| ros_control (ROS1) / ros2_control | Var | Controller manager aktif |
| Nav (Nav2 / move_base) | Var | **standart actionlib** |
| MoveIt | Var | **standart actionlib** |
| Head / gaze controller | Var | actionlib veya custom service |
| Kol primitive'leri (`point_to`, `wave`, `handover`) | Var | **karışık — bir kısmı custom service (cancellable değil!)** |
| Gripper / grasp | Var | actionlib |
| Locomotion (yürüme hedefi) | Var | Velocity / pose hedefi |
| İfade jestleri (nod, shake, wave, shrug) | Var | Action server |

> **Kritik kısıt:** Hareket primitive'lerinin bir kısmı actionlib (goal+feedback+cancel),
> bir kısmı **cancellable olmayan custom service**. EI-1'in cancellation shim'i
> bu heterojenliği üst katmandan gizlemek için şart.

### 0.5 Safety

| Yetenek | Durum | Yayın? |
|---|---|---|
| Donanım E-stop → yazılım topic | Var | Evet |
| Çarpışma tahmini / sanal bumper | Var | Evet |
| Self-collision kontrolü | Var | Evet |
| Workspace / sanal çit | Var | Evet |
| Watchdog / deadman | Var | Evet |
| **Bağımsız safety monitor süreci** | **Yok** | — |
| **Birleşik `/safety/*` topic ailesi** | **Kısmen** (topic adları parçalı) | — |

Olaylar **yayınlanıyor**, bu büyük şans — EI-4 sadece subscribe + cause
eşlemesi yapar, yeni bir monitor süreci yazılması gerekmez.

### 0.6 HMI (ifade çıktıları)

- **Yüz ekranı / animated face** (ifade gösterir)
- **LED / body-light**
- **Göğüs tableti / dokunmatik ekran**
- İfade jestleri (action olarak)
- TTS (zaten voice-controller'da)

### 0.7 Dünya Modeli & Bellek

Bütün bileşenler **ROS topic'inde canlı yayın** olarak mevcut — yani subscribe edip
snapshot almak yeterli.

- **Semantik harita** (odalar, nesneler etiketli)
- **Scene graph** (görünen objeler + ilişkiler)
- **Kişi takibi** (çoklu kare boyunca; ama kimlik **session-only**, restart sonrası kaybolur)
- **Episodic memory** (konuşma geçmişi — muhtemelen `service-robot-chatbot`'un
  Redis'iyle birleştirilebilir)

### 0.8 Orchestration — **AÇIK YER**

`none_orch`: Yüksek-seviye orchestrator, behavior tree, task manager **yok**.
Mevcut uygulamalar ayrı ayrı koşuyor. **v2'nin merkezi katkısı burasıdır**:
voice-controller, "embodied agent orchestrator"a evrilir.

### 0.9 Telemetri / Infra

- rosbag ile replay kültürü var
- Operatör paneli / diagnostics dashboard var
- Merkezi log toplayıcı / metrik sistemi yok
- Flotta yönetimi yok (tek robot)

### 0.10 LLM Entegrasyonu

- `service-robot-chatbot` şu an robotun durumundan **minimal** haberdar (sadece dil etiketi vb.)
- Hiçbir tool action ile bağlı değil
- Dinamik world-snapshot enjeksiyonu yok

### 0.11 Tek-cümlelik yargı

> **"Malzeme deposu dolu bir mutfak; eksik olan tek şey şef."**
> Perception ✓ · Motion ✓ · World model ✓ · Safety ✓ · HMI ✓ ·
> **Orchestration ✗** · **Unified skill contract ✗** · **LLM context injection ✗**

---

## 1. Hedef Mimari

```
              ┌──────────────────────────────────────────────────────────┐
              │  SAFETY (mevcut, /safety/* topic'lerinde yayında)         │
              │  e-stop · collision · self-collision · workspace · watchdog│
              └────────────────────────┬─────────────────────────────────┘
                                       │ EI-4 bridge
                                       ▼
┌──────────────┐  ┌──────────────┐  ┌──────────────────────────────────────┐
│ PERCEPTION   │  │ PROPRIO /    │  │      AGENT ORCHESTRATOR (v2)          │
│ (mevcut)     │  │ LOCALIZATION │  │   = voice-controller + adapter katmanı │
│ rgbd, face,  │──│  joint, imu, │─▶│                                       │
│ pose, gest,  │  │  amcl, battery│  │  ┌─────────────────────────────────┐ │
│ obj, doa     │  │  tf, thermal  │  │  │ TriggerRouter                   │ │
└──────────────┘  └──────────────┘  │  │  Voice · Vision · Safety ·      │ │
        │                │          │  │  Scheduled · ToolReturn · Doa   │ │
        ▼                ▼          │  └──────────────┬──────────────────┘ │
┌──────────────────────────────┐    │                 ▼                    │
│ EI-3 WORLD SNAPSHOT AGGREGATOR│───▶│  ┌─────────────────────────────────┐ │
│ /agent/world_snapshot (2 Hz)  │    │  │ TurnManager (multi-component)   │ │
│ scene graph + persons + pose  │    │  │  speech · motion · gaze · manip │ │
│ + battery + localization      │    │  └──────────────┬──────────────────┘ │
└──────────────────────────────┘    │                 ▼                    │
                                     │  ┌─────────────────────────────────┐ │
                                     │  │ Policies                         │ │
                                     │  │  · DialogPolicy (mevcut)        │ │
                                     │  │  · TaskPolicy (multi-round loop)│ │
                                     │  │  · ReflexPolicy (hızlı, kural)  │ │
                                     │  └──────────────┬──────────────────┘ │
                                     │                 ▼                    │
                                     │  ┌─────────────────────────────────┐ │
                                     │  │ Skill Dispatcher (voice-ctrl)   │ │
                                     │  │ → EI-1 skill-adapter üzerinden  │ │
                                     │  └──────────────┬──────────────────┘ │
                                     └─────────────────┼────────────────────┘
                                                       │
                              ┌────────────────────────┼────────────────────────┐
                              ▼                        ▼                        ▼
                    ┌──────────────────┐   ┌──────────────────────┐   ┌──────────────────┐
                    │ service-robot-    │   │ EI-1 SKILL ADAPTER   │   │ TTS / ASR        │
                    │ chatbot (LLM)     │   │ /agent/skill_request │   │ (mevcut HTTP)    │
                    │  + world context  │   │  → actionlib or svc  │   │                  │
                    │  + tool manifest  │   │  + cancel shim       │   │                  │
                    │  + identity bind  │   └──────┬──────┬────────┘   └──────────────────┘
                    └──────────────────┘          │      │
                                                  ▼      ▼
                                      ┌────────────┐  ┌────────────┐
                                      │ actionlib  │  │ custom svc │
                                      │ nav/moveit │  │ (wrapped)  │
                                      │ head/arm   │  └────────────┘
                                      └────────────┘

BUS: ROS (migrasyon süresince ros1_bridge) — voice-controller'ın
     in-process bus'ı ve ROS bus'ı aynı dataclass payload'larını taşır.
```

### Mimaride kritik kararlar

1. **Voice-controller → Agent Orchestrator evrimi**, *dosya isimleri değişmez*;
   sadece `core/manager.py` + `core/policy.py` + `core/types.py` genelleşir.
2. **Voice-controller asla RT katmanda değildir.** Yalnızca action goal gönderir
   ve `cancel` çağırır. Düşük seviye kontrol `ros_control`/`ros2_control` +
   gömülü tarafında kalır.
3. **Heterojen aksiyon arayüzleri (actionlib + custom svc) tek bir kontratın
   arkasına alınır** — EI-1 adapter. LLM, "skill call"ın altındaki protokolü bilmez.
4. **Tool execution hibrit**:
   - Yavaş / yan-etkisiz tool'lar (hava durumu, takvim, web) → LLM service içinde MCP.
   - Fiziksel / robot tool'ları → voice-controller içinde skill-adapter üzerinden.
5. **World snapshot, LLM context'inin parçasıdır** — prompt engineering ile
   değil, yapılandırılmış JSON olarak `system` rolündeki mesaja iliştirilir.
6. **Safety, ayrı süreç olmak zorunda değil** çünkü robot stack zaten izole.
   Fakat voice-controller'ın `ExternalStopSource`'u `/safety/*` topic'lerine
   bağlanır (EI-4).
7. **State machine düzleşir**: enum tabanlı `TurnState` → **component state
   matrisi** (`speech`, `motion`, `gaze`, `manipulation` paralel).

---

## 2. Yol Haritası

İşaretler v1'den korunmuştur:
- **Refactor size:** **S** (saatler), **M** (günler), **L** (haftalar).
- **Fit:** 0-10 (10 = drop-in, 0 = sıfırdan).

Her madde `[origin]` etiketiyle işaretlenmiştir:
- `T1/T2/T3-N` → v1 Tier 1/2/3 madde N
- `FI-N` → v1 Future Integration madde N
- `EI-N` → **v2 yeni maddesi** (Embodied Integration)

### 2.1 Faz A — Fiziksel ciddiyet (güvenlik, timeout, observability)

Bu faz olmadan robot üzerinde herhangi bir skill testine **başlanmamalıdır**.

#### A1. `[T1-1]` Counter carry-over fix
- **S · 9/10**
- `InterruptDetector._counter` `PROCESSING → SPEAKING` geçişinde sıfırlanmıyor.
- Fix: `InterruptDetector.clear_counter()` + transition hook'larında çağır.
- Files: `audio/interrupt.py`, `core/manager.py`.

#### A2. `[T1-5 + EI-4]` Safety bridge — `/safety/*` → `ExternalStopSource`
- **S · 10/10**
- `ExternalStopSource` zaten mevcut (`audio/interrupt.py:130-143`), sadece
  `Pipeline`'de instantiate edilmiyor.
- Yeni: `runtime/safety_bridge.py` — ROS subscriber, aşağıdaki eşlemeyi yapar.

  | ROS topic (mevcut) | `InterruptCause` | priority |
  |---|---|---|
  | `/safety/estop` | **YENİ** `SAFETY_ESTOP` | 100 |
  | `/safety/collision_imminent` | **YENİ** `SAFETY_COLLISION` | 95 |
  | `/safety/self_collision` | `SAFETY` (genişletilmiş) | 90 |
  | `/safety/workspace_violation` | `SAFETY` | 85 |
  | `/safety/watchdog_timeout` | `SHUTDOWN` | 100 |

- `InterruptCause` enum'una eklemeler: `SAFETY_ESTOP`, `SAFETY_COLLISION`
  (mevcut `SAFETY` kalsın, geri uyumluluk).
- `core/cancellation.py:8-14` güncellenir.
- Files: `audio/interrupt.py`, `runtime/safety_bridge.py` (yeni), `pipeline.py`,
  `config.yaml` (topic isim override'ları).

#### A3. `[T1-2]` Turn-level + tool-level timeout
- **M · 8/10**
- v1'de yalnızca LLM timeout'u hedefliydi; v2'de **her skill goal'ü için ayrı timeout**.
- Yeni config:
  ```yaml
  turn:
    max_turn_sec: 60.0
  tool:
    default_timeout_sec: 20.0
    timeouts_by_name:
      move_to: 45.0
      grasp: 15.0
      look_at: 5.0
  ```
- `TurnManager` ana döngüsünde `time.time() - active_turn_started_at` kontrolü.
- `InterruptCause.TIMEOUT` zaten mevcut (kullanılmıyordu).
- Files: `config/audio.py`, `config.yaml`, `core/manager.py`, yeni `config/turn.py`,
  yeni `config/tool.py`.

#### A4. `[T1-4 + EI yeni]` Filler + "thinking" multimodal expression
- **S-M · 9/10**
- LLM tool waiting sırasında hem **TTS filler** hem **yüz ekranı + kafa jesti**
  emit edilsin.
- Protokol: LLM stream'inde boşluk (>1.5s) yakalandığında bus'a `ToolWaiting`
  event'i düşer. İki subscriber:
  - `TTSPlayer` filler segment enqueue eder (dil bazlı bank'tan).
  - Yeni `runtime/expression_bridge.py` → `/face/expression = thinking` ve
    `/head/gesture = look_away_brief` aksiyonlarını tetikler (EI-1 üzerinden).
- Files: `core/policy.py`, `providers/llm.py`, yeni `runtime/expression_bridge.py`,
  yeni `prompts/filler_tr.yaml`.

#### A5. `[T1-6 + FI-9]` Tool & service event telemetry
- **S-M · 8/10**
- Mevcut `ToolCallRequested` / `ToolCallCompleted` dataclass'ları emit edilmiyor.
- EI-1 skill adapter her aksiyonda (`/agent/skill_feedback`) olay basacak;
  voice-controller bunu `/tools/*` topic'lerine forward edecek.
- ASR/TTS response header'larını da yayınla (`AsrModelLoaded`, `TtsModelUsed`).
- Files: `providers/llm.py`, `providers/sr.py`, `providers/tts.py`,
  `runtime/event_types.py`.

### 2.2 Faz B — HTTP servis göçü (zaten v1'de planlı)

Sadece config işleri ve protokol dönüşümü. Robot bağlamından bağımsız ama
sonraki fazların öncülü.

#### B1. `[FI-1]` ASR service migration (OpenAI-compat → asr-api)
- **S · 9/10**
- `AsrCfg.base_url = http://127.0.0.1:8008/v1`, `model = large-v3`.
- `OPENAI_API_KEY` zorunluluğu kalkar.
- `response_format=verbose_json` korunur (language metadata için).

#### B2. `[FI-2]` TTS service migration
- **S · 9/10**
- `TtsCfg.base_url = http://127.0.0.1:8020/v1`.
- `voice_by_language` → piper model ID'leri.
- `X-Sample-Rate` header'a göre resampling kararı ileride.

#### B3. `[FI-3]` TTS verbalization & richer synth params
- **S · 7/10** (opsiyonel)
- `/v1/audio/inference` yolu → `verbalize`, `length_scale`, `noise_scale`, `speaker_id`.
- `providers/tts.py` içinde ikinci path.

#### B4. `[FI-4]` LLM streaming adapter (SSE → `LlmDelta`)
- **M · 7/10**
- `HttpLlmClient` — `httpx` SSE akışı; chunk dict → `ContentDelta`/`ToolCallDelta`/`DoneDelta`.
- Cancel: her chunk sonrası `token.raise_if_cancelled()`.
- `OpenAiLlmClient` bypass modu için kalır.

#### B5. `[FI-5]` LLM session + API-key lifecycle
- **S-M · 6/10**
- `x-session-id` header zorunlu; startup'ta `POST /session`.
- `providers/llm_session.py` küçük helper.
- UUID per-process veya disk-persisted (config ile seçilebilir).

### 2.3 Faz C — Pipeline'ı multi-modal açmak (orchestration'ın temeli)

Bu faz **embodied yeteneklerin açıldığı kritik dönüm noktasıdır**. Faz A ve B
paralel bitirilmeden C'ye başlanmamalı.

#### C1. `[T2-8]` `TurnTrigger` tagged union
- **M · 6/10** — **KRİTİK**
- `TurnContext.transcript: FinalTranscript` sabitlemesi kalkar.
- Yeni tip:
  ```python
  # core/triggers.py
  @dataclass(slots=True)
  class VoiceTrigger:
      transcript: FinalTranscript

  @dataclass(slots=True)
  class VisionTrigger:
      payload: dict  # face_id, position, confidence, gesture, ...

  @dataclass(slots=True)
  class SafetyTrigger:
      cause: InterruptCause
      detail: dict

  @dataclass(slots=True)
  class ScheduledTrigger:
      text: str
      reason: str  # "reminder", "greeting", ...

  @dataclass(slots=True)
  class ToolReturnTrigger:
      previous_turn_id: int
      tool_name: str
      result: Any

  @dataclass(slots=True)
  class AudioDoaTrigger:
      angle_deg: float
      confidence: float

  TurnTrigger = Union[
      VoiceTrigger, VisionTrigger, SafetyTrigger,
      ScheduledTrigger, ToolReturnTrigger, AudioDoaTrigger
  ]
  ```
- `TurnContext` → `trigger: TurnTrigger`.
- `StreamingLlmPolicy.run` → trigger type'a göre `build_messages` çağırır;
  `VisionTrigger` için "ctx kullanıcı yaklaşıyor" sistem mesajı, vb.
- `AsrProcessingWorker` → generic `TurnWorker` (ASR bir kaynak).
- Files: `core/types.py`, `core/triggers.py` (yeni), `core/policy.py`,
  `core/worker.py`, `core/manager.py`.

#### C2. `[T2-9]` `/turn/external_request` channel
- **M · 6/10** (C1'e bağımlı)
- `TurnManager` yeni topic'e subscribe: `/turn/external_request` → `TurnTrigger`.
- `IDLE → PROCESSING` doğrudan geçiş (VAD atlanır).
- Mevcut VAD yolu değişmez.
- Files: `core/manager.py`.

#### C3. `[EI-3]` World snapshot aggregator node
- **M · 7/10** — YENİ
- Ayrı ROS node paketi: `robot_agent_adapter/world_snapshot_aggregator`.
- Subscribe ettiği topic'ler (mevcut robot stack'inden):
  - `/world/scene_graph`
  - `/world/persons/tracked` (id, pose, face embedding, last_seen)
  - `/map/semantic` (statik)
  - `/localization/pose` (amcl)
  - `/battery/state`
  - `/robot/thermal`
- Publishes: `/agent/world_snapshot` @ 2 Hz (throttled).
- Request API: `/agent/world/query` service → daraltılmış view
  (scope: `visible_objects` | `interlocutor` | `self_state` | `full`).
- **Örnek snapshot JSON:**
  ```json
  {
    "t": 1714300000.12,
    "self": {
      "pose": {"x": 2.4, "y": 1.1, "yaw_deg": 45},
      "battery_pct": 78,
      "motion_state": "idle",
      "thermal_alert": false
    },
    "room": "living_room",
    "persons": [
      {"track_id": 3, "face_embedding_hash": "ab12…",
       "relative_pos": {"angle_deg": -15, "distance_m": 1.4},
       "is_interlocutor": true, "last_gesture": null}
    ],
    "visible_objects": [
      {"class": "cup", "pose": [2.1, 1.3, 0.8], "confidence": 0.92}
    ]
  }
  ```
- Files: yeni repo / yeni ROS package (voice-controller'dan ayrı). Voice-controller'da
  sadece `providers/world.py` HTTP/topic client.

#### C4. `[EI-7]` Mic array & DOA integration (opsiyonel, faz-sonu)
- **M · 5/10**
- **Kısa vade:** mevcut independent mic kalır; DOA topic'i (`/audio/doa/angle`)
  `AudioDoaTrigger` olarak tüketilir → "konuşmacıya dön" skill'i tetiklenir.
- **Orta vade:** mic array'in beamformed PCM çıktısı voice-controller'ın ses
  girişi olur; `AudioIO` config'i ROS topic'inden okuyacak şekilde genişler.
- Files: `audio/io.py` (yeni source type: `ros_topic`), `config/audio.py`.

### 2.4 Faz D — Aksiyon ekosistemi (skills)

Burada robot *yapan* oluyor. C fazı bittikten sonra.

#### D1. `[EI-1]` Skill adapter node
- **M · 7/10** — YENİ, KRİTİK
- Ayrı ROS package: `robot_agent_adapter/skill_adapter`.
- **Amaç:** actionlib + custom service heterojenliğini tek bir kontratın
  arkasına al.
- Input topic/service:
  - `/agent/skill_request` (service veya action — tercihen **action** ki cancel/feedback olsun)
  - Payload: `{name, arguments, correlation_id, deadline_sec}`
- Output bus olayları:
  - `/agent/skill/started` {correlation_id, name}
  - `/agent/skill/feedback` {correlation_id, progress, partial_state}
  - `/agent/skill/completed` {correlation_id, result}
  - `/agent/skill/cancelled` {correlation_id, reason}
  - `/agent/skill/failed` {correlation_id, error}
- İçeride **driver registry**:
  ```
  drivers/
    nav.py        -> wraps /move_base action (actionlib pass-through)
    moveit.py     -> wraps /move_group action
    head_gaze.py  -> wraps /head/look_at
    arm_point.py  -> wraps /arm/point_to CUSTOM SERVICE (shim below)
    grip.py       -> wraps /gripper action
    gesture.py    -> wraps /expression/gesture action
    face_expr.py  -> wraps /face/expression service
  ```
- **Cancellation shim (custom service için):**
  - Custom service yarıda kesilemiyorsa "best-effort" protokol:
    1. Goal çağrısı ayrı bir thread'de başlatılır.
    2. `cancel` gelirse adapter `failed` olay basar, sonuç gelirse yok sayılır.
    3. Gömülü tarafa `/emergency/stop_motion` publish edilir (eğer varsa).
    4. `deadline_sec` dolarsa aynı protokol.
- Files: yeni ROS package, voice-controller tarafı `providers/skills.py`
  (Skill dispatch client).

#### D2. `[EI-2]` Skill registry & LLM tool manifest
- **S-M · 6/10** — YENİ
- Skill adapter `GET /agent/skills` endpoint'i yayınlar:
  ```json
  [
    {
      "name": "look_at",
      "description": "Turn head to face a world point or tracked person.",
      "schema": {
        "target": {"oneOf": [
          {"type": "object", "properties": {"track_id": {"type": "integer"}}},
          {"type": "object", "properties": {"x": {"type": "number"},
                                             "y": {"type": "number"},
                                             "z": {"type": "number"}}}
        ]}
      },
      "est_duration_sec": 1.5,
      "cancellable": true,
      "side_effects": ["head_motion"]
    },
    ...
  ]
  ```
- `service-robot-chatbot` startup'ta bu manifest'i çeker; OpenAI tool-schema
  formatına çevirir; system prompt'ın tool listesine koyar.
- Yeni skill eklendiğinde LLM'e otomatik görünür.
- Files: skill adapter yeni endpoint + service-robot-chatbot'ta yeni startup hook.

#### D3. `[T3-11 küçültülmüş + FI-7B]` Tool execution loop (multi-round policy)
- **M · 5/10**
- `StreamingLlmPolicy` tek-round. `TaskPolicy` (yeni) multi-round:
  ```
  Stream chunk'lar al
    eğer ContentDelta: TTS'e segment gönder
    eğer ToolCallDelta: biriktir
    eğer DoneDelta AND tool_calls var:
      her tool için:
        skill_adapter'a paralel gönder  (eğer side_effects çakışmıyorsa)
        correlation_id'leri sakla
      skill completed/failed'i bekle (ToolWaiting bus event'i)
      sonuçları role="tool" mesajı olarak LLM'e geri post et
      round++ → tekrar stream aç
    eğer DoneDelta AND tool_calls yok:
      bitir
  ```
- **Cancellation:** ctx.token iptal olursa — hem LLM stream kapat hem aktif
  skill'leri `skill_adapter.cancel(correlation_id)` ile iptal et.
- Files: yeni `core/task_policy.py`, `providers/llm.py` (tool_call shape desteği),
  `providers/skills.py`.

#### D4. `[T1-3 + FI-8 genişletilmiş]` Per-turn cancel contract
- **M · 6/10**
- Barge-in geldiğinde:
  - LLM stream: `x-turn-id` ile `POST /chat/{turn_id}/cancel` (FI-8 v1) veya
    bağlantıyı kapat.
  - Skill adapter: aktif `correlation_id`'ler için `/agent/skill/cancel`.
  - TTS: zaten `tts_player.stop()`.
- LLM service'te **commit protocol**: stream bittiğinde son chunk'ta `X-Commit: true`;
  mid-stream close → history'e yazma.
- Files: `providers/llm.py`, `providers/skills.py`, `core/manager.py`, LLM service.

#### D5. `[FI-6 + world injection]` Context ownership + world snapshot injection
- **M · 5/10**
- `InMemoryHistory` artık feature-flag ile (offline test için) kalır; default
  olarak server-side history kullanılır.
- Her chat request'ine, EI-3'ten alınan son `world_snapshot` daraltılmış hali
  `x-world-context` header'ı veya request body'nin `meta` alanı olarak eklenir.
- `service-robot-chatbot` bunu system prompt'a işler.
- Files: `core/policy.py`, `providers/llm.py`, `providers/world.py`,
  service-robot-chatbot prompt builder.

### 2.5 Faz E — Yapısal olgunluk

Embodied sistem çalışır hale gelince yapılan işler. Paralel ilerleyebilir.

#### E1. `[EI-6]` Multi-component state model
- **M-L · 5/10** — YENİ (v1 T3-12'nin genişletilmiş hali)
- `TurnState` enum → component state matrisi:
  ```python
  @dataclass
  class ComponentStates:
      speech: SpeechState   # IDLE / LISTENING / SPEAKING / FILLER
      motion: MotionState   # IDLE / MOVING / HOLDING / RECOVERING
      gaze:   GazeState     # FREE / TRACKING / LOCKED
      manip:  ManipState    # IDLE / PLANNING / EXECUTING
  ```
- Her component kendi `InterruptCause` filtresini yönetir (örn. `SAFETY_ESTOP`
  tüm component'leri durdurur; `VOICE_BARGE_IN` sadece `speech`'i).
- `TurnManager` üst koordinatör — component'lerin state değişikliklerini
  bus'tan dinler.
- Files: `core/states.py` (yeni), `core/manager.py` (büyük yeniden yapılandırma).

#### E2. `[EI-8]` ROS1→ROS2 migration alignment
- **S · 8/10** (voice-controller tarafı)
- `ros_backends.py` zaten ikiyi destekliyor.
- Yeni adapter node'lar ROS2-first. `ros1_bridge` migration süresince.
- Voice-controller'ın kendi topic şeması **ROS mesaj tipinden bağımsız
  (JSON payload)**, migration'a bağışık.
- Files: `runtime/ros_backends.py` konfig iyileştirmeleri.

#### E3. `[T3-13]` Testing harness
- **M · 4/10**
- Öncelikli testler:
  - `CancellationToken.child()` propagation.
  - `CaptureController` VAD debounce / rewind.
  - Fake `TurnTrigger` kaynakları → `TaskPolicy.run` çıktısı.
  - Fake skill adapter (HTTP) → tool loop doğruluğu.
  - Safety bridge → `ExternalStopSource` → token cancel yolu.
- `tests/` scaffold + pytest + pre-commit hook.
- Files: yeni `tests/` ağacı.

#### E4. `[FI-10]` Deployment alignment
- **S · 7/10**
- `docker-compose.yaml` → ASR (8008) + LLM (8000) + TTS (8020) + voice-controller.
- `systemd` bundle alternatifi.
- Provider client'larda startup retry (servisler çökebilir).
- Files: yeni `deploy/`, `config.yaml`.

### 2.6 Faz F — Opsiyonel / uzun vade

#### F1. `[EI-5]` Persistent identity service
- **M · 4/10**
- Ayrı mini servis: SQLite/Postgres + embedding index.
- ROS service `/identity/resolve (face_embedding) → stable_user_id`.
- `service-robot-chatbot` `x-user-id` header'ıyla Redis bucket seçer
  → kullanıcı başına konuşma hafızası.
- **Yalnızca uzun dönem kişiselleştirme/hafıza isteniyorsa.**

#### F2. `[T2-10]` Split `TTSPlayer` (standalone synthesize_to_pcm)
- **M · 5/10**
- `tts.synthesize_to_pcm(text, cfg) -> np.ndarray` küçük helper.
- Pipeline dışı kullanım (örn. önceden hazırlanmış fillers) için.

#### F3. `[T3-14]` Multi-robot / fleet
- **L · 5/10**
- Şu an tek robot. Flotta geldiğinde ele alınır.

---

## 3. Öncelik Listesi (Tam Sıralı)

| # | Madde | Faz | Boyut | Fit |
|---|---|---|---|---|
| 1 | A1 Counter carry-over fix | A | S | 9 |
| 2 | A2 Safety bridge + ExternalStopSource wiring | A | S | 10 |
| 3 | A3 Turn + tool timeout | A | M | 8 |
| 4 | A5 Tool & service event telemetry | A | S-M | 8 |
| 5 | B1 ASR service migration | B | S | 9 |
| 6 | B2 TTS service migration | B | S | 9 |
| 7 | B4 LLM streaming adapter | B | M | 7 |
| 8 | B5 LLM session + API key lifecycle | B | S-M | 6 |
| 9 | A4 Filler + multimodal thinking expression | A | S-M | 9 |
| 10 | C1 `TurnTrigger` tagged union | C | M | 6 |
| 11 | C2 `/turn/external_request` channel | C | M | 6 |
| 12 | C3 World snapshot aggregator (EI-3) | C | M | 7 |
| 13 | D1 Skill adapter node (EI-1) | D | M | 7 |
| 14 | D2 Skill registry + LLM tool manifest (EI-2) | D | S-M | 6 |
| 15 | D3 Tool execution loop (TaskPolicy) | D | M | 5 |
| 16 | D4 Per-turn cancel contract (LLM + skill) | D | M | 6 |
| 17 | D5 Context ownership + world injection | D | M | 5 |
| 18 | E1 Multi-component state model (EI-6) | E | M-L | 5 |
| 19 | E2 ROS1→ROS2 alignment | E | S | 8 |
| 20 | C4 Mic array / DOA integration (EI-7) | C/E | M | 5 |
| 21 | E3 Testing harness | E | M | 4 |
| 22 | E4 Deployment alignment | E | S | 7 |
| 23 | B3 TTS verbalization (opt) | B | S | 7 |
| 24 | F1 Persistent identity (EI-5, opt) | F | M | 4 |
| 25 | F2 Split TTSPlayer (opt) | F | M | 5 |
| 26 | F3 Multi-robot (opt, long-horizon) | F | L | 5 |

> **Kritik yol:** 1 → 2 → 3 → 10 → 12 → 13 → 14 → 15 → 16 → 17. Bu 10 madde
> tamamlandığında "embodied agent" işlevsel olur.

---

## 4. Kabaca Efor & Risk Tablosu

| Metrik | Değer |
|---|---|
| Süre (1-2 kişi) | **2-3 ay** kritik yol; + 1-2 ay olgunlaşma |
| Yeni Python LOC | ~1.5-2.5k (voice-controller tarafı) |
| Yeni ROS package LOC | ~2-3k (skill-adapter + world-snapshot-aggregator) |
| Voice-controller içi değişim | ~%25-30 |
| En büyük teknik risk | **Custom service skill'lerinin cancellation shim'i** (D1) — bazı hareketler gerçekten yarıda kesilemeyecek; shim "best-effort" kalacak |
| İkinci risk | **ROS1→ROS2 migration** zamanlaması — v2 bitmeden diğer ekip ROS2'ye geçerse köprü kurmak gerekir |
| Üçüncü risk | **LLM service prompt büyümesi** — world snapshot + tool manifest + history → token quota; özetleme / sıkıştırma gerekebilir |
| En büyük kazanım | Perception/motion/world/safety stack'leri **zaten hazır** — sadece tüketim katmanı inşa ediliyor |

---

## 5. Cross-Cutting Principles (v2)

v1'in ilkeleri korunur, üstüne eklenenler:

- **Providers remain `Protocol`-based** (v1) — bu, skill/world/identity için de aynen.
- **Interrupts topic-driven** (v1) — her yeni interrupt kaynağı
  `/interrupt/requested`'e publish eder. Safety bridge (A2) bu kuralın örneğidir.
- **Instrument before refactor** (v1) — A5 (telemetry) C/D fazından önce.
- **Prefer event bus fan-out over method calls** (v1) — tool_event, world_snapshot,
  face_detected hepsi bus üstünden.
- **NEW — Voice-controller is not a real-time controller.** Alçak-seviye kontrol
  asla Python sürecine girmez. Yalnızca "goal + cancel".
- **NEW — Skill layer must be protocol-unified.** LLM'in ve voice-controller'ın
  aktüatör heterojenliğini bilmesi gerekmez; EI-1 adapter perdesi bunu sağlar.
- **NEW — LLM context is structured, not improvised.** World snapshot JSON
  formatında; prompt engineering ile "yan taraftaki bardak" bilgisi katılmaz.
- **NEW — Migration-agnostic wire format.** Voice-controller olay şeması JSON
  payload (dataclass → `encode_event`); ROS mesaj tipine bağlı değil,
  ROS1/ROS2 geçişinde ayakta kalır.

---

## 6. Appendix A — Yeni Dataclass / Enum Taslakları

### 6.1 `InterruptCause` genişlemesi (v1'den geçiş)

```python
# core/cancellation.py
class InterruptCause(str, Enum):
    # — mevcut (v1) —
    VOICE_BARGE_IN = "voice_barge_in"
    EXTERNAL_STOP = "external_stop"
    SAFETY = "safety"          # korunur, geri uyumluluk
    TIMEOUT = "timeout"
    CONTEXT_RESET = "context_reset"
    SHUTDOWN = "shutdown"
    # — yeni (v2) —
    SAFETY_ESTOP = "safety_estop"
    SAFETY_COLLISION = "safety_collision"
    SAFETY_WORKSPACE = "safety_workspace"
    SAFETY_SELF_COLLISION = "safety_self_collision"
    TOOL_TIMEOUT = "tool_timeout"
    TOOL_FAILED = "tool_failed"
    USER_CANCEL = "user_cancel"      # kullanıcı "dur" dediğinde (intent)
    BATTERY_LOW = "battery_low"
```

### 6.2 Yeni event types (`runtime/event_types.py` eklemeleri)

```python
@dataclass(slots=True)
class WorldSnapshot:
    at: float
    data: dict  # Appendix C'deki şema

@dataclass(slots=True)
class SkillRequested:
    correlation_id: str
    name: str
    arguments: dict
    turn_id: int | None

@dataclass(slots=True)
class SkillStarted:
    correlation_id: str
    at: float

@dataclass(slots=True)
class SkillFeedback:
    correlation_id: str
    progress: float
    partial_state: dict

@dataclass(slots=True)
class SkillCompleted:
    correlation_id: str
    result: dict
    duration_ms: float

@dataclass(slots=True)
class SkillCancelled:
    correlation_id: str
    cause: str

@dataclass(slots=True)
class SkillFailed:
    correlation_id: str
    error: str
    recoverable: bool

@dataclass(slots=True)
class SafetyEvent:
    source: str         # "estop" | "collision" | ...
    severity: str       # "critical" | "warning"
    detail: dict

@dataclass(slots=True)
class PersonPresence:
    track_id: int
    present: bool
    relative_angle_deg: float | None
    distance_m: float | None

@dataclass(slots=True)
class ToolWaiting:
    turn_id: int
    since_sec: float
    context: str | None   # "LLM waiting on tool X"
```

### 6.3 Topic namespace (voice-controller kendi bus'ında)

```
/audio/*              (mevcut)
/dialog/turn/*        (mevcut)
/dialog/assistant/*   (mevcut)
/llm/*                (mevcut)
/tts/*                (mevcut)
/interrupt/*          (mevcut)
/service/state        (mevcut)
/tools/requested      (v2)
/tools/completed      (v2)
/tools/waiting        (v2)
/agent/world_snapshot (v2 — EI-3 forward)
/agent/skill/*        (v2 — EI-1 forward)
/safety/*             (v2 — EI-4 bridged)
/presence/person      (v2 — perception → turn trigger)
```

---

## 7. Appendix B — Skill Manifest Şeması (EI-2)

```yaml
# robot_agent_adapter/skill_adapter/manifest.yaml (ÖRNEK)
skills:
  - name: look_at
    description: |
      Turn the head to face a world point or a tracked person.
    arguments:
      type: object
      oneOf:
        - properties:
            track_id: {type: integer}
          required: [track_id]
        - properties:
            x: {type: number}
            y: {type: number}
            z: {type: number, default: 1.6}
          required: [x, y]
    est_duration_sec: 1.5
    cancellable: true
    side_effects: [head]
    # Adapter internal (LLM görmez):
    backend:
      kind: actionlib
      action: /head/look_at
      goal_mapping: {track_id: tracked_frame, x: target.x, y: target.y}

  - name: move_to
    description: Navigate to a pose on the current map.
    arguments:
      type: object
      properties:
        target: {type: string, description: "semantic room or object name"}
        pose:   {type: object, description: "fallback x,y,yaw_deg"}
    est_duration_sec: 30.0
    cancellable: true
    side_effects: [base, motion]
    backend:
      kind: actionlib
      action: /move_base

  - name: point_to
    description: Raise the arm and point to a target in space.
    arguments:
      type: object
      properties:
        target: {type: string}
    est_duration_sec: 4.0
    cancellable: false    # ← custom service; shim uygulanır
    side_effects: [arm]
    backend:
      kind: service
      service: /arm/point_to
      cancel_strategy: best_effort_with_emergency_halt

  - name: express
    description: Show a facial expression on the face display.
    arguments:
      type: object
      properties:
        expression:
          type: string
          enum: [happy, thinking, sad, surprised, listening, neutral]
        duration_sec: {type: number, default: 2.0}
    est_duration_sec: 0.1
    cancellable: true
    side_effects: [face]
    backend:
      kind: service
      service: /face/expression
```

---

## 8. Appendix C — World Snapshot JSON Şeması (EI-3)

Tam şema; LLM'e gönderilen *daraltılmış* forma `world.query(scope=...)` servisi
karar verir.

```json
{
  "t": 1714300123.45,
  "schema_version": "1.0",
  "self": {
    "pose": {"x": 2.4, "y": 1.1, "z": 0.0, "yaw_deg": 45},
    "room": "living_room",
    "battery_pct": 78,
    "thermal_alert": false,
    "motion_state": "idle",
    "speech_state": "idle"
  },
  "persons": [
    {
      "track_id": 3,
      "persistent_id": null,
      "name": null,
      "relative_pos": {"angle_deg": -15, "distance_m": 1.4, "height_m": 1.72},
      "is_interlocutor": true,
      "last_gesture": null,
      "last_seen": 1714300122.98,
      "face_visible": true
    }
  ],
  "visible_objects": [
    {"class": "cup", "pose": [2.1, 1.3, 0.8], "confidence": 0.92,
     "id": "obj_42", "relation_to_self": "in_front_of"}
  ],
  "scene_graph": {
    "rooms": ["living_room", "kitchen"],
    "known_objects_by_room": {
      "living_room": ["obj_42", "obj_43"],
      "kitchen": ["obj_10", "obj_11"]
    }
  },
  "safety": {
    "estop": false,
    "collision_warnings": []
  }
}
```

---

## 9. Appendix D — Cancellation Propagation (Multi-Layer)

```
user barge-in (audio)
  └─▶ /interrupt/requested (voice, priority=50)
         └─▶ InterruptArbiter._handle_request
                └─▶ active_token.cancel(VOICE_BARGE_IN)
                       ├─▶ LLM stream: httpx connection close
                       │     └─▶ service-robot-chatbot drops partial reply
                       ├─▶ TTSPlayer.stop() (mevcut)
                       └─▶ Skill Dispatcher:
                             for each active correlation_id:
                                /agent/skill/cancel
                                   ├─▶ actionlib goal cancel (pass-through)
                                   └─▶ custom svc shim:
                                         /emergency/stop_motion publish
                                         thread join with timeout
                                         → SkillCancelled event

SAFETY /safety/estop
  └─▶ EI-4 safety_bridge
         └─▶ /interrupt/requested (external, priority=100, SAFETY_ESTOP)
                └─▶ aynı yukarıdaki zincir,
                    + TurnManager component-state = HARD_STOPPED
                    (hiçbir yeni trigger kabul edilmez, E-stop kalkana dek)
```

---

## 10. Appendix E — Açık Sorular / Gelecek Netleştirmeler

Bu sorular **ilerleyen fazlarda cevaplanmalı**:

1. **ROS2 migration takvimi ne?** — EI-8'in zamanlaması bu cevaba bağlı.
2. **Cancellable olmayan arm primitive'lerinin listesi kesin mi?** — D1'in shim
   yük tahmini için kritik.
3. **`/safety/*` topic adları robot stack'inde kesin olarak nedir?** — A2'de
   config'e sabit isim koyuyoruz.
4. **`service-robot-chatbot` sisteminde dinamik tool manifest enjeksiyonu için
   yeni endpoint eklenebilir mi?** — D2 bağımlılığı.
5. **Yüz embedding'inin normalize edilmiş boyutu / modeli ne?** — F1 (persistent
   identity) için gerekli.
6. **Mic array donanımsal olarak aynı sürece erişilebilir mi, yoksa ROS topic
   abone olmak tek yol mu?** — C4'ün implementasyonunu değiştirir.
7. **Episodic memory şu an bir DB'de tutuluyor mu, yoksa uçucu mu?** — D5'in
   nasıl birleşeceğini belirler.
8. **Watchdog deadman'e voice-controller da heartbeat basmalı mı?** — Eğer evetse
   yeni bir runtime task; eğer hayırsa sadece dinleyici.
9. **Birden çok skill paralel çalıştırılabilir mi (örn. "look_at + move_to")?**
   — D3'ün paralel dispatch kararını belirler.
10. **HMI tablet'i voice-controller'dan ayrı bir UI mu, yoksa ortak event
    bus'a bağlanacak mı?** — A4 expression bridge'in kapsamını etkiler.

---

## 11. v1 vs v2 Kısa Karşılaştırma

| Boyut | v1 | v2 |
|---|---|---|
| Odak | voice-controller'ı MCP + async'e aç | voice-controller'ı embodied agent orchestrator'a evrilt |
| Perception varsayımı | sadece mic | mic + vision + DOA + proprio + world model |
| Tool execution | LLM service içinde MCP | hibrit: external MCP + lokal skill-adapter |
| World state | yok | EI-3 aggregator → snapshot JSON |
| Safety | ExternalStopSource placeholder | `/safety/*` topic ailesi ile bağlandı |
| State model | enum `TurnState` | component state matrisi (E1) |
| LLM context | user text | user text + world snapshot + tool manifest |
| Süre tahmini | 4-6 ay (T1+T2+FI) | **2-3 ay kritik yol, 4-5 ay tam** |
| Yeni LOC | ~1-2k | ~3-5k (yarısı ayrı ROS package) |

---

## 12. Sonraki Adımlar

1. Bu belgeyi ekip içinde **review**: Appendix E sorularına cevap topla.
2. Faz A'yı tek sprint içinde bitir (3-5 iş günü).
3. Faz B'yi paralel yürüt (servis göçü ayrı kişi alabilir).
4. C1 (`TurnTrigger`) için tasarım dokümanı — embodied tarafının temeli.
5. EI-1 adapter node için ayrı ROS repo'su veya aynı repo altında yeni paket
   kararı — robot stack ekibiyle koordine et.
