# Contributing to AR Voice Controller

Thanks for helping improve the voice dialog service behind Akinrobotics robots.
This guide is for **human developers**. If you are an AI coding agent, start
from [`AGENTS.md`](./AGENTS.md) instead — it captures the invariants that are
easy to miss.

## Scope

The voice-controller is evolving from a voice-only dialog service into an
**embodied agent orchestrator**. Near-term priorities live in
[`ROADMAP.md`](./docs/roadmaps/ROADMAP.md) (v1 — MCP and async tool calls), long-term
direction is in [`ROADMAP_v2.md`](./docs/roadmaps/ROADMAP_v2.md) (embodied integration:
perception, skills, world model, safety). Please skim both before proposing
larger changes so your work lands in the right phase.

## Prerequisites

- **Python 3.11** only. The vendored `aec-audio-processing` wheel is
  CPython 3.11 / Linux x86_64 — other Python versions will not resolve.
- **Linux** (POSIX audio and vendored wheels).
- System packages (Debian / Ubuntu):

  ```bash
  sudo apt install -y ffmpeg libportaudio2 portaudio19-dev
  ```

- [`uv`](https://docs.astral.sh/uv/) for Python + dependency management.
- Working microphone and speakers if you plan to run the full pipeline.
- An `OPENAI_API_KEY` (or local service endpoints — see roadmap FI / B phases).

## Getting the code running

```bash
git clone <repo> voice-controller
cd voice-controller
uv sync --group dev
uv run pre-commit install
cp .env.example .env   # if present; otherwise create one with OPENAI_API_KEY=
uv run ar-voice-controller --config config.yaml
```

In a second terminal, stream structured events:

```bash
uv run ar-voice-monitor
```

## Repository layout (quick map)

- `src/ar_voice_controller/audio/` — capture, VAD, interrupt detection, AEC.
- `src/ar_voice_controller/core/` — `TurnManager`, policies, cancellation,
  types. This is where dialog orchestration lives.
- `src/ar_voice_controller/providers/` — `Protocol`-typed clients for ASR,
  LLM, TTS. **Keep these swappable.**
- `src/ar_voice_controller/runtime/` — event bus, ROS backends, event types.
- `src/ar_voice_controller/telemetry/` — FIFO sink, `ar-voice-monitor`.
- `src/ar_voice_controller/pipeline.py` — wires everything together.
- `config/` (under `ar_voice_controller/`) + root `config.yaml` — layered
  config; `AVC_`-prefixed env vars override YAML (nested keys use `__`).
- `asr-api/`, `tts-api/`, `service-robot-chatbot/` — sibling services the
  voice-controller is migrating onto (see roadmap Phase B / FI-*).
- `ui/`, `examples/`, `vendor/` — web UI, demos, pinned wheels.

## Development workflow

1. **Branch** off `main`. Keep changes focused; prefer small MRs.
2. **Design before refactor.** For anything touching cancellation, interrupts,
   state machine, or provider contracts, open an issue or MR draft first —
   these are load-bearing and the roadmap has opinions about them.
3. **Code**, following the style rules below.
4. **Run pre-commit** locally before pushing:

   ```bash
   uv run pre-commit run --all-files
   ```

5. **Update [`CHANGELOG.md`](./CHANGELOG.md)** under `[Unreleased]` for any
   user-visible change. On a version bump, promote the `[Unreleased]` section
   to the new version and refresh the compare links.
6. **Open a merge request** against `main`. Link related roadmap items
   (e.g. "implements T1-5 / A2 safety bridge").

### Commit messages

Use [Conventional Commits](https://www.conventionalcommits.org/):
`type(scope): summary`. Common types: `feat`, `fix`, `refactor`, `docs`,
`test`, `chore`, `ci`. Keep the summary imperative and under ~72 chars.
The repo ships a `commit-message` skill under `.cursor/skills/` that can
propose one from staged changes.

### Code style

- **Type hints everywhere.** `ruff` runs with `ANN401` enabled — no
  unexplained `Any`.
- **`ruff` + `ruff-format`** enforce import order, lint, and formatting.
  Do not fight the formatter.
- **Cyclomatic complexity ≤ 20** (`complexipy`). If a function goes over,
  split it — usually a sign that the state machine or dispatch table needs
  to grow.
- Prefer **`dataclass(slots=True)`** for event payloads to keep the wire
  format cheap and typed.
- Public APIs in `providers/` should stay **`Protocol`-typed**; that is the
  single biggest reason the system can migrate to local HTTP services.

### Testing

The repo currently has minimal tests (see roadmap Tier 3 #13 / E3). When
you add them, use `pytest`, mirror the source layout under `tests/`, and
keep providers injectable so fakes can be plugged in. Priority targets:
cancellation propagation, interrupt arbitration, VAD debounce, policy
streaming, and safety-bridge → token-cancel paths.

## Architectural guardrails

Please honour these cross-cutting principles — they appear in both roadmaps
and are the reason the codebase stays tractable:

1. **Providers stay `Protocol`-based.** Do not add concrete imports across
   layer boundaries.
2. **Interrupts are topic-driven.** Publish to `/interrupt/requested`; never
   introduce side-channels or direct method calls for cancel.
3. **Prefer event-bus fan-out to method calls.** New cross-cutting features
   (tool events, safety, world snapshots) ride the bus.
4. **Instrument before refactoring.** Add event types first; the monitor
   auto-renders them.
5. **Voice-controller is not a real-time controller.** No low-level motor
   control in Python. Only `goal + cancel` against robot action servers.
6. **LLM context is structured.** World / tool / history data is JSON, not
   prompt-engineered prose.
7. **Wire format is migration-agnostic.** JSON payloads, not ROS message
   types — survives the ROS1 → ROS2 transition.

## Reporting issues

Use GitLab issues on this repo. For bugs, include: exact command, relevant
config section (secrets redacted), a recent `ar-voice-monitor` transcript,
and the `ar-voice-controller` logs. For larger proposals, reference the
roadmap item you are targeting so phases stay coherent.

## Releases

Releases are driven from GitLab CI (`.gitlab-ci.yml`). Tags matching
`v<major>.<minor>.<patch>` trigger `pypi` and `release` jobs that read the
matching section from `CHANGELOG.md`. Make sure the changelog entry exists
and is accurate **before** tagging.

## Code of conduct

Be kind. Assume good intent. Review code, not people.
