from __future__ import annotations

import queue
import threading
import time
from collections import defaultdict
from typing import Callable, Protocol

from .event_types import DroppedEvent

Handler = Callable[[str, object], None]
Spy = Callable[[str, object], None]


class Subscription(Protocol):
    def close(self) -> None: ...


class EventBus(Protocol):
    def publish(self, topic: str, event: object) -> None: ...

    def subscribe(
        self,
        topic: str | list[str],
        handler: Handler,
        *,
        queue_size: int = 256,
    ) -> Subscription: ...


class _Subscription:
    def __init__(
        self,
        bus: InProcessBus,
        topics: list[str],
        handler: Handler,
        queue_size: int,
    ) -> None:
        self._bus = bus
        self.topics = topics
        self.handler = handler
        self._queue: queue.Queue[tuple[str, object]] = queue.Queue(maxsize=queue_size)
        self._closed = threading.Event()
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def dispatch(self, topic: str, event: object) -> None:
        if self._closed.is_set():
            return
        try:
            self._queue.put_nowait((topic, event))
        except queue.Full:
            try:
                self._queue.get_nowait()
            except queue.Empty:
                pass
            try:
                self._queue.put_nowait((topic, event))
            except queue.Full:
                return
            if topic != "/system/dropped":
                self._bus.publish("/system/dropped", DroppedEvent(topic, 1))

    def _run(self) -> None:
        while not self._closed.is_set():
            try:
                topic, event = self._queue.get(timeout=0.1)
            except queue.Empty:
                continue
            try:
                self.handler(topic, event)
            except Exception:
                continue

    def close(self) -> None:
        self._closed.set()
        self._bus._remove(self)


class InProcessBus:
    def __init__(self) -> None:
        self._subscriptions: dict[str, list[_Subscription]] = defaultdict(list)
        self._lock = threading.Lock()
        self._spy: Spy | None = None

    def set_spy(self, spy: Spy | None) -> None:
        self._spy = spy

    def publish(self, topic: str, event: object) -> None:
        with self._lock:
            subscribers = list(self._subscriptions.get(topic, []))
        for subscription in subscribers:
            subscription.dispatch(topic, event)
        if self._spy is not None:
            try:
                self._spy(topic, event)
            except Exception:
                pass

    def subscribe(
        self,
        topic: str | list[str],
        handler: Handler,
        *,
        queue_size: int = 256,
    ) -> _Subscription:
        topics = [topic] if isinstance(topic, str) else topic
        subscription = _Subscription(self, topics, handler, queue_size)
        with self._lock:
            for name in topics:
                self._subscriptions[name].append(subscription)
        return subscription

    def _remove(self, subscription: _Subscription) -> None:
        with self._lock:
            for name in subscription.topics:
                subscribers = self._subscriptions.get(name)
                if not subscribers:
                    continue
                self._subscriptions[name] = [
                    item for item in subscribers if item is not subscription
                ]
                if not self._subscriptions[name]:
                    del self._subscriptions[name]

    def close(self, timeout: float = 1.0) -> None:
        deadline = time.time() + timeout
        with self._lock:
            subscriptions = {
                item
                for subscribers in self._subscriptions.values()
                for item in subscribers
            }
        for subscription in subscriptions:
            subscription.close()
        while time.time() < deadline:
            with self._lock:
                if not self._subscriptions:
                    return
            time.sleep(0.01)
