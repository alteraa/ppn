from __future__ import annotations

import queue
import threading
import time

from .event_types import DroppedEvent, decode_event, encode_event
from .events import Handler, Subscription
from .ros_backends import RosVersion, _RosBackend, select_backend


class _RosSubscription:
    def __init__(
        self,
        bus: "RosBus",
        topics: list[str],
        handler: Handler,
        queue_size: int,
    ) -> None:
        self._bus = bus
        self.topics = topics
        self.handler = handler
        self._queue: queue.Queue[tuple[str, object]] = queue.Queue(maxsize=queue_size)
        self._closed = threading.Event()
        self._ros_handles: list[object] = []
        self._thread = threading.Thread(target=self._run, daemon=True)

    def start(self) -> None:
        backend: _RosBackend = self._bus._backend
        for topic in self.topics:
            ros_topic = self._bus._resolve(topic)

            def callback(payload: str, topic: str = topic) -> None:
                self._dispatch(topic, decode_event(payload))

            handle = backend.subscribe(ros_topic, callback, self._queue.maxsize or 10)
            self._ros_handles.append(handle)
        self._thread.start()

    def _dispatch(self, topic: str, event: object) -> None:
        if self._closed.is_set():
            return
        try:
            self._queue.put_nowait((topic, event))
        except queue.Full:
            try:
                self._queue.get_nowait()
            except queue.Empty:
                pass
            try:
                self._queue.put_nowait((topic, event))
            except queue.Full:
                return
            if topic != "/system/dropped":
                self._bus.publish("/system/dropped", DroppedEvent(topic, 1))

    def _run(self) -> None:
        while not self._closed.is_set():
            try:
                topic, event = self._queue.get(timeout=0.1)
            except queue.Empty:
                continue
            try:
                self.handler(topic, event)
            except Exception:
                continue

    def close(self) -> None:
        if self._closed.is_set():
            return
        self._closed.set()
        backend: _RosBackend = self._bus._backend
        for handle in self._ros_handles:
            backend.close_subscription(handle)
        self._ros_handles.clear()
        self._bus._remove(self)


class RosBus:
    def __init__(
        self,
        *,
        ros_version: RosVersion = "auto",
        node_name: str = "ar_voice_controller",
        namespace: str = "/ar_voice_controller",
        default_publisher_queue_size: int = 32,
    ) -> None:
        self._backend: _RosBackend = select_backend(ros_version, node_name)
        self._namespace = namespace.rstrip("/")
        self._pub_queue_size = default_publisher_queue_size
        self._publishers: dict[str, object] = {}
        self._subscriptions: list[_RosSubscription] = []
        self._lock = threading.Lock()
        self._closed = False

    @property
    def ros_version(self) -> str:
        return self._backend.version

    def _resolve(self, topic: str) -> str:
        if topic.startswith("/"):
            return f"{self._namespace}{topic}"
        return f"{self._namespace}/{topic}"

    def _get_publisher(self, ros_topic: str) -> object:
        with self._lock:
            pub = self._publishers.get(ros_topic)
            if pub is None:
                pub = self._backend.make_publisher(ros_topic, self._pub_queue_size)
                self._publishers[ros_topic] = pub
            return pub

    def publish(self, topic: str, event: object) -> None:
        if self._closed:
            return
        ros_topic = self._resolve(topic)
        payload = encode_event(event)
        publisher = self._get_publisher(ros_topic)
        self._backend.publish(publisher, payload)

    def subscribe(
        self,
        topic: str | list[str],
        handler: Handler,
        *,
        queue_size: int = 256,
    ) -> Subscription:
        if self._closed:
            raise RuntimeError("RosBus is closed")
        topics = [topic] if isinstance(topic, str) else list(topic)
        subscription = _RosSubscription(self, topics, handler, queue_size)
        with self._lock:
            self._subscriptions.append(subscription)
        subscription.start()
        return subscription

    def _remove(self, subscription: _RosSubscription) -> None:
        with self._lock:
            try:
                self._subscriptions.remove(subscription)
            except ValueError:
                pass

    def close(self, timeout: float = 1.0) -> None:
        if self._closed:
            return
        self._closed = True
        with self._lock:
            subs = list(self._subscriptions)
        for sub in subs:
            sub.close()
        deadline = time.time() + timeout
        while time.time() < deadline:
            with self._lock:
                if not self._subscriptions:
                    break
            time.sleep(0.01)
        self._backend.shutdown()
