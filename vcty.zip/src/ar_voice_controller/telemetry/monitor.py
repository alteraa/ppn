"""ar-voice-monitor — real-time event bus viewer.

Reads JSON lines from the FIFO written by FifoSink and prints them in a
coloured, human-readable format.

Usage::

    ar-voice-monitor            # default path /tmp/voice_bus
    ar-voice-monitor --path /tmp/my_bus
    ar-voice-monitor --json     # raw JSON output (for piping / grep)
"""

from __future__ import annotations

import argparse
import datetime
import json
import sys
import time

FIFO_PATH = "/tmp/voice_bus"

RESET = "\033[0m"
BOLD = "\033[1m"
DIM = "\033[2m"

_TOPIC_COLORS: dict[str, str] = {
    "/audio/": "\033[36m",  # cyan
    "/asr/": "\033[34m",  # blue
    "/llm/": "\033[95m",  # bright magenta
    "/dialog/assistant/": "\033[35m",  # magenta
    "/dialog/turn/": "\033[33m",  # yellow
    "/tts/audio_frame": "\033[90m",  # dark grey  (high-frequency, keep subtle)
    "/tts/": "\033[32m",  # green
    "/interrupt/": "\033[31m",  # red
    "/error": "\033[91m",  # bright red
    "/service/": "\033[96m",  # bright cyan
    "/metrics/": "\033[90m",  # dark grey
    "/system/": "\033[90m",  # dark grey
}


def _color_for(topic: str) -> str:
    for prefix, color in _TOPIC_COLORS.items():
        if topic.startswith(prefix) or topic == prefix.rstrip("/"):
            return color
    return "\033[37m"  # white


def _format_pretty(obj: dict) -> str:
    topic = obj.get("topic", "?")
    type_name = obj.get("type", "")
    data = obj.get("data", {})
    color = _color_for(topic)
    ts = datetime.datetime.now().strftime("%H:%M:%S.%f")[:-3]

    data_str = ""
    if isinstance(data, dict):
        parts = [f"{k}={v!r}" for k, v in data.items()]
        data_str = "  " + "  ".join(parts) if parts else ""
    elif data is not None:
        data_str = f"  {data!r}"

    return f"{DIM}{ts}{RESET}  {color}{BOLD}{topic:<40}{RESET}  {DIM}{type_name}{RESET}{data_str}"


def _parse_monitor_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog="ar-voice-monitor",
        description="Real-time ar-voice-controller event bus viewer",
    )
    parser.add_argument(
        "--path",
        default=FIFO_PATH,
        help=f"FIFO path (default: {FIFO_PATH})",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        dest="raw_json",
        help="Print raw JSON lines instead of formatted output",
    )
    parser.add_argument(
        "--topic",
        metavar="PREFIX",
        help="Only show events whose topic starts with PREFIX",
    )
    return parser.parse_args()


def _print_monitor_line(args: argparse.Namespace, line: str, obj: dict) -> None:
    if args.topic and not obj.get("topic", "").startswith(args.topic):
        return
    if args.raw_json:
        print(line)
    else:
        print(_format_pretty(obj))


def _stream_fifo_lines(args: argparse.Namespace) -> None:
    with open(args.path) as fh:
        print("Connected — streaming events.", file=sys.stderr)
        for line in fh:
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError:
                print(line)
                continue
            _print_monitor_line(args, line, obj)
        print("Connection closed — waiting for reconnect …", file=sys.stderr)


def _monitor_forever(args: argparse.Namespace) -> None:
    while True:
        try:
            _stream_fifo_lines(args)
        except KeyboardInterrupt:
            sys.exit(0)
        except OSError:
            time.sleep(0.5)


def main() -> None:
    args = _parse_monitor_args()
    print(
        f"Waiting for ar-voice-controller on {args.path} … (Ctrl-C to quit)",
        file=sys.stderr,
    )
    _monitor_forever(args)


if __name__ == "__main__":
    main()
