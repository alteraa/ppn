"""
Unit specs for the event wire-format feature.

Feature under test: ``encode_event`` / ``decode_event`` — JSON dataclass
payloads are the project's wire format (AGENTS.md invariant #7: "must
survive the ROS1 → ROS2 migration unchanged"). These tests pin the
roundtrip contract independent of the transport that carries the bytes.

Source: ``ar_voice_controller.runtime.event_types``
"""

from __future__ import annotations

import json

import pytest

from ar_voice_controller.runtime.event_types import (
    EVENT_TYPES,
    AssistantDone,
    AssistantSegment,
    DroppedEvent,
    ErrorEvent,
    FinalTranscript,
    InterruptHonored,
    InterruptRequested,
    LlmTextDelta,
    ServiceStateChanged,
    TurnMetrics,
    TurnStateChanged,
    UserSpeechDetected,
    UserSpeechEnded,
    decode_event,
    encode_event,
)


@pytest.fixture
def sample_events() -> list[object]:
    """One representative instance of each commonly-published event type."""
    return [
        ServiceStateChanged(previous="idle", current="ready"),
        TurnStateChanged(turn_id=1, previous="IDLE", current="LISTENING", at=1.5),
        UserSpeechDetected(turn_id=1, at=1.25),
        UserSpeechEnded(turn_id=1, duration_ms=420.0),
        FinalTranscript(turn_id=1, text="merhaba", language="tr", latency_ms=180.0),
        LlmTextDelta(turn_id=1, text="he", index=1),
        AssistantSegment(turn_id=1, text="hello.", language="en", index=1),
        AssistantDone(turn_id=1, full_text="hello.", language="en"),
        InterruptRequested(source="voice", cause="voice_barge_in", priority=5, at=2.0),
        InterruptHonored(turn_id=1, cause="voice_barge_in", at=2.1),
        TurnMetrics(turn_id=1, metrics={"asr_ms": 120, "llm_ms": 300, "tts_ms": None}),
        ErrorEvent(component="llm", detail="timeout", recoverable=True),
        DroppedEvent(topic="/llm/text_delta", dropped_count=3),
    ]


class TestEncodeDecodeRoundtrip:
    """Feature: every known event survives an encode → decode roundtrip."""

    def test_encoded_payload_is_valid_json(self, sample_events):
        for event in sample_events:
            payload = encode_event(event)
            json.loads(payload)

    def test_encoded_payload_has_type_tag_and_data(self, sample_events):
        for event in sample_events:
            obj = json.loads(encode_event(event))
            assert obj["__type__"] == type(event).__name__
            assert "data" in obj

    def test_roundtrip_preserves_type(self, sample_events):
        for event in sample_events:
            decoded = decode_event(encode_event(event))
            assert type(decoded) is type(event)

    def test_roundtrip_preserves_value_equality(self, sample_events):
        for event in sample_events:
            decoded = decode_event(encode_event(event))
            assert decoded == event


class TestEventTypesRegistry:
    """Feature: the ``EVENT_TYPES`` registry drives decoding."""

    def test_registry_keys_match_class_names(self):
        for name, cls in EVENT_TYPES.items():
            assert cls.__name__ == name

    def test_every_registered_type_roundtrips_via_registry(self):
        for cls in EVENT_TYPES.values():
            decoded = decode_event(
                json.dumps(
                    {
                        "__type__": cls.__name__,
                        "data": _default_data_for(cls),
                    }
                )
            )
            assert type(decoded) is cls


class TestDecodeFallbacks:
    """Feature: decoder degrades gracefully for unknown or malformed payloads."""

    def test_unknown_type_returns_raw_data(self):
        payload = json.dumps({"__type__": "NotARealEvent", "data": {"x": 1}})
        assert decode_event(payload) == {"x": 1}

    def test_raw_type_returns_raw_data(self):
        payload = json.dumps({"__type__": "raw", "data": [1, 2, 3]})
        assert decode_event(payload) == [1, 2, 3]

    def test_missing_type_tag_returns_raw_data(self):
        payload = json.dumps({"data": {"hello": "world"}})
        assert decode_event(payload) == {"hello": "world"}

    def test_mismatched_fields_fall_back_to_raw_data(self):
        payload = json.dumps(
            {
                "__type__": "FinalTranscript",
                "data": {"totally": "wrong", "shape": True},
            }
        )
        result = decode_event(payload)
        assert result == {"totally": "wrong", "shape": True}


class TestEncodeNonDataclass:
    """Feature: encoding a plain object produces a ``raw`` payload."""

    def test_plain_dict_is_encoded_as_raw(self):
        payload = encode_event({"hello": "world"})
        obj = json.loads(payload)
        assert obj["__type__"] == "raw"
        assert obj["data"] == {"hello": "world"}

    def test_plain_string_is_encoded_as_raw(self):
        payload = encode_event("a string event")
        obj = json.loads(payload)
        assert obj["__type__"] == "raw"
        assert obj["data"] == "a string event"


def _default_data_for(cls: type) -> dict:
    """Produce a minimal-but-valid kwargs dict for any registered event class.

    Kept local to the test to avoid leaking test scaffolding into production.
    """
    from dataclasses import fields

    defaults: dict[str, object] = {
        "turn_id": 0,
        "previous": "",
        "current": "",
        "at": 0.0,
        "duration_ms": 0.0,
        "text": "",
        "language": "",
        "latency_ms": 0.0,
        "index": 0,
        "full_text": "",
        "rms": 0.0,
        "frame_index": 0,
        "source": "",
        "cause": "",
        "priority": 0,
        "metrics": {},
        "name": "",
        "arguments": {},
        "result": None,
        "component": "",
        "detail": "",
        "recoverable": False,
        "topic": "",
        "dropped_count": 0,
    }
    return {field.name: defaults.get(field.name) for field in fields(cls)}
