"""
Unit specs for the LLM provider feature.

Feature under test: ``OpenAiLlmClient.chat_stream`` — the adapter that turns
an OpenAI-style streaming response into the project's ``LlmDelta`` sequence.
The model (API) boundary is mocked so we verify the orchestration logic
(cancellation hooks, delta classification, stream cleanup) without hitting
the network. When a different backend is wired in (FI-2), this spec moves
with the feature because it asserts on the ``LlmDelta`` protocol, not on
OpenAI specifics.

Source: ``ar_voice_controller.providers.llm``
"""

from __future__ import annotations

import pytest

pytestmark = pytest.mark.requires_openai

pytest.importorskip("openai", reason="openai SDK not installed")

from pathlib import Path  # noqa: E402
from unittest.mock import MagicMock  # noqa: E402

from ar_voice_controller.config import LlmCfg  # noqa: E402
from ar_voice_controller.core.cancellation import (  # noqa: E402
    CancellationError,
    CancellationToken,
    InterruptCause,
)
from ar_voice_controller.providers.llm import (  # noqa: E402
    ContentDelta,
    DoneDelta,
    InMemoryHistory,
    OpenAiLlmClient,
    ToolCallDelta,
    build_messages,
)


def _make_chunk(content: str | None = None, tool_calls: list | None = None):
    """Build a fake OpenAI streaming chunk with the attributes the adapter reads."""
    chunk = MagicMock()
    chunk.choices = [MagicMock()]
    chunk.choices[0].delta.content = content
    chunk.choices[0].delta.tool_calls = tool_calls
    return chunk


@pytest.fixture
def system_prompt_file(tmp_path: Path) -> Path:
    path = tmp_path / "system.md"
    path.write_text("You are a helpful assistant.\n", encoding="utf-8")
    return path


@pytest.fixture
def llm_config(system_prompt_file: Path) -> LlmCfg:
    return LlmCfg(
        base_url="http://stub",
        api_key="stub-key",
        model="stub-model",
        timeout_sec=5.0,
        system_prompt_path=str(system_prompt_file),
    )


@pytest.fixture
def client(llm_config: LlmCfg) -> OpenAiLlmClient:
    """Client instance with the OpenAI SDK replaced by a MagicMock."""
    instance = OpenAiLlmClient(llm_config)
    instance.client = MagicMock()
    return instance


def _set_stream(client: OpenAiLlmClient, chunks: list) -> MagicMock:
    """Configure the stub OpenAI client to return the given chunks from stream."""
    stream = MagicMock()
    stream.__iter__.return_value = iter(chunks)
    client.client.chat.completions.create.return_value = stream
    return stream


class TestSystemPromptLoading:
    def test_system_prompt_is_read_and_stripped(self, client: OpenAiLlmClient):
        assert client.system_prompt == "You are a helpful assistant."


class TestChatStreamContent:
    def test_yields_content_delta_for_each_non_empty_chunk(
        self, client: OpenAiLlmClient
    ):
        _set_stream(
            client,
            [_make_chunk(content="Hel"), _make_chunk(content="lo")],
        )
        deltas = list(client.chat_stream([], token=CancellationToken()))
        content_deltas = [d for d in deltas if isinstance(d, ContentDelta)]
        assert [d.text for d in content_deltas] == ["Hel", "lo"]

    def test_always_terminates_with_done_delta(self, client: OpenAiLlmClient):
        _set_stream(client, [_make_chunk(content="hi")])
        deltas = list(client.chat_stream([], token=CancellationToken()))
        assert isinstance(deltas[-1], DoneDelta)

    def test_empty_content_chunks_are_skipped(self, client: OpenAiLlmClient):
        _set_stream(
            client,
            [
                _make_chunk(content=None),
                _make_chunk(content=""),
                _make_chunk(content="real"),
            ],
        )
        deltas = list(client.chat_stream([], token=CancellationToken()))
        content_deltas = [d for d in deltas if isinstance(d, ContentDelta)]
        assert [d.text for d in content_deltas] == ["real"]


class TestChatStreamToolCalls:
    def test_tool_calls_yield_tool_call_deltas(self, client: OpenAiLlmClient):
        tool_call = MagicMock(name="tool_call_1")
        _set_stream(client, [_make_chunk(tool_calls=[tool_call])])
        deltas = list(client.chat_stream([], token=CancellationToken()))
        tool_deltas = [d for d in deltas if isinstance(d, ToolCallDelta)]
        assert len(tool_deltas) == 1
        assert tool_deltas[0].raw is tool_call

    def test_content_and_tool_calls_coexist_in_one_chunk(self, client: OpenAiLlmClient):
        tool_call = MagicMock()
        _set_stream(
            client,
            [_make_chunk(content="answer", tool_calls=[tool_call])],
        )
        deltas = list(client.chat_stream([], token=CancellationToken()))
        types = [type(d).__name__ for d in deltas]
        assert types == ["ContentDelta", "ToolCallDelta", "DoneDelta"]


class TestCancellation:
    def test_raises_before_any_api_call_when_already_cancelled(
        self, client: OpenAiLlmClient
    ):
        token = CancellationToken()
        token.cancel(InterruptCause.VOICE_BARGE_IN)
        with pytest.raises(CancellationError):
            list(client.chat_stream([], token=token))
        client.client.chat.completions.create.assert_not_called()

    def test_raises_between_chunks_when_cancelled_mid_stream(
        self, client: OpenAiLlmClient
    ):
        token = CancellationToken()

        def _chunks():
            yield _make_chunk(content="first")
            token.cancel(InterruptCause.EXTERNAL_STOP)
            yield _make_chunk(content="never-reached")

        stream = MagicMock()
        stream.__iter__.return_value = _chunks()
        client.client.chat.completions.create.return_value = stream

        with pytest.raises(CancellationError):
            list(client.chat_stream([], token=token))


class TestStreamCleanup:
    def test_stream_close_is_called_when_stream_exposes_close(
        self, client: OpenAiLlmClient
    ):
        stream = _set_stream(client, [_make_chunk(content="x")])
        list(client.chat_stream([], token=CancellationToken()))
        stream.close.assert_called_once()

    def test_stream_close_is_called_on_cancellation(self, client: OpenAiLlmClient):
        token = CancellationToken()
        token.cancel(InterruptCause.TIMEOUT)

        stream = MagicMock()
        stream.__iter__.return_value = iter([])
        client.client.chat.completions.create.return_value = stream

        with pytest.raises(CancellationError):
            list(client.chat_stream([], token=token))
        client.client.chat.completions.create.assert_not_called()


class TestRequestArguments:
    def test_request_uses_configured_model_when_override_is_none(
        self, client: OpenAiLlmClient
    ):
        _set_stream(client, [])
        list(
            client.chat_stream(
                [{"role": "user", "content": "hi"}],
                token=CancellationToken(),
            )
        )
        kwargs = client.client.chat.completions.create.call_args.kwargs
        assert kwargs["model"] == "stub-model"
        assert kwargs["stream"] is True

    def test_request_honors_explicit_model_override(self, client: OpenAiLlmClient):
        _set_stream(client, [])
        list(
            client.chat_stream(
                [{"role": "user", "content": "hi"}],
                token=CancellationToken(),
                model="override-model",
            )
        )
        assert (
            client.client.chat.completions.create.call_args.kwargs["model"]
            == "override-model"
        )

    def test_tools_kwarg_defaults_to_none_when_empty(self, client: OpenAiLlmClient):
        _set_stream(client, [])
        list(client.chat_stream([], token=CancellationToken()))
        assert client.client.chat.completions.create.call_args.kwargs["tools"] is None


class TestBuildMessagesFeature:
    """Feature: prompt composition is pure and stable across provider swaps."""

    def test_system_prompt_is_first_message(self):
        history = InMemoryHistory()
        messages = build_messages("SYS", history, "hello", language_tag="tr")
        assert messages[0] == {"role": "system", "content": "SYS"}

    def test_user_message_is_last_and_language_tagged(self):
        history = InMemoryHistory()
        messages = build_messages("SYS", history, "hello", language_tag="en")
        assert messages[-1] == {"role": "user", "content": "[en]: hello"}

    def test_history_snapshot_is_inserted_between_system_and_user(self):
        history = InMemoryHistory()
        history.add({"role": "user", "content": "prev-user"})
        history.add({"role": "assistant", "content": "prev-asst"})
        messages = build_messages("SYS", history, "now", language_tag="tr")
        assert [m["role"] for m in messages] == [
            "system",
            "user",
            "assistant",
            "user",
        ]
