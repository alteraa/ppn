from __future__ import annotations

from ..providers.llm import ContentDelta, DoneDelta, MessageHistory, OpenAiLlmClient, build_messages
from ..providers.text_utils import drain_completed_sentences, drain_partial_tts_segments, split_sentence_for_tts
from ..providers.tts_player import TTSPlayer
from ..config import Settings
from ..runtime.event_types import AssistantDone, AssistantSegment, LlmTextDelta
from ..runtime.events import EventBus
from .types import PolicyResult, TurnContext


class StreamingLlmPolicy:
    def __init__(
        self,
        llm_client: OpenAiLlmClient,
        tts_player: TTSPlayer,
        history: MessageHistory,
        bus: EventBus,
        settings: Settings,
    ) -> None:
        self.llm_client = llm_client
        self.tts_player = tts_player
        self.history = history
        self.bus = bus
        self.settings = settings

    def run(self, ctx: TurnContext) -> PolicyResult:
        messages = build_messages(
            self.llm_client.system_prompt,
            self.history,
            ctx.transcript.text,
            language_tag=ctx.transcript.language or "tr",
        )
        self.history.add({"role": "user", "content": ctx.transcript.text})

        full_text_parts: list[str] = []
        sentence_buffer = ""
        emitted_segments = 0
        delta_index = 0
        tts_started = False

        for delta in self.llm_client.chat_stream(messages, token=ctx.token):
            ctx.token.raise_if_cancelled()
            if isinstance(delta, DoneDelta):
                break
            if not isinstance(delta, ContentDelta):
                continue
            text = delta.text
            if not text:
                continue

            delta_index += 1
            self.bus.publish(
                "/llm/text_delta",
                LlmTextDelta(turn_id=ctx.turn_id, text=text, index=delta_index),
            )

            full_text_parts.append(text)
            sentence_buffer += text
            ready_partials, sentence_buffer = drain_partial_tts_segments(
                sentence_buffer,
                min_chars=self.settings.llm.min_tts_segment_chars,
                target_chars=self.settings.llm.target_tts_segment_chars,
                max_chars=self.settings.llm.max_tts_segment_chars,
            )
            for partial in ready_partials:
                if not tts_started:
                    self.tts_player.start_stream(ctx.turn_id, ctx.token)
                    tts_started = True
                emitted_segments += 1
                self.bus.publish(
                    "/dialog/assistant/segment",
                    AssistantSegment(
                        turn_id=ctx.turn_id,
                        text=partial,
                        language=ctx.transcript.language,
                        index=emitted_segments,
                    ),
                )
                self.tts_player.enqueue_segment(
                    ctx.turn_id,
                    ctx.token,
                    partial,
                    index=emitted_segments,
                    language=ctx.transcript.language or "tr",
                )

            ready_sentences, sentence_buffer = drain_completed_sentences(sentence_buffer)
            for sentence in ready_sentences:
                for segment in split_sentence_for_tts(
                    sentence,
                    min_chars=self.settings.llm.min_tts_segment_chars,
                    max_chars=self.settings.llm.max_tts_segment_chars,
                ):
                    if not tts_started:
                        self.tts_player.start_stream(ctx.turn_id, ctx.token)
                        tts_started = True
                    emitted_segments += 1
                    self.bus.publish(
                        "/dialog/assistant/segment",
                        AssistantSegment(
                            turn_id=ctx.turn_id,
                            text=segment,
                            language=ctx.transcript.language,
                            index=emitted_segments,
                        ),
                    )
                    self.tts_player.enqueue_segment(
                        ctx.turn_id,
                        ctx.token,
                        segment,
                        index=emitted_segments,
                        language=ctx.transcript.language or "tr",
                    )

        if sentence_buffer.strip():
            for segment in split_sentence_for_tts(
                sentence_buffer.strip(),
                min_chars=self.settings.llm.min_tts_segment_chars,
                max_chars=self.settings.llm.max_tts_segment_chars,
            ):
                if not tts_started:
                    self.tts_player.start_stream(ctx.turn_id, ctx.token)
                    tts_started = True
                emitted_segments += 1
                self.bus.publish(
                    "/dialog/assistant/segment",
                    AssistantSegment(
                        turn_id=ctx.turn_id,
                        text=segment,
                        language=ctx.transcript.language,
                        index=emitted_segments,
                    ),
                )
                self.tts_player.enqueue_segment(
                    ctx.turn_id,
                    ctx.token,
                    segment,
                    index=emitted_segments,
                    language=ctx.transcript.language or "tr",
                )

        full_text = "".join(full_text_parts).strip()
        if tts_started:
            self.tts_player.finish_stream(
                ctx.turn_id,
                ctx.token,
                language=ctx.transcript.language or "tr",
            )

        if full_text:
            self.history.add({"role": "assistant", "content": full_text})
            self.bus.publish(
                "/dialog/assistant/done",
                AssistantDone(
                    turn_id=ctx.turn_id,
                    full_text=full_text,
                    language=ctx.transcript.language,
                ),
            )

        return PolicyResult(full_text=full_text, emitted_segments=emitted_segments)
