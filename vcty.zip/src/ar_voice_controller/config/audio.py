from __future__ import annotations

from typing import Literal

from pydantic import BaseModel


class AudioCfg(BaseModel):
    channels: int = 1
    sample_rate: int = 16000
    num_samples: int = 1536
    input_queue_max_chunks: int = 64
    max_status_logs: int = 10
    aec_delay_ms: int = 60
    aec_frame_size: int = 160
    stream_latency: Literal["low", "high"] = "high"
    playback_pre_buffer_ms: int = 200


class VadCfg(BaseModel):
    model_path: str = "/opt/akinrobotics/share/asr_models/snakers4_silero-vad_master"
    speak_threshold: float = 0.5
    start_rms_multiplier: float = 2.2
    min_start_rms: float = 180.0
    max_start_crest_factor: float = 6.5
    before_chunks_sec: float = 0.8
    after_chunks_sec: float = 0.5
    debounce_sec: float = 0.3
    onnx_intra_op_num_threads: int = 2
    onnx_inter_op_num_threads: int = 1


class InterruptCfg(BaseModel):
    rms_multiplier: float = 2.5
    vad_threshold: float = 0.7
    hold_chunks: int = 3
    grace_period_sec: float = 1.0
    processing_grace_period_sec: float = 0.8
    baseline_window: int = 40
    post_tts_ignore_chunks: int = 8
