from __future__ import annotations

import time
from collections import deque
from typing import Protocol

import numpy as np

from ..core.cancellation import CancellationToken, InterruptCause
from ..config import InterruptCfg
from ..runtime.event_types import InterruptHonored, InterruptRequested
from ..runtime.events import EventBus
from .utils import rms


class InterruptSource(Protocol):
    def start(self, bus: EventBus) -> None: ...

    def stop(self) -> None: ...


class InterruptDetector:
    def __init__(self, config: InterruptCfg, vad_confidence):
        self.config = config
        self.vad_confidence = vad_confidence
        self._rolling: deque[float] = deque(maxlen=self.config.baseline_window)
        self._frozen_baseline: float | None = None
        self._counter = 0

    def freeze_baseline(self) -> None:
        if len(self._rolling) >= 5:
            self._frozen_baseline = float(np.mean(self._rolling))
        else:
            self._frozen_baseline = None
        self._counter = 0

    def reset(self) -> None:
        self._counter = 0
        self._frozen_baseline = None
        self._rolling.clear()

    def feed_rolling(self, audio_chunk: bytes) -> None:
        self._rolling.append(rms(audio_chunk))

    def current_baseline(self) -> float:
        if len(self._rolling) >= 5:
            return float(np.mean(self._rolling))
        return 80.0

    def update(self, audio_chunk: bytes) -> bool:
        current_rms = rms(audio_chunk)
        current_vad = self.vad_confidence(audio_chunk)

        baseline = self._frozen_baseline
        if baseline is None or baseline < 10:
            baseline = max(baseline or 0, 80.0)

        threshold = baseline * self.config.rms_multiplier
        rms_ok = current_rms > threshold
        vad_ok = current_vad > self.config.vad_threshold

        if rms_ok and vad_ok:
            self._counter += 1
        else:
            self._counter = 0

        if self._counter >= self.config.hold_chunks:
            self.reset()
            return True
        return False


class AudioInterruptSource:
    def __init__(self, detector: InterruptDetector):
        self.detector = detector
        self.bus: EventBus | None = None

    def start(self, bus: EventBus) -> None:
        self.bus = bus

    def stop(self) -> None:
        self.bus = None

    def maybe_emit(self, audio_chunk: bytes) -> bool:
        if self.bus is None:
            return False
        if not self.detector.update(audio_chunk):
            return False
        self.bus.publish(
            "/interrupt/requested",
            InterruptRequested(
                source="voice",
                cause=InterruptCause.VOICE_BARGE_IN.value,
                priority=50,
                at=time.time(),
            ),
        )
        return True


class ExternalStopSource:
    def __init__(self, bus: EventBus):
        self.bus = bus

    def trigger(self, cause: InterruptCause = InterruptCause.EXTERNAL_STOP) -> None:
        self.bus.publish(
            "/interrupt/requested",
            InterruptRequested(
                source="external",
                cause=cause.value,
                priority=80,
                at=time.time(),
            ),
        )


class InterruptArbiter:
    def __init__(self, bus: EventBus):
        self.bus = bus
        self._active_turn_id: int | None = None
        self._active_token: CancellationToken | None = None
        self._subscription = self.bus.subscribe(
            "/interrupt/requested", self._handle_request
        )

    def set_active(self, turn_id: int | None, token: CancellationToken | None) -> None:
        self._active_turn_id = turn_id
        self._active_token = token

    def _handle_request(self, topic: str, event: InterruptRequested) -> None:
        del topic
        if self._active_token is None:
            return
        try:
            cause = InterruptCause(event.cause)
        except ValueError:
            cause = InterruptCause.EXTERNAL_STOP
        self._active_token.cancel(cause)
        self.bus.publish(
            "/interrupt/honored",
            InterruptHonored(
                turn_id=self._active_turn_id,
                cause=cause.value,
                at=time.time(),
            ),
        )

    def close(self) -> None:
        self._subscription.close()
