"""FIFO-based bus spy.

The sink writes every published event as a JSON line to a named pipe so an
external process (e.g. ``ar-voice-monitor``) can consume them in real-time
without any overhead when no reader is attached.

Usage (from Pipeline or make_event_bus)::

    sink = FifoSink()
    bus.set_spy(sink.write)
    # on shutdown:
    sink.close()
"""

from __future__ import annotations

import errno
import json
import os
import queue
import stat
import threading
import time
from dataclasses import asdict, is_dataclass
from typing import Any

DEFAULT_PATH = "/tmp/voice_bus"

_SENTINEL = object()


class FifoSink:
    def __init__(self, path: str = DEFAULT_PATH) -> None:
        self._path = path
        self._queue: queue.Queue[tuple[str, str] | object] = queue.Queue(maxsize=512)
        self._thread = threading.Thread(target=self._run, daemon=True, name="fifo-sink")
        self._closed = False
        self._ensure_fifo()
        self._thread.start()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def write(self, topic: str, event: Any) -> None:
        if self._closed:
            return
        try:
            payload = self._encode(topic, event)
            self._queue.put_nowait((topic, payload))
        except queue.Full:
            pass
        except Exception:
            pass

    def close(self) -> None:
        self._closed = True
        try:
            self._queue.put_nowait(_SENTINEL)
        except queue.Full:
            pass
        self._thread.join(timeout=2.0)

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _ensure_fifo(self) -> None:
        if os.path.exists(self._path):
            if not stat.S_ISFIFO(os.stat(self._path).st_mode):
                os.remove(self._path)
                os.mkfifo(self._path)
        else:
            os.mkfifo(self._path)

    def _run(self) -> None:
        fd: int | None = None
        pending: list[str] = []

        while not self._closed:
            # Try to open the FIFO for writing (non-blocking: fails if no reader).
            if fd is None:
                try:
                    fd = os.open(self._path, os.O_WRONLY | os.O_NONBLOCK)
                except OSError as exc:
                    if exc.errno in (errno.ENXIO, errno.ENOENT):
                        # No reader connected yet — wait a bit and retry.
                        time.sleep(0.2)
                        continue
                    time.sleep(0.5)
                    continue

            # Drain the queue into pending buffer first.
            while True:
                try:
                    item = self._queue.get_nowait()
                except queue.Empty:
                    break
                if item is _SENTINEL:
                    self._try_close_fd(fd)
                    return
                _topic, payload = item  # type: ignore[misc]
                pending.append(payload + "\n")

            # Flush pending writes to the FIFO.
            if not pending:
                # Nothing to write — small sleep to avoid busy-loop.
                time.sleep(0.05)
                continue

            to_write = "".join(pending)
            pending.clear()
            try:
                os.write(fd, to_write.encode())
            except OSError:
                # Reader disconnected — close and wait for next reader.
                self._try_close_fd(fd)
                fd = None

        self._try_close_fd(fd)

    @staticmethod
    def _try_close_fd(fd: int | None) -> None:
        if fd is not None:
            try:
                os.close(fd)
            except OSError:
                pass

    @staticmethod
    def _encode(topic: str, event: Any) -> str:
        if is_dataclass(event) and not isinstance(event, type):
            data = asdict(event)
        else:
            data = event
        return json.dumps(
            {"topic": topic, "type": type(event).__name__, "data": data},
            default=str,
        )
