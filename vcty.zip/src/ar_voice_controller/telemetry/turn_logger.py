from __future__ import annotations

import threading
import time

from ..runtime.event_types import (
    AssistantDone,
    AssistantSegment,
    ErrorEvent,
    FinalTranscript,
    InterruptHonored,
    TtsPlaybackEnded,
    TtsPlaybackStarted,
    TurnMetrics,
    TurnStateChanged,
    UserSpeechDetected,
    UserSpeechEnded,
)
from ..runtime.events import EventBus
from .._ansi import BLUE, CYAN, GREEN, MAGENTA, RED, YELLOW
from .plain_logger import log_stage


class TurnLogger:
    def __init__(self, bus: EventBus):
        self._lock = threading.Lock()
        self._data: dict[int, dict[str, float | int | None]] = {}
        self._bus = bus
        self._subscriptions = [
            bus.subscribe("/audio/speech_detected", self._on_speech_detected),
            bus.subscribe("/audio/speech_ended", self._on_speech_ended),
            bus.subscribe("/asr/final", self._on_asr_final),
            bus.subscribe("/dialog/assistant/segment", self._on_assistant_segment),
            bus.subscribe("/dialog/assistant/done", self._on_assistant_done),
            bus.subscribe("/tts/playback_started", self._on_tts_started),
            bus.subscribe("/tts/playback_ended", self._on_tts_ended),
            bus.subscribe("/interrupt/honored", self._on_interrupt),
            bus.subscribe("/dialog/turn/state", self._on_turn_state),
            bus.subscribe("/error", self._on_error),
        ]

    def _snapshot(self, turn_id: int) -> dict[str, float | int | None]:
        with self._lock:
            return dict(self._data.setdefault(turn_id, {}))

    def _update(self, turn_id: int, **values) -> None:
        with self._lock:
            self._data.setdefault(turn_id, {}).update(values)

    def _publish_metrics(self, turn_id: int) -> None:
        self._bus.publish(
            "/metrics/turn", TurnMetrics(turn_id, self._snapshot(turn_id))
        )

    def _on_speech_detected(self, topic: str, event: UserSpeechDetected) -> None:
        del topic
        turn_info = f" turn={event.turn_id}" if event.turn_id is not None else ""
        log_stage("TURN", f"speech detected, capture started{turn_info}", CYAN)

    def _on_speech_ended(self, topic: str, event: UserSpeechEnded) -> None:
        del topic
        self._update(
            event.turn_id,
            capture_done_at=time.time(),
            capture_duration_ms=event.duration_ms,
        )
        log_stage(
            "TURN",
            f"turn={event.turn_id} capture complete | capture={event.duration_ms:.0f} ms",
            CYAN,
        )

    def _on_asr_final(self, topic: str, event: FinalTranscript) -> None:
        del topic
        self._update(event.turn_id, asr_latency_ms=event.latency_ms)
        preview = event.text[:80] + "…" if len(event.text) > 80 else event.text
        log_stage(
            "SR",
            f'turn={event.turn_id} [{event.latency_ms:.0f} ms] "{preview}"',
            BLUE,
        )

    def _on_assistant_segment(self, topic: str, event: AssistantSegment) -> None:
        del topic
        snapshot = self._snapshot(event.turn_id)
        count = int(snapshot.get("segment_count", 0) or 0) + 1
        self._update(event.turn_id, segment_count=count)
        if count == 1:
            log_stage("LLM", f"turn={event.turn_id} first segment ready", MAGENTA)
        else:
            log_stage(
                "TTS", f"turn={event.turn_id} queued extra segment #{count}", YELLOW
            )

    def _on_assistant_done(self, topic: str, event: AssistantDone) -> None:
        del topic
        log_stage(
            "LLM",
            f"turn={event.turn_id} completed | text_len={len(event.full_text)}",
            MAGENTA,
        )
        self._publish_metrics(event.turn_id)

    def _on_tts_started(self, topic: str, event: TtsPlaybackStarted) -> None:
        del topic
        self._update(event.turn_id, playback_started_at=event.at)
        log_stage("AUDIO", f"turn={event.turn_id} playback started", GREEN)

    def _on_tts_ended(self, topic: str, event: TtsPlaybackEnded) -> None:
        del topic
        self._update(event.turn_id, playback_ended_at=event.at)
        log_stage("TURN", f"turn={event.turn_id} response finished", GREEN)
        self._publish_metrics(event.turn_id)

    def _on_interrupt(self, topic: str, event: InterruptHonored) -> None:
        del topic
        log_stage("INTERRUPT", f"turn={event.turn_id} interrupted ({event.cause})", RED)

    def _on_turn_state(self, topic: str, event: TurnStateChanged) -> None:
        del topic
        turn_info = f" turn={event.turn_id}" if event.turn_id is not None else ""
        log_stage(
            "STATE",
            f"{turn_info} {event.previous} → {event.current}".strip(),
            YELLOW,
        )

    def _on_error(self, topic: str, event: ErrorEvent) -> None:
        del topic
        log_stage("ERROR", f"[{event.component}] {event.detail}", RED)
