"""
Unit specs for the ASR provider feature.

Feature under test: ``OpenAiAsrClient.transcribe`` — turns an audio blob into
a normalized ``Transcription`` via an OpenAI-compatible STT endpoint (the
project also targets the in-repo ``asr-api`` service via the same protocol).
We mock the HTTP boundary; the feature contract being pinned is:
  * cancellation is checked before and after the API call
  * text is trimmed; language is lowercased and trimmed
  * missing attributes on the response degrade gracefully

Source: ``ar_voice_controller.providers.sr``
"""

from __future__ import annotations

import pytest

pytestmark = pytest.mark.requires_openai

pytest.importorskip("openai", reason="openai SDK not installed")

from types import SimpleNamespace  # noqa: E402
from unittest.mock import MagicMock  # noqa: E402

from ar_voice_controller.config import AsrCfg  # noqa: E402
from ar_voice_controller.core.cancellation import (  # noqa: E402
    CancellationError,
    CancellationToken,
    InterruptCause,
)
from ar_voice_controller.providers.sr import (  # noqa: E402
    OpenAiAsrClient,
    Transcription,
)


@pytest.fixture
def asr_config() -> AsrCfg:
    return AsrCfg(
        base_url="http://stub",
        api_key="stub-key",
        model="stub-whisper",
        timeout_sec=5.0,
    )


@pytest.fixture
def client(asr_config: AsrCfg) -> OpenAiAsrClient:
    instance = OpenAiAsrClient(asr_config)
    instance.client = MagicMock()
    return instance


def _set_response(client: OpenAiAsrClient, **attrs) -> None:
    response = SimpleNamespace(**attrs)
    client.client.audio.transcriptions.create.return_value = response


class TestTranscribe:
    def test_returns_transcription_dataclass(self, client: OpenAiAsrClient):
        _set_response(client, text="hello", language="en")
        result = client.transcribe(b"\x00\x01", token=CancellationToken())
        assert isinstance(result, Transcription)

    def test_text_is_stripped(self, client: OpenAiAsrClient):
        _set_response(client, text="  merhaba dünya\n", language="tr")
        result = client.transcribe(b"\x00\x01", token=CancellationToken())
        assert result.text == "merhaba dünya"

    def test_language_is_lowercased_and_stripped(self, client: OpenAiAsrClient):
        _set_response(client, text="hi", language=" EN ")
        result = client.transcribe(b"\x00\x01", token=CancellationToken())
        assert result.language == "en"

    def test_missing_text_defaults_to_empty_string(self, client: OpenAiAsrClient):
        _set_response(client, language="en")
        result = client.transcribe(b"\x00\x01", token=CancellationToken())
        assert result.text == ""

    def test_missing_language_defaults_to_empty_string(self, client: OpenAiAsrClient):
        _set_response(client, text="hi")
        result = client.transcribe(b"\x00\x01", token=CancellationToken())
        assert result.language == ""

    def test_none_text_from_api_is_coerced_to_empty(self, client: OpenAiAsrClient):
        _set_response(client, text=None, language=None)
        result = client.transcribe(b"\x00\x01", token=CancellationToken())
        assert result.text == ""
        assert result.language == ""


class TestRequestArguments:
    def test_request_uses_configured_model(self, client: OpenAiAsrClient):
        _set_response(client, text="x", language="tr")
        client.transcribe(b"\x00\x01", token=CancellationToken())
        kwargs = client.client.audio.transcriptions.create.call_args.kwargs
        assert kwargs["model"] == "stub-whisper"
        assert kwargs["response_format"] == "verbose_json"

    def test_language_hint_is_forwarded(self, client: OpenAiAsrClient):
        _set_response(client, text="x", language="tr")
        client.transcribe(b"\x00\x01", token=CancellationToken(), language="tr")
        kwargs = client.client.audio.transcriptions.create.call_args.kwargs
        assert kwargs["language"] == "tr"

    def test_default_language_hint_is_none(self, client: OpenAiAsrClient):
        _set_response(client, text="x", language="tr")
        client.transcribe(b"\x00\x01", token=CancellationToken())
        kwargs = client.client.audio.transcriptions.create.call_args.kwargs
        assert kwargs["language"] is None


class TestCancellation:
    def test_raises_before_api_call_when_already_cancelled(
        self, client: OpenAiAsrClient
    ):
        token = CancellationToken()
        token.cancel(InterruptCause.VOICE_BARGE_IN)
        with pytest.raises(CancellationError):
            client.transcribe(b"\x00\x01", token=token)
        client.client.audio.transcriptions.create.assert_not_called()

    def test_raises_after_api_call_when_cancelled_mid_request(
        self, client: OpenAiAsrClient
    ):
        token = CancellationToken()

        def _side_effect(**_: object):
            token.cancel(InterruptCause.EXTERNAL_STOP)
            return SimpleNamespace(text="late", language="tr")

        client.client.audio.transcriptions.create.side_effect = _side_effect
        with pytest.raises(CancellationError):
            client.transcribe(b"\x00\x01", token=token)
