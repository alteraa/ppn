from __future__ import annotations

import time
from collections import deque
from enum import Enum, auto
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..audio.interrupt import InterruptDetector

from ..audio.utils import Streamer, is_speech_start
from ..audio.vad import VadDetector
from ..config import Settings


class IdleDecision(Enum):
    SKIP = auto()  # post_tts_ignore_chunks > 0; skip VAD check this tick
    CONTINUE = auto()  # normal chunk, no speech start yet
    START_LISTENING = auto()  # debounce threshold met; transition to LISTENING


class CaptureController:
    """Owns all audio-capture state that lives between IDLE and PROCESSING.

    Responsibilities:
    - ``before_chunks`` ring buffer (pre-speech context)
    - VAD-based speech-start detection with debounce
    - Streamer accumulation and silence-based end detection
    - ``post_tts_ignore`` cooldown after robot speech
    - ``speaking_baseline_ready`` flag for interrupt detector
    - Barge-in rewind (discard old capture, start fresh)
    """

    def __init__(
        self,
        settings: Settings,
        vad: VadDetector,
        interrupt_detector: InterruptDetector,
    ) -> None:
        self._settings = settings
        self._vad = vad
        self._detector = interrupt_detector

        self._before_chunks: deque[bytes] = deque(
            maxlen=self._to_chunks(settings.vad.before_chunks_sec)
        )
        self._streamer: Streamer | None = None
        self._silence_counter = 0
        self._speak_counter = 0
        self._speaking_baseline_ready = False
        self._post_tts_ignore_chunks = settings.interrupt.post_tts_ignore_chunks
        self._pending_capture_started_at: float | None = None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def reset(self) -> None:
        """Full state reset; called when transitioning back to IDLE."""
        self._before_chunks.clear()
        self._streamer = None
        self._silence_counter = 0
        self._speak_counter = 0
        self._speaking_baseline_ready = False
        self._post_tts_ignore_chunks = self._settings.interrupt.post_tts_ignore_chunks
        self._pending_capture_started_at = None

    def on_idle_chunk(self, raw: bytes) -> IdleDecision:
        """Process one audio chunk while in IDLE state.

        Returns ``SKIP`` when the post-TTS cooldown is active,
        ``START_LISTENING`` when the debounce counter is reached, or
        ``CONTINUE`` otherwise.
        """
        self._before_chunks.append(raw)
        self._detector.feed_rolling(raw)

        if self._post_tts_ignore_chunks > 0:
            self._post_tts_ignore_chunks -= 1
            return IdleDecision.SKIP

        baseline = self._detector.current_baseline()
        vad_conf = self._vad.confidence(raw)
        if is_speech_start(
            raw,
            baseline=baseline,
            vad_confidence=vad_conf,
            settings=self._settings,
        ):
            self._speak_counter += 1
            if self._speak_counter >= self._to_chunks(self._settings.vad.debounce_sec):
                return IdleDecision.START_LISTENING
        else:
            self._speak_counter = 0

        return IdleDecision.CONTINUE

    def begin_listening(self, first_chunk: bytes | None = None) -> float:
        """Open a new streamer pre-filled with the ``before_chunks`` context.

        Returns the capture start timestamp.
        """
        self._pending_capture_started_at = time.time()
        self._streamer = Streamer()
        for chunk in self._before_chunks:
            self._streamer.add(chunk)
        if first_chunk is not None:
            self._streamer.add(first_chunk)
        self._speak_counter = 0
        return self._pending_capture_started_at

    def on_listening_chunk(self, raw: bytes) -> list[bytes] | None:
        """Accumulate one chunk while in LISTENING state.

        Returns the completed audio buffer when the silence threshold is
        reached, or ``None`` to keep accumulating.
        """
        if self._streamer is None:
            self._streamer = Streamer()
        self._streamer.add(raw)

        conf = self._vad.confidence(raw)
        if conf > self._settings.vad.speak_threshold:
            self._silence_counter = 0
        else:
            self._silence_counter += 1

        if self._silence_counter > self._to_chunks(self._settings.vad.after_chunks_sec):
            audio_buffer = list(self._streamer.audio_buffer)
            self._streamer = None
            self._silence_counter = 0
            return audio_buffer

        return None

    def barge_in_rewind(self, raw: bytes) -> float:
        """Discard the previous capture and start a fresh LISTENING session.

        Called when a barge-in interrupt is honoured mid-processing.
        Returns the new capture start timestamp.
        """
        self._before_chunks.clear()
        self._streamer = Streamer()
        self._streamer.add(raw)
        self._silence_counter = 0
        self._speak_counter = 0
        self._speaking_baseline_ready = False
        self._pending_capture_started_at = time.time()
        return self._pending_capture_started_at

    def freeze_baseline_once(self) -> None:
        """Freeze the interrupt-detector baseline at the start of SPEAKING.

        Subsequent calls within the same turn are no-ops.
        """
        if not self._speaking_baseline_ready:
            self._detector.freeze_baseline()
            self._speaking_baseline_ready = True

    def capture_duration_ms(self) -> float:
        """Elapsed milliseconds since ``begin_listening`` (or ``barge_in_rewind``)."""
        if self._pending_capture_started_at is None:
            return 0.0
        return (time.time() - self._pending_capture_started_at) * 1000

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _to_chunks(self, sec: float) -> int:
        s = self._settings
        return int(sec * (s.audio.sample_rate / s.audio.num_samples))
