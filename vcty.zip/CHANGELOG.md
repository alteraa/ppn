# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

GitLab project: https://arfgit.akinsoft.net/akinrobotics/servisler/yapayzeka/services/voice/voice-controller

## [Unreleased]

## [0.3.0] - 2026-04-22

### Changed

- Telemetry **FifoSink**: enqueue raw events and encode on dequeue instead of pre-encoding on enqueue, for lower overhead and clearer handling when event encoding fails.

## [0.2.0] - 2026-04-22

### Changed

- GitLab CI: add an **assets-manager** stage (runs on version tags after `release`) to coordinate deployment assets with the GitLab assets manager.

## [0.1.0] - 2026-04-21

### Added

- Installable Python package **ar-voice-controller** with `pyproject.toml`, `uv.lock`, and Python 3.11+ support on Linux.
- `ar-voice-controller` CLI: loads YAML configuration and optional `.env`, runs the end-to-end voice `Pipeline`.
- `ar-voice-monitor` CLI for telemetry and monitoring workflows.
- Voice pipeline: audio capture and processing (including AEC via bundled Linux wheel), speech recognition, LLM, and TTS playback modules.
- Core orchestration: policy, capture, worker, and manager components with shared types.
- Runtime integration with ROS-oriented backends and an event bus for structured runtime events.
- Telemetry: logging helpers, FIFO-based event sink for external consumers, and event type definitions.
- Web UI (`ui/`) with a small local server: connection state, FIFO attach/detach handling, and live event updates (English UI).
- Pre-commit configuration and related repository hygiene (`.gitignore`, `.gitattributes`).

[Unreleased]: https://arfgit.akinsoft.net/akinrobotics/servisler/yapayzeka/services/voice/voice-controller/-/compare/v0.3.0...main
[0.3.0]: https://arfgit.akinsoft.net/akinrobotics/servisler/yapayzeka/services/voice/voice-controller/-/compare/v0.2.0...v0.3.0
[0.2.0]: https://arfgit.akinsoft.net/akinrobotics/servisler/yapayzeka/services/voice/voice-controller/-/compare/v0.1.0...v0.2.0
[0.1.0]: https://arfgit.akinsoft.net/akinrobotics/servisler/yapayzeka/services/voice/voice-controller/-/compare/fc514ba51c8bc585a7c944a9ec4ace3606628db3...v0.1.0
