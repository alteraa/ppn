from __future__ import annotations

import math
from pathlib import Path
from threading import Lock

import numpy as np
import onnxruntime as ort

from ..config import VadCfg


def _resolve_silero_onnx(model_path: str) -> Path:
    """Resolve ``silero_vad.onnx`` from a repo root or accept a direct ``.onnx`` path."""
    p = Path(model_path).expanduser()
    if p.is_file() and p.suffix.lower() == ".onnx":
        return p
    candidates = [
        p / "src" / "silero_vad" / "data" / "silero_vad.onnx",
        p / "silero_vad" / "data" / "silero_vad.onnx",
    ]
    for c in candidates:
        if c.is_file():
            return c
    tried = ", ".join(str(c) for c in candidates)
    raise FileNotFoundError(
        f"Silero ONNX model not found under {p}. Tried: {tried}. "
        "Point vad.model_path at a snakers4/silero-vad checkout or to silero_vad.onnx directly."
    )


class _SileroOnnxVAD:
    """ONNXRuntime runner mirroring silero-vad ``OnnxWrapper`` (state + context)."""

    def __init__(
        self,
        onnx_path: Path,
        *,
        intra_op_num_threads: int,
        inter_op_num_threads: int,
    ) -> None:
        so = ort.SessionOptions()
        so.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
        so.intra_op_num_threads = max(1, int(intra_op_num_threads))
        so.inter_op_num_threads = max(1, int(inter_op_num_threads))
        self._session = ort.InferenceSession(
            str(onnx_path),
            sess_options=so,
            providers=["CPUExecutionProvider"],
        )
        self._state: np.ndarray | None = None
        self._context: np.ndarray | None = None
        self._last_sr = 0
        self._last_batch_size = 0

    def _reset_states(self, batch_size: int) -> None:
        self._state = np.zeros((2, batch_size, 128), dtype=np.float32)
        self._context = None
        self._last_sr = 0
        self._last_batch_size = 0

    @staticmethod
    def _validate_input(x: np.ndarray, sr: int) -> tuple[np.ndarray, int]:
        if x.ndim == 1:
            x = x.reshape(1, -1)
        if x.ndim > 2:
            raise ValueError(f"Too many dimensions for input audio chunk: {x.ndim}")
        if sr != 16000 and (sr % 16000 == 0):
            step = sr // 16000
            x = x[:, ::step].copy()
            sr = 16000
        if sr not in (8000, 16000):
            raise ValueError(f"Unsupported sampling rate for Silero VAD: {sr}")
        if x.shape[1] > 0 and (sr / x.shape[1]) > 31.25:
            raise ValueError("Input audio chunk is too short for Silero VAD")
        return x.astype(np.float32, copy=False), sr

    def forward_window(self, x: np.ndarray, sr: int) -> float:
        """One window of exactly 512 samples @ 16 kHz (256 @ 8 kHz). State carries between calls."""
        x, sr = self._validate_input(np.asarray(x, dtype=np.float32), sr)
        num_samples = 512 if sr == 16000 else 256
        if x.shape[1] != num_samples:
            raise ValueError(
                f"Silero VAD expects {num_samples} samples at {sr} Hz, got {x.shape[1]}"
            )
        batch_size = x.shape[0]
        context_size = 64 if sr == 16000 else 32

        if not self._last_batch_size:
            self._reset_states(batch_size)
        if self._last_sr and self._last_sr != sr:
            self._reset_states(batch_size)
        if self._last_batch_size and self._last_batch_size != batch_size:
            self._reset_states(batch_size)

        if self._context is None:
            self._context = np.zeros((batch_size, context_size), dtype=np.float32)

        inp = np.concatenate([self._context, x], axis=1)
        ort_inputs = {
            "input": inp.astype(np.float32, copy=False),
            "state": self._state.astype(np.float32, copy=False),
            "sr": np.array(sr, dtype=np.int64),
        }
        out, new_state = self._session.run(None, ort_inputs)
        self._state = np.asarray(new_state, dtype=np.float32)
        self._context = np.asarray(inp[:, -context_size:], dtype=np.float32)
        self._last_sr = sr
        self._last_batch_size = batch_size
        return float(np.asarray(out, dtype=np.float32).reshape(-1)[0])


class VadDetector:
    def __init__(self, config: VadCfg, *, sample_rate: int) -> None:
        self.config = config
        self.sample_rate = sample_rate
        self._model: _SileroOnnxVAD | None = None
        self._lock = Lock()

    def _ensure_model(self) -> _SileroOnnxVAD:
        if self._model is not None:
            return self._model
        with self._lock:
            if self._model is None:
                onnx_path = _resolve_silero_onnx(self.config.model_path)
                self._model = _SileroOnnxVAD(
                    onnx_path,
                    intra_op_num_threads=self.config.onnx_intra_op_num_threads,
                    inter_op_num_threads=self.config.onnx_inter_op_num_threads,
                )
        return self._model

    @staticmethod
    def int2float(sound: bytes) -> np.ndarray:
        arr = np.frombuffer(sound, np.int16).astype("float32")
        peak = np.abs(arr).max() if len(arr) > 0 else 0
        if peak > 0:
            arr *= 1.0 / 32768.0
        return arr.squeeze()

    def confidence(self, audio_chunk: bytes) -> float:
        model = self._ensure_model()
        audio_float = self.int2float(audio_chunk)
        x = np.atleast_2d(audio_float.astype(np.float32, copy=False))
        if x.ndim > 2:
            raise ValueError(f"VAD input has too many dimensions: {x.ndim}")

        expected = int(round((512 / 16000) * self.sample_rate))
        length = int(x.shape[-1])

        if length == 0:
            return 0.0

        if length == expected:
            return model.forward_window(x, self.sample_rate)

        n = int(math.ceil(length / expected)) if expected > 0 else 0
        if n <= 0:
            return 0.0

        confidences: list[float] = []
        for i in range(n):
            start = i * expected
            end = min((i + 1) * expected, length)
            seg = x[..., start:end]
            if int(seg.shape[-1]) < expected:
                pad = expected - int(seg.shape[-1])
                seg = np.pad(
                    seg, ((0, 0), (0, pad)), mode="constant", constant_values=0.0
                )
            confidences.append(model.forward_window(seg, self.sample_rate))

        if not confidences:
            return 0.0

        scores = np.array(confidences, dtype=np.float32)
        return float(max(np.mean(scores), np.percentile(scores, 75)))
