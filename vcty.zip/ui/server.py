from __future__ import annotations

import argparse
import json
import queue
import threading
import time
from http import HTTPStatus
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

# Sent to SSE clients when a writer opens / closes the FIFO (typically the voice controller).
_FIFO_ATTACHED = json.dumps(
    {"topic": "/_monitor/fifo", "type": "FifoAttached", "data": {}},
    ensure_ascii=True,
)
_FIFO_DETACHED = json.dumps(
    {"topic": "/_monitor/fifo", "type": "FifoDetached", "data": {}},
    ensure_ascii=True,
)


class EventBroker:
    def __init__(self, fifo_path: str) -> None:
        self._fifo_path = fifo_path
        self._listeners: set[queue.Queue[str]] = set()
        self._lock = threading.Lock()
        self._fifo_attached = False
        self._running = True
        self._thread = threading.Thread(target=self._read_fifo_loop, daemon=True)
        self._thread.start()

    def subscribe(self) -> queue.Queue[str]:
        listener: queue.Queue[str] = queue.Queue(maxsize=256)
        with self._lock:
            self._listeners.add(listener)
            fifo_up = self._fifo_attached
        if fifo_up:
            try:
                listener.put_nowait(_FIFO_ATTACHED)
            except queue.Full:
                pass
        return listener

    def unsubscribe(self, listener: queue.Queue[str]) -> None:
        with self._lock:
            self._listeners.discard(listener)

    def close(self) -> None:
        self._running = False

    def _broadcast(self, line: str) -> None:
        dead: list[queue.Queue[str]] = []
        with self._lock:
            listeners = list(self._listeners)
        for listener in listeners:
            try:
                listener.put_nowait(line)
            except queue.Full:
                dead.append(listener)
        if dead:
            with self._lock:
                for listener in dead:
                    self._listeners.discard(listener)

    def _read_fifo_loop(self) -> None:
        while self._running:
            try:
                with open(self._fifo_path, "r", encoding="utf-8") as fifo:
                    with self._lock:
                        self._fifo_attached = True
                    self._broadcast(_FIFO_ATTACHED)
                    try:
                        for raw in fifo:
                            line = raw.strip()
                            if not line:
                                continue
                            self._broadcast(line)
                    finally:
                        with self._lock:
                            self._fifo_attached = False
                        self._broadcast(_FIFO_DETACHED)
            except OSError:
                time.sleep(0.5)


class MonitorHandler(SimpleHTTPRequestHandler):
    broker: EventBroker

    def do_GET(self) -> None:
        if self.path == "/events":
            self._handle_sse()
            return
        super().do_GET()

    def _handle_sse(self) -> None:
        listener = self.broker.subscribe()
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Connection", "keep-alive")
        self.end_headers()

        try:
            while True:
                try:
                    line = listener.get(timeout=1.0)
                    parsed = json.loads(line)
                    payload = json.dumps(parsed, ensure_ascii=True)
                    self.wfile.write(f"data: {payload}\n\n".encode("utf-8"))
                except queue.Empty:
                    self.wfile.write(b": ping\n\n")
                self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError):
            pass
        finally:
            self.broker.unsubscribe(listener)


def main() -> None:
    parser = argparse.ArgumentParser(description="Voice UI SSE server")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8080)
    parser.add_argument("--fifo", default="/tmp/voice_bus")
    args = parser.parse_args()

    ui_dir = Path(__file__).resolve().parent
    broker = EventBroker(args.fifo)
    MonitorHandler.broker = broker

    server = ThreadingHTTPServer((args.host, args.port), MonitorHandler)
    try:
        import os

        os.chdir(ui_dir)
        print(
            f"Serving UI at http://{args.host}:{args.port} | FIFO: {args.fifo}",
            flush=True,
        )
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        broker.close()
        server.server_close()


if __name__ == "__main__":
    main()
