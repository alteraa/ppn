# VAD ONNX smoke test

Runs each `*.onnx` in a directory through `VadDetector` (same path as production) with fixed 512-sample @ 16 kHz windows.

## Run

From the repository root:

```bash
uv run python examples/vad_inference/test_vad_models.py --models-dir /path/to/onnx
```

Optional: `--wav path/to/file.wav` — 16-bit PCM, mono or stereo; non–16 kHz files are linearly resampled to 16 kHz. Omit `--wav` to use built-in synthetic audio.

Exit code `0` if every model reports `OK`; `2` if any failed. Failures log the full message on **stderr** first; the table **status** column is truncated so wide terminals do not wrap one model across two lines.

Some int8 graphs use ops (for example `ConvInteger`) that the default **onnxruntime** CPU build does not implement; use a different export or ORT build if you need that variant.
