# tts-api: server-side streaming for the PCM endpoint

> Audience: maintainers of the `tts-api` service (separate repo/project). This
> document captures the changes required **on the server** to complement the
> voice-controller's new streaming client. The voice-controller side is
> already shipped (see [Related](#related-voice-controller-changes)).

## Motivation

The voice-controller now consumes the OpenAI-compatible speech endpoint with
`with_streaming_response.create(...)` + `iter_bytes()`, pushing resampled
audio blocks to the playback queue as they arrive (~50 ms granularity). This
cuts the **time-to-first-audio (TTFA)** against OpenAI cloud by roughly
500-700 ms on a typical turn.

Against the local `tts-api` service the client-side change is a **no-op**
today, because the server:

1. Consumes Piper's internal generator into a `list[bytes]` and joins it
   into a single blob before returning (`synthesize_pcm`).
2. Returns a `fastapi.responses.Response` (not `StreamingResponse`), so the
   HTTP body is only flushed after the whole blob is ready.

With both ends streaming end-to-end, TTFA against the local service drops
from ~200-400 ms to ~80-150 ms — the range where the interaction starts to
feel immediate.

## Scope

- **In scope:** `response_format=pcm` on `POST /v1/audio/speech` and
  `POST /v1/inference`.
- **Out of scope:** encoded formats (`mp3`, `opus`, `aac`, `flac`). These
  go through `pydub`/ffmpeg and need the full PCM buffer up front; keep the
  existing batch path.
- **Out of scope (can be added later):** `wav`. A streaming WAV is possible
  by emitting a header with a provisional data length, but it adds
  complexity with no additional client win for our use case (voice-controller
  requests `pcm`).

## Current code (for reference)

```15:30:tts-api/src/ar_tts_api/services/synthesizer.py
def synthesize_pcm(
    voice: PiperVoice,
    text: str,
    syn_config: SynthesisConfig | None = None,
) -> tuple[bytes, int]:
    """
    Synthesize text and return (raw_pcm_s16le_bytes, sample_rate).
    ...
    """
    parts: list[bytes] = []
    sample_rate = 22050
    for chunk in voice.synthesize(text, syn_config=syn_config):
        parts.append(chunk.audio_int16_bytes)
        sample_rate = chunk.sample_rate
    return b"".join(parts), sample_rate
```

```51:63:tts-api/src/ar_tts_api/api/v1/endpoints/inference.py
    if fmt == OpenAIResponseFormat.pcm:
        audio_bytes, sample_rate = await loop.run_in_executor(
            None, functools.partial(synthesize_pcm, voice, text, syn_config)
        )
        return Response(
            content=audio_bytes,
            media_type="application/octet-stream",
            headers={
                "X-Model-Id": model_id,
                "X-Audio-Format": "pcm_s16le",
                "X-Sample-Rate": str(sample_rate),
            },
        )
```

## Required changes

### 1. `services/synthesizer.py` — add a chunk-level generator

Expose Piper's native generator without joining:

```python
from typing import Iterator

def iter_pcm(
    voice: PiperVoice,
    text: str,
    syn_config: SynthesisConfig | None = None,
) -> Iterator[tuple[bytes, int]]:
    """Yield ``(pcm_s16le_chunk, sample_rate)`` tuples as Piper produces them.

    The sample rate is emitted with every chunk for caller convenience; in
    practice it is constant for the lifetime of a single synthesis.
    """
    for chunk in voice.synthesize(text, syn_config=syn_config):
        yield chunk.audio_int16_bytes, chunk.sample_rate
```

Keep `synthesize_pcm` as a thin wrapper for the encoded-format path
(`convert_pcm` still needs the full buffer):

```python
def synthesize_pcm(
    voice: PiperVoice,
    text: str,
    syn_config: SynthesisConfig | None = None,
) -> tuple[bytes, int]:
    parts: list[bytes] = []
    sample_rate = 22050
    for data, rate in iter_pcm(voice, text, syn_config):
        parts.append(data)
        sample_rate = rate
    return b"".join(parts), sample_rate
```

### 2. `api/v1/endpoints/inference.py` — `StreamingResponse` for PCM

Replace the PCM branch in `_build_audio_response` with a generator-backed
`StreamingResponse`. Key constraints:

- The `X-Sample-Rate` header must be set **before** the body starts. Piper
  only reveals its sample rate once the first chunk is produced, so peek the
  first chunk eagerly in a worker thread, then stream the rest.
- The hand-off has to stay async-friendly; Piper's `voice.synthesize` is a
  blocking generator, so run it in a thread and push chunks into an
  `asyncio.Queue` that the streaming response consumes.

Reference implementation (condensed):

```python
import asyncio
from fastapi.responses import StreamingResponse
from ar_tts_api.services.synthesizer import iter_pcm

async def _stream_pcm_response(voice, text, syn_config, model_id) -> StreamingResponse:
    loop = asyncio.get_running_loop()
    q: asyncio.Queue[bytes | None] = asyncio.Queue(maxsize=32)
    first_chunk: dict[str, object] = {}
    first_ready = asyncio.Event()

    def _producer() -> None:
        try:
            it = iter_pcm(voice, text, syn_config)
            try:
                data, rate = next(it)
            except StopIteration:
                first_chunk["rate"] = 22050
                first_chunk["data"] = b""
                loop.call_soon_threadsafe(first_ready.set)
                loop.call_soon_threadsafe(q.put_nowait, None)
                return
            first_chunk["rate"] = rate
            first_chunk["data"] = data
            loop.call_soon_threadsafe(first_ready.set)
            loop.call_soon_threadsafe(q.put_nowait, data)
            for data, _ in it:
                loop.call_soon_threadsafe(q.put_nowait, data)
        finally:
            loop.call_soon_threadsafe(q.put_nowait, None)  # sentinel

    loop.run_in_executor(None, _producer)
    await first_ready.wait()

    async def _body():
        # First chunk is already enqueued by the producer.
        while True:
            item = await q.get()
            if item is None:
                return
            yield item

    return StreamingResponse(
        _body(),
        media_type="application/octet-stream",
        headers={
            "X-Model-Id": model_id,
            "X-Audio-Format": "pcm_s16le",
            "X-Sample-Rate": str(first_chunk["rate"]),
        },
    )
```

Then, in `_build_audio_response`:

```python
if fmt == OpenAIResponseFormat.pcm:
    return await _stream_pcm_response(voice, text, syn_config, model_id)
```

The `wav` and encoded branches stay as they are.

### 3. Cancellation / client disconnect

`voice.synthesize` can run for hundreds of milliseconds. If the client
disconnects (barge-in, timeout), the producer should stop consuming Piper
rather than finish generating a reply nobody wants.

Two options, in increasing order of effort:

1. **Detection via backpressure** (simplest). If `q` stays full because
   Starlette stopped draining the body, the producer's
   `loop.call_soon_threadsafe(q.put_nowait, ...)` will raise `QueueFull`
   after N blocked iterations. Wrap with a small timeout and let it exit.
2. **Explicit cancellation**. Pass a `threading.Event` into the producer;
   wire it up through a Starlette `BackgroundTask` or by polling
   `request.is_disconnected()` in a watchdog coroutine. This gives a clean
   shutdown without relying on queue pressure.

Option 1 is enough for the voice-controller's use pattern (barge-in closes
the connection immediately and Starlette stops reading).

## Contract stability

What stays the same:

- URL, JSON schema, query params, response headers.
- Response body bytes: still raw s16le mono PCM at `X-Sample-Rate` Hz.
- Encoded formats (`mp3`/`opus`/`aac`/`flac`) and `wav` behavior.

What changes:

- `Transfer-Encoding: chunked` (FastAPI / Starlette set this automatically
  for `StreamingResponse`).
- `Content-Length` header is no longer emitted for the PCM branch.

Both are transparent to:

- `openai` Python SDK (`with_streaming_response.create(...).iter_bytes()`).
- `curl --output -`.
- Any client that reads the response body to EOF.

The voice-controller's `OpenAiTtsClient.synthesize_stream` consumes either
transport identically.

## Test updates

### `tests/unit/test_openai_speech_endpoint.py`

Add cases asserting the streaming transport for the PCM format:

```python
def test_speech_pcm_format_is_streaming(client: TestClient):
    response = client.post(
        "/v1/audio/speech",
        json={"model": "test-model", "input": "Test input", "response_format": "pcm"},
    )
    assert response.status_code == 200
    assert response.headers["content-type"] == "application/octet-stream"
    assert response.headers["X-Audio-Format"] == "pcm_s16le"
    assert "X-Sample-Rate" in response.headers
    # StreamingResponse omits Content-Length; body is still fully readable.
    assert "content-length" not in {k.lower() for k in response.headers}
    assert len(response.content) > 0
```

Keep the existing MP3/WAV assertions intact — those paths are unchanged.

### `tests/unit/test_synthesizer.py`

Add a test for the new `iter_pcm` generator:

```python
def test_iter_pcm_yields_chunks_with_sample_rate(stub_voice):
    chunks = list(iter_pcm(stub_voice, "hello"))
    assert chunks, "expected at least one chunk"
    for data, rate in chunks:
        assert isinstance(data, (bytes, bytearray))
        assert rate > 0
```

And retain the existing `synthesize_pcm` tests — it's now thin wrapper but
must keep returning the joined blob with the last-seen rate.

### `tests/integration/test_openai_sdk_speech.py`

Optional (recommended): regression guard for TTFB using `iter_bytes`:

```python
def test_pcm_time_to_first_byte_under_threshold(running_server):
    import time
    from openai import OpenAI

    client = OpenAI(base_url=running_server.url, api_key="not-needed")
    t0 = time.perf_counter()
    with client.audio.speech.with_streaming_response.create(
        model="test-model",
        voice="unused",
        input="Merhaba, nasılsın?",
        response_format="pcm",
    ) as response:
        for _ in response.iter_bytes(chunk_size=1024):
            ttfb_ms = (time.perf_counter() - t0) * 1000
            break
    assert ttfb_ms < 250  # tighten over time; baseline 300-500ms on batch mode
```

## Performance expectations

| Metric | Today | After this change |
|---|---|---|
| Piper first-chunk latency | bundled with full synthesis | ~30-80 ms |
| Accumulator on client (voice-controller) | ~50 ms | ~50 ms |
| End-to-end TTFA (short sentence) | ~200-400 ms | ~80-150 ms |
| Total synthesis time | unchanged | unchanged |
| Total bytes on wire | unchanged | unchanged |

## Rollout

- **Backward compatible both ways.** A voice-controller using the old
  batch `synthesize` path still works against a streaming server
  (reads to EOF). An updated voice-controller (streaming client) still
  works against the current batch server (receives all bytes at once;
  trade-off: no latency win but no regression).
- **No configuration changes required** on the voice-controller side,
  other than `TtsCfg.sample_rate = 22050` when pointing at this service
  (Piper default).
- Ship behind a feature flag if desired (`TTS_API_STREAM_PCM=1`) for a
  canary period.

## Related: voice-controller changes

The client-side counterpart is already live in this repo:

- [src/ar_voice_controller/providers/tts.py](../src/ar_voice_controller/providers/tts.py) —
  new `synthesize_stream`, `synthesize` preserved as a backward-compatible
  wrapper, ~50 ms accumulator before resample.
- [src/ar_voice_controller/providers/tts_player.py](../src/ar_voice_controller/providers/tts_player.py) —
  `_synthesis_loop` iterates chunks into `_playback_queue`; segment metadata
  attached only to the first chunk so `_segment_events_loop` keeps its
  "text marker" invariant.
- [tests/unit/test_tts_client.py](../tests/unit/test_tts_client.py) — mocks
  `with_streaming_response.create` + `iter_bytes`; covers the accumulator
  threshold, odd-byte boundaries, and mid-stream cancellation.
