"""
Top-level pytest configuration.

Provides two things:

1. A registry of optional / heavy dependencies, keyed by the pytest marker
   that declares a test needs them.
2. A ``pytest_collection_modifyitems`` hook that auto-skips
   ``requires_*``-marked tests whose underlying dependency is not importable.
3. A ``collect_ignore_glob`` fallback that drops whole test modules when a
   dependency is missing, so collection itself does not crash on their
   top-level imports.

This lets CI/CD pipelines install a lean dependency set and run
``pytest -m "not requires_onnx_model and not requires_audio_hw"`` without
test-collection errors.

See ``docs/testing.md`` for the fast-lane recipe.
"""

from __future__ import annotations

from importlib.util import find_spec

import pytest

# Marker name -> the module names whose absence should skip those tests.
# The first-party package name goes here (with underscores), not the PyPI
# distribution name.
_OPTIONAL_DEPS: dict[str, tuple[str, ...]] = {
    "requires_onnx_model": ("onnxruntime",),
    "requires_audio_hw": ("sounddevice", "aec_audio_processing"),
    "requires_openai": ("openai",),
}

# Test modules that cannot even be *collected* without the listed packages
# (their top-level imports pull the dependency in). Paths are relative to
# this ``conftest.py``.
_HARD_DEP_MODULES: dict[str, tuple[str, ...]] = {
    "unit/test_vad_detector.py": ("onnxruntime",),
    "unit/test_llm_client.py": ("openai",),
    "unit/test_asr_client.py": ("openai",),
    "unit/test_tts_client.py": ("openai",),
    "unit/test_message_history.py": ("openai",),
}


def _missing(packages: tuple[str, ...]) -> list[str]:
    return [name for name in packages if find_spec(name) is None]


collect_ignore_glob: list[str] = []
for _module_path, _deps in _HARD_DEP_MODULES.items():
    if _missing(_deps):
        collect_ignore_glob.append(_module_path)


def pytest_collection_modifyitems(
    config: pytest.Config, items: list[pytest.Item]
) -> None:
    """Skip ``requires_*`` items when their optional dependency is missing."""
    for item in items:
        for marker_name, deps in _OPTIONAL_DEPS.items():
            if item.get_closest_marker(marker_name) is None:
                continue
            missing = _missing(deps)
            if missing:
                item.add_marker(
                    pytest.mark.skip(
                        reason=(
                            f"requires optional dependency: " f"{', '.join(missing)}"
                        )
                    )
                )
