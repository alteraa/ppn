"""
Unit specs for the TTS streaming text-splitting feature.

Feature under test: incremental sentence and segment extraction used by the
streaming LLM policy to feed the TTS player. These are pure string functions
and their behavior is a stable contract regardless of which policy / bus /
transport wires them together.

Source: ``ar_voice_controller.providers.text_utils``
"""

from __future__ import annotations

import pytest

from ar_voice_controller.providers.text_utils import (
    drain_completed_sentences,
    drain_partial_tts_segments,
    split_sentence_for_tts,
)


class TestDrainCompletedSentences:
    """Feature: extract whole sentences from a streaming buffer."""

    def test_empty_buffer_yields_no_sentences(self):
        sentences, remainder = drain_completed_sentences("")
        assert sentences == []
        assert remainder == ""

    def test_buffer_without_terminator_is_kept_as_remainder(self):
        sentences, remainder = drain_completed_sentences("hello there")
        assert sentences == []
        assert remainder == "hello there"

    def test_single_completed_sentence_is_extracted(self):
        sentences, remainder = drain_completed_sentences("Hello world. ")
        assert sentences == ["Hello world."]
        assert remainder == ""

    def test_multiple_sentences_are_extracted_in_order(self):
        sentences, remainder = drain_completed_sentences("One. Two! Three? ")
        assert sentences == ["One.", "Two!", "Three?"]
        assert remainder == ""

    def test_partial_trailing_sentence_is_returned_as_remainder(self):
        sentences, remainder = drain_completed_sentences("Done. still typing")
        assert sentences == ["Done."]
        assert remainder == "still typing"

    @pytest.mark.parametrize("terminator", [".", "!", "?"])
    def test_all_standard_terminators_close_a_sentence(self, terminator: str):
        sentences, _ = drain_completed_sentences(f"End{terminator} ")
        assert sentences == [f"End{terminator}"]

    def test_closing_quote_or_bracket_is_kept_with_sentence(self):
        sentences, remainder = drain_completed_sentences('She said "hi." ')
        assert sentences == ['She said "hi."']
        assert remainder == ""


class TestDrainPartialTtsSegments:
    """
    Feature: before a full sentence arrives, flush long-enough partials at
    pause breaks (comma / semicolon / colon) so TTS can start speaking sooner.
    """

    def test_short_buffer_is_not_drained(self):
        segments, remaining = drain_partial_tts_segments(
            "too short",
            min_chars=20,
            target_chars=40,
            max_chars=80,
        )
        assert segments == []
        assert remaining == "too short"

    def test_returns_empty_when_no_pause_break_available(self):
        buffer = "a " * 50  # > target_chars but no pause punctuation
        segments, remaining = drain_partial_tts_segments(
            buffer,
            min_chars=20,
            target_chars=40,
            max_chars=80,
        )
        assert segments == []
        assert remaining == buffer

    def test_splits_at_comma_past_min_chars(self):
        buffer = "this is a fairly long clause, and then more content follows here"
        segments, remaining = drain_partial_tts_segments(
            buffer,
            min_chars=10,
            target_chars=20,
            max_chars=80,
        )
        assert len(segments) == 1
        assert segments[0].endswith(",")
        assert "then more content" in remaining

    def test_remaining_shorter_than_target_terminates_draining(self):
        buffer = "alpha, beta"
        segments, remaining = drain_partial_tts_segments(
            buffer,
            min_chars=3,
            target_chars=100,
            max_chars=80,
        )
        assert segments == []
        assert remaining == buffer


class TestSplitSentenceForTts:
    """
    Feature: break a completed sentence that exceeds ``max_chars`` into
    TTS-sized segments using pause punctuation first, whitespace as fallback.
    """

    def test_empty_input_returns_empty_list(self):
        assert split_sentence_for_tts("", min_chars=10, max_chars=40) == []

    def test_whitespace_only_input_returns_empty_list(self):
        assert split_sentence_for_tts("   \n\t  ", min_chars=10, max_chars=40) == []

    def test_short_sentence_is_returned_as_single_segment(self):
        assert split_sentence_for_tts(
            "hello there.",
            min_chars=10,
            max_chars=80,
        ) == ["hello there."]

    def test_segments_prefer_pause_punctuation_boundaries(self):
        sentence = (
            "first clause goes here, second clause follows; "
            "third clause ends the line."
        )
        segments = split_sentence_for_tts(sentence, min_chars=15, max_chars=40)
        assert len(segments) >= 2
        assert segments[0].endswith((",", ";", ":"))

    def test_every_segment_is_non_empty_and_stripped(self):
        sentence = "alpha beta gamma delta epsilon zeta eta theta iota"
        segments = split_sentence_for_tts(sentence, min_chars=5, max_chars=20)
        assert segments
        for segment in segments:
            assert segment
            assert segment == segment.strip()

    def test_joined_segments_preserve_all_non_whitespace_content(self):
        sentence = "alpha beta gamma delta epsilon zeta eta theta iota kappa"
        segments = split_sentence_for_tts(sentence, min_chars=5, max_chars=20)
        joined = " ".join(segments)
        assert joined.replace(" ", "") == sentence.replace(" ", "")
