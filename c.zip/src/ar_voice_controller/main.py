from __future__ import annotations

import argparse
from pathlib import Path

from dotenv import load_dotenv

from .config import load_settings
from .pipeline import Pipeline


def main() -> None:
    load_dotenv(Path(__file__).resolve().parents[2] / ".env", override=False)
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config/config.yaml")
    args = parser.parse_args()
    settings = load_settings(args.config)
    Pipeline(settings).run()


if __name__ == "__main__":
    main()
