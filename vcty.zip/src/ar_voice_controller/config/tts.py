from __future__ import annotations

from pydantic import BaseModel, Field


class TtsCfg(BaseModel):
    base_url: str | None = "http://127.0.0.1:8020/v1"
    api_key: str | None = None
    model: str = "tts-1"
    timeout_sec: float = 60.0
    sample_rate: int = 24000
    default_language: str = "tr"
    voice_by_language: dict[str, str] = Field(
        default_factory=lambda: {
            "tr": "nova",
            "en": "alloy",
        }
    )
    chunk_buffer_ms: int = 150
