from __future__ import annotations

import os
from typing import Iterator, Protocol

import numpy as np
from openai import OpenAI

from ..core.cancellation import CancellationToken
from ..config import AudioCfg, TtsCfg


class TtsClient(Protocol):
    def synthesize_stream(
        self,
        text: str,
        *,
        token: CancellationToken,
        language: str,
    ) -> Iterator[np.ndarray]: ...

    def synthesize(
        self,
        text: str,
        *,
        token: CancellationToken,
        language: str,
    ) -> np.ndarray | None: ...


class OpenAiTtsClient:
    def __init__(self, config: TtsCfg, audio_config: AudioCfg):
        self.config = config
        self.audio_config = audio_config
        self.client = OpenAI(
            base_url=self.config.base_url,
            api_key=self.config.api_key or os.getenv("OPENAI_API_KEY") or "not-needed",
            timeout=self.config.timeout_sec,
        )

    def _normalize_language(self, language: str) -> str:
        lang = (language or "").strip().lower()
        if lang.startswith("tr") or lang == "turkish":
            return "tr"
        if lang.startswith("en") or lang == "english":
            return "en"
        return self.config.default_language

    def _resample_to_output_rate(self, samples: np.ndarray) -> np.ndarray:
        if (
            len(samples) == 0
            or self.config.sample_rate == self.audio_config.sample_rate
        ):
            return samples

        source_positions = np.arange(len(samples), dtype=np.float32)
        target_length = max(
            1,
            int(
                round(
                    len(samples)
                    * self.audio_config.sample_rate
                    / self.config.sample_rate
                )
            ),
        )
        target_positions = np.linspace(
            0, len(samples) - 1, num=target_length, dtype=np.float32
        )
        resampled = np.interp(
            target_positions, source_positions, samples.astype(np.float32)
        )
        return np.clip(np.round(resampled), -32768, 32767).astype(np.int16)

    def _select_voice(self, language: str) -> str:
        normalized = self._normalize_language(language)
        return self.config.voice_by_language.get(
            normalized,
            self.config.voice_by_language[self.config.default_language],
        )

    def _min_block_bytes(self) -> int:
        # Buffer at least chunk_buffer_ms of s16 mono PCM at the source rate
        # before yielding a resampled chunk; larger chunks reduce the chance of
        # the playback device running dry between network deliveries.
        return 2 * max(1, int(self.config.sample_rate * self.config.chunk_buffer_ms / 1000))

    @staticmethod
    def _split_even_bytes(buffer: bytes) -> tuple[bytes, bytes]:
        """Return ``(even-byte prefix, one-byte carry)`` so the prefix can be
        safely interpreted as ``int16`` frames."""
        if len(buffer) % 2:
            return buffer[:-1], buffer[-1:]
        return buffer, b""

    def _bytes_to_resampled_chunk(self, block: bytes) -> np.ndarray | None:
        if len(block) < 2:
            return None
        samples = np.frombuffer(block, dtype=np.int16).copy()
        resampled = self._resample_to_output_rate(samples)
        return resampled if len(resampled) > 0 else None

    def synthesize_stream(
        self,
        text: str,
        *,
        token: CancellationToken,
        language: str,
    ) -> Iterator[np.ndarray]:
        token.raise_if_cancelled()
        voice = self._select_voice(language)
        min_bytes = self._min_block_bytes()

        with self.client.audio.speech.with_streaming_response.create(
            model=self.config.model,
            voice=voice,
            input=text,
            response_format="pcm",
        ) as response:
            carry = b""
            for raw in response.iter_bytes(chunk_size=4096):
                token.raise_if_cancelled()
                carry += raw
                if len(carry) < min_bytes:
                    continue
                block, carry = self._split_even_bytes(carry)
                chunk = self._bytes_to_resampled_chunk(block)
                if chunk is not None:
                    yield chunk

            tail_block, _ = self._split_even_bytes(carry)
            tail_chunk = self._bytes_to_resampled_chunk(tail_block)
            if tail_chunk is not None:
                yield tail_chunk

    def synthesize(
        self,
        text: str,
        *,
        token: CancellationToken,
        language: str,
    ) -> np.ndarray | None:
        parts = [
            chunk
            for chunk in self.synthesize_stream(text, token=token, language=language)
            if len(chunk) > 0
        ]
        if not parts:
            return None
        return np.concatenate(parts)
