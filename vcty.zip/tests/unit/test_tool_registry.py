"""
Unit specs for the ToolRegistry feature.

Feature under test: name-keyed registry used by the dialog policy to look up
registered tools. Contract is a tiny stable CRUD-like surface; these tests
pin it so later refactors (e.g., moving the registry into a DI container)
stay honest about what callers depend on.

Source: ``ar_voice_controller.core.types.ToolRegistry``
"""

from __future__ import annotations

from ar_voice_controller.core.types import ToolRegistry


class TestEmptyRegistry:
    def test_list_is_empty_initially(self):
        assert ToolRegistry().list() == []

    def test_get_returns_none_for_unknown_name(self):
        assert ToolRegistry().get("does-not-exist") is None


class TestRegister:
    def test_registered_tool_is_retrievable_by_name(self):
        registry = ToolRegistry()
        tool = object()
        registry.register("hello", tool)
        assert registry.get("hello") is tool

    def test_registering_same_name_replaces_previous_tool(self):
        registry = ToolRegistry()
        first = object()
        second = object()
        registry.register("one", first)
        registry.register("one", second)
        assert registry.get("one") is second

    def test_list_contains_all_distinct_registered_tools(self):
        registry = ToolRegistry()
        a = object()
        b = object()
        registry.register("a", a)
        registry.register("b", b)
        listed = registry.list()
        assert len(listed) == 2
        assert a in listed
        assert b in listed

    def test_list_returns_a_snapshot_not_an_internal_reference(self):
        registry = ToolRegistry()
        tool = object()
        registry.register("only", tool)
        snapshot = registry.list()
        snapshot.clear()
        assert registry.get("only") is tool
        assert registry.list() == [tool]
