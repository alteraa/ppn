from __future__ import annotations

import re

SENTENCE_END_RE = re.compile(r"(.+?[.!?](?:[\"')\]]+)?)(?=\s+|$)", re.DOTALL)
PAUSE_BREAK_RE = re.compile(r"[,;:](?:[\"')\]]+)?(?=\s+|$)")


def _find_pause_break(text: str, min_chars: int, max_chars: int) -> int | None:
    window = text[:max_chars]
    split_at = None
    for match in PAUSE_BREAK_RE.finditer(window):
        if match.end() >= min_chars:
            split_at = match.end()
    return split_at


def drain_completed_sentences(buffer: str) -> tuple[list[str], str]:
    sentences: list[str] = []
    consumed = 0
    for match in SENTENCE_END_RE.finditer(buffer):
        sentence = match.group(1).strip()
        if sentence:
            sentences.append(sentence)
        consumed = match.end()
    remainder = buffer[consumed:].lstrip() if consumed else buffer
    return sentences, remainder


def drain_partial_tts_segments(
    buffer: str,
    *,
    min_chars: int,
    target_chars: int,
    max_chars: int,
) -> tuple[list[str], str]:
    segments: list[str] = []
    remaining = buffer
    while len(remaining.strip()) >= target_chars:
        split_at = _find_pause_break(remaining, min_chars, max_chars)
        if split_at is None:
            break
        segment = remaining[:split_at].strip()
        if not segment:
            break
        segments.append(segment)
        remaining = remaining[split_at:].lstrip()
    return segments, remaining


def split_sentence_for_tts(
    sentence: str,
    *,
    min_chars: int,
    max_chars: int,
) -> list[str]:
    remaining = " ".join(sentence.split()).strip()
    if not remaining:
        return []
    segments: list[str] = []
    while len(remaining) > max_chars:
        split_at = _find_pause_break(remaining, min_chars, max_chars)
        if split_at is None:
            split_at = remaining.rfind(" ", min_chars, max_chars)
            if split_at == -1:
                break
        segment = remaining[:split_at].strip()
        if not segment:
            break
        segments.append(segment)
        remaining = remaining[split_at:].lstrip()
    if remaining:
        segments.append(remaining)
    return segments
