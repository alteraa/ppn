from __future__ import annotations

import queue
import threading
import time
from collections import deque
from dataclasses import dataclass

import numpy as np
import sounddevice as sd

from ..config import AudioCfg
from .._ansi import RED
from ..telemetry.plain_logger import log_stage
from .aec import AecProcessor


class AudioIO:
    def __init__(self, config: AudioCfg):
        self.config = config
        self._pre_buffer_samples = max(
            1, int(config.sample_rate * config.playback_pre_buffer_ms / 1000)
        )
        self._input_queue: queue.Queue[bytes] = queue.Queue(
            maxsize=self.config.input_queue_max_chunks
        )
        self._playback_lock = threading.Lock()
        self._playback_segments: deque[_PlaybackSegment] = deque()
        self._playback_cursor = 0
        self._playback_active = False
        self._pre_buffering = False
        self._started_segments: queue.SimpleQueue[tuple[int, float]] = (
            queue.SimpleQueue()
        )
        self._status_log_count = 0
        self._aec = AecProcessor(config)
        self._stream = sd.Stream(
            samplerate=self.config.sample_rate,
            blocksize=self.config.num_samples,
            dtype="int16",
            channels=self.config.channels,
            callback=self._callback,
            latency=self.config.stream_latency,
        )
        self._stream.start()

    def _queue_input_chunk(self, chunk: bytes) -> None:
        try:
            self._input_queue.put_nowait(chunk)
        except queue.Full:
            try:
                self._input_queue.get_nowait()
            except queue.Empty:
                pass
            try:
                self._input_queue.put_nowait(chunk)
            except queue.Full:
                pass

    def _maybe_mark_segment_started(
        self, segment: _PlaybackSegment, started_markers: list[tuple[int, float]]
    ) -> None:
        if segment.started:
            return
        segment.started = True
        segment.started_at = time.time()
        if segment.segment_id is not None:
            started_markers.append((segment.segment_id, segment.started_at))

    def _mix_playback_segments(
        self, frames: int, started_markers: list[tuple[int, float]]
    ) -> np.ndarray:
        out = np.zeros(frames, dtype=np.int16)
        written = 0
        while written < frames and self._playback_segments:
            current = self._playback_segments[0]
            self._maybe_mark_segment_started(current, started_markers)
            available = len(current.samples) - self._playback_cursor
            take = min(frames - written, available)
            out[written : written + take] = current.samples[
                self._playback_cursor : self._playback_cursor + take
            ]
            written += take
            self._playback_cursor += take
            if self._playback_cursor >= len(current.samples):
                self._playback_segments.popleft()
                self._playback_cursor = 0
        return out

    def _consume_playback(self, frames: int) -> np.ndarray:
        started_markers: list[tuple[int, float]] = []
        with self._playback_lock:
            if not self._playback_active or not self._playback_segments:
                return np.zeros(frames, dtype=np.int16)
            out = self._mix_playback_segments(frames, started_markers)
            if not self._playback_segments:
                self._playback_active = False

        for marker in started_markers:
            self._started_segments.put(marker)
        return out

    def _callback(self, indata, outdata, frames, time_info, status) -> None:
        del time_info
        playback = self._consume_playback(frames)
        outdata[:, 0] = playback

        if status:
            is_startup_output_underflow = bool(
                getattr(status, "output_underflow", False) and not self.is_playing
            )
            if (
                not is_startup_output_underflow
                and self._status_log_count < self.config.max_status_logs
            ):
                self._status_log_count += 1
                log_stage("AUDIO", f"callback status: {status}", RED)

        mic = np.ascontiguousarray(indata[:, 0].copy(), dtype=np.int16)
        try:
            cleaned = self._aec.process(mic, playback)
        except Exception as exc:
            log_stage("AUDIO", f"processing error: {exc}", RED)
            cleaned = np.zeros_like(mic)

        self._queue_input_chunk(cleaned.astype(np.int16).tobytes())

    def read_chunk(self, timeout: float | None = None) -> bytes:
        return self._input_queue.get(timeout=timeout)

    def clear_input_queue(self) -> None:
        while True:
            try:
                self._input_queue.get_nowait()
            except queue.Empty:
                break

    def start_playback(self, samples: np.ndarray) -> None:
        normalized = np.ascontiguousarray(samples.astype(np.int16))
        with self._playback_lock:
            self._playback_segments.clear()
            if len(normalized) > 0:
                self._playback_segments.append(_PlaybackSegment(samples=normalized))
            self._playback_cursor = 0
            self._pre_buffering = False
            self._playback_active = len(normalized) > 0
        self.clear_input_queue()
        self._aec.reset()

    def enqueue_playback(
        self, samples: np.ndarray, *, segment_id: int | None = None
    ) -> None:
        normalized = np.ascontiguousarray(samples.astype(np.int16))
        if len(normalized) == 0:
            return

        should_reset = False
        with self._playback_lock:
            truly_idle = (
                not self._playback_active
                and not self._pre_buffering
                and not self._playback_segments
            )
            if truly_idle:
                self._playback_segments.clear()
                self._playback_cursor = 0
                self._pre_buffering = True
            self._playback_segments.append(
                _PlaybackSegment(samples=normalized, segment_id=segment_id)
            )
            if not self._playback_active and self._pre_buffering:
                total_buffered = (
                    sum(len(s.samples) for s in self._playback_segments)
                    - self._playback_cursor
                )
                if total_buffered >= self._pre_buffer_samples:
                    self._pre_buffering = False
                    self._playback_active = True
                    should_reset = True

        if should_reset:
            self.clear_input_queue()
            self._aec.reset()

    def flush_playback_buffer(self) -> None:
        """Activate playback immediately even if the pre-buffer is not full yet.

        Call this when no more audio chunks are coming (e.g. end of TTS stream)
        so that any remaining buffered audio is not silently discarded.
        """
        should_reset = False
        with self._playback_lock:
            if self._pre_buffering and self._playback_segments:
                self._pre_buffering = False
                self._playback_active = True
                should_reset = True
        if should_reset:
            self.clear_input_queue()
            self._aec.reset()

    def stop_playback(self) -> None:
        with self._playback_lock:
            self._playback_active = False
            self._pre_buffering = False
            self._playback_segments.clear()
            self._playback_cursor = 0
        self.clear_input_queue()
        self._aec.reset()

    @property
    def is_playing(self) -> bool:
        with self._playback_lock:
            return self._playback_active or self._pre_buffering

    def close(self) -> None:
        self.stop_playback()
        self._stream.stop()
        self._stream.close()

    def poll_started_segment(self) -> tuple[int, float] | None:
        try:
            return self._started_segments.get_nowait()
        except queue.Empty:
            return None


@dataclass
class _PlaybackSegment:
    samples: np.ndarray
    segment_id: int | None = None
    started: bool = False
    started_at: float = 0.0
