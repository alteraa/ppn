#!/usr/bin/env python3
"""Smoke-test Silero ONNX VAD variants using the project's VadDetector."""

from __future__ import annotations

import argparse
import sys
import time
import wave
from dataclasses import dataclass
from pathlib import Path

import numpy as np

_REPO_ROOT = Path(__file__).resolve().parents[2]
_SRC = _REPO_ROOT / "src"
if _SRC.is_dir() and str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

from ar_voice_controller.config import VadCfg  # noqa: E402
from ar_voice_controller.audio.vad import VadDetector  # noqa: E402

SAMPLE_RATE = 16000
WINDOW_SAMPLES = 512  # Silero @ 16 kHz (matches VadDetector chunking)
STATUS_PRINT_MAX = 48  # keep one line per model in narrow terminals


@dataclass
class Row:
    name: str
    cold_start_ms: float | None
    avg_window_ms: float | None
    mean_conf: float | None
    max_conf: float | None
    above_threshold: int | None
    windows: int | None
    status: str


def _synthetic_int16(seconds: float) -> np.ndarray:
    n = int(SAMPLE_RATE * seconds)
    t = np.linspace(0.0, seconds, n, endpoint=False, dtype=np.float64)
    tone = 0.35 * np.sin(2.0 * np.pi * 440.0 * t)
    noise = 0.02 * np.random.default_rng(42).standard_normal(n)
    x = np.clip((tone + noise) * 32767.0, -32768.0, 32767.0)
    return x.astype(np.int16)


def _resample_linear_int16(x: np.ndarray, sr_in: int, sr_out: int) -> np.ndarray:
    """Linear resample int16 mono PCM (good enough for VAD smoke tests)."""
    if sr_in == sr_out:
        return x
    xf = x.astype(np.float32, copy=False)
    n_in = int(x.shape[0])
    n_out = max(1, int(round(n_in * sr_out / sr_in)))
    t_in = np.arange(n_in, dtype=np.float64)
    t_out = np.linspace(0.0, float(n_in - 1), n_out, dtype=np.float64)
    yf = np.interp(t_out, t_in, xf)
    return np.clip(np.rint(yf), -32768.0, 32767.0).astype(np.int16)


def load_wav_mono16(path: Path) -> np.ndarray:
    """Load WAV as mono int16 @ SAMPLE_RATE (resamples if needed)."""
    with wave.open(str(path), "rb") as wf:
        ch = wf.getnchannels()
        sw = wf.getsampwidth()
        sr = wf.getframerate()
        if sw != 2:
            raise ValueError(f"Expected 16-bit PCM (sampwidth=2), got {sw}")
        if ch < 1 or ch > 2:
            raise ValueError(f"Expected mono or stereo WAV, got {ch} channels")
        raw = wf.readframes(wf.getnframes())
    interleaved = np.frombuffer(raw, dtype=np.int16).reshape(-1, ch)
    if ch == 1:
        mono = interleaved[:, 0].copy()
    else:
        mono = np.mean(interleaved.astype(np.float32), axis=1)
        mono = np.clip(np.rint(mono), -32768.0, 32767.0).astype(np.int16)
    if sr != SAMPLE_RATE:
        mono = _resample_linear_int16(mono, sr, SAMPLE_RATE)
        print(
            f"Resampled WAV {path.name}: {sr} Hz -> {SAMPLE_RATE} Hz "
            f"({interleaved.shape[0]} -> {mono.shape[0]} samples)",
            file=sys.stderr,
        )
    return mono


def _short_status(msg: str, limit: int = STATUS_PRINT_MAX) -> str:
    if len(msg) <= limit:
        return msg
    return msg[: limit - 3] + "..."


def iter_window_bytes(samples: np.ndarray) -> list[bytes]:
    if samples.ndim != 1:
        raise ValueError("samples must be 1-D")
    out: list[bytes] = []
    n = int(samples.shape[0])
    for start in range(0, n, WINDOW_SAMPLES):
        end = min(start + WINDOW_SAMPLES, n)
        chunk = samples[start:end]
        if chunk.size < WINDOW_SAMPLES:
            pad = np.zeros(WINDOW_SAMPLES - chunk.size, dtype=np.int16)
            chunk = np.concatenate([chunk, pad])
        out.append(chunk.astype(np.int16, copy=False).tobytes())
    return out


def run_one_model(onnx_path: Path, windows: list[bytes], threshold: float) -> Row:
    name = onnx_path.name
    cfg = VadCfg(model_path=str(onnx_path))
    det = VadDetector(cfg, sample_rate=SAMPLE_RATE)
    confs: list[float] = []
    cold_ms: float | None = None
    per_win_ms: list[float] = []

    try:
        t0 = time.perf_counter()
        confs.append(det.confidence(windows[0]))
        cold_ms = (time.perf_counter() - t0) * 1000.0

        for w in windows[1:]:
            t1 = time.perf_counter()
            confs.append(det.confidence(w))
            per_win_ms.append((time.perf_counter() - t1) * 1000.0)

        arr = np.array(confs, dtype=np.float64)
        above = int(np.sum(arr >= threshold))
        avg_win = float(np.mean(per_win_ms)) if per_win_ms else None
        return Row(
            name=name,
            cold_start_ms=cold_ms,
            avg_window_ms=avg_win,
            mean_conf=float(np.mean(arr)),
            max_conf=float(np.max(arr)),
            above_threshold=above,
            windows=len(confs),
            status="OK",
        )
    except Exception as exc:  # noqa: BLE001 — smoke test: report any failure
        return Row(
            name=name,
            cold_start_ms=cold_ms,
            avg_window_ms=None,
            mean_conf=None,
            max_conf=None,
            above_threshold=None,
            windows=len(confs) if confs else 0,
            status=f"FAIL: {exc}",
        )


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Test ONNX VAD models with VadDetector."
    )
    parser.add_argument(
        "--models-dir",
        type=Path,
        default=Path("/media/robotik/store0/models/vad/silero-vad-onnx/onnx"),
        help="Directory containing *.onnx files",
    )
    parser.add_argument(
        "--wav",
        type=Path,
        default=None,
        help="16-bit PCM WAV, mono or stereo; resampled to 16 kHz if needed",
    )
    parser.add_argument(
        "--synthetic-sec",
        type=float,
        default=1.0,
        help="Length of synthetic audio when --wav is omitted",
    )
    parser.add_argument(
        "--threshold",
        type=float,
        default=0.5,
        help="Count windows with confidence >= this value",
    )
    args = parser.parse_args()

    if args.wav is not None:
        samples = load_wav_mono16(args.wav)
    else:
        samples = _synthetic_int16(args.synthetic_sec)

    windows = iter_window_bytes(samples)
    if not windows:
        print("No audio windows to process.", file=sys.stderr)
        return 1

    models = sorted(args.models_dir.glob("*.onnx"))
    if not models:
        print(f"No .onnx files under {args.models_dir}", file=sys.stderr)
        return 1

    rows = [run_one_model(p, windows, args.threshold) for p in models]

    for r in rows:
        if r.status != "OK":
            print(f"{r.name}: {r.status}", file=sys.stderr)

    hdr = (
        f"{'model':<24} {'cold_ms':>10} {'avg_ms':>10} {'mean_c':>8} {'max_c':>8} "
        f"{'>thr':>5} {'n':>4}  status"
    )
    print(hdr)
    print("-" * len(hdr))
    for r in rows:
        cold = f"{r.cold_start_ms:.1f}" if r.cold_start_ms is not None else "—"
        avg = f"{r.avg_window_ms:.2f}" if r.avg_window_ms is not None else "—"
        mc = f"{r.mean_conf:.3f}" if r.mean_conf is not None else "—"
        xc = f"{r.max_conf:.3f}" if r.max_conf is not None else "—"
        ab = str(r.above_threshold) if r.above_threshold is not None else "—"
        nw = str(r.windows) if r.windows is not None else "—"
        st = _short_status(r.status)
        print(
            f"{r.name:<24} {cold:>10} {avg:>10} {mc:>8} {xc:>8} {ab:>5} {nw:>4}  {st}"
        )
    return 0 if all(r.status == "OK" for r in rows) else 2


if __name__ == "__main__":
    raise SystemExit(main())
