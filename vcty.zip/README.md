# AR Voice Controller

<div align="center">

![Python 3.11](https://arfgit.akinsoft.net/akinrobotics/servisler/yapayzeka/wiki/gitlab-badges/-/raw/main/badges/runtime/python_3_11.svg)
![Latest Release](https://arfgit.akinsoft.net/akinrobotics/servisler/yapayzeka/services/voice/voice-controller/-/badges/release.svg)
![Pipeline](https://arfgit.akinsoft.net/akinrobotics/servisler/yapayzeka/services/voice/voice-controller/badges/main/pipeline.svg)
![Coverage Report](https://arfgit.akinsoft.net/akinrobotics/servisler/yapayzeka/services/voice/voice-controller/badges/main/coverage.svg)
![License](https://arfgit.akinsoft.net/akinrobotics/servisler/yapayzeka/wiki/gitlab-badges/-/raw/main/badges/licenses/mit.svg)

<!-- Tech Stack -->

![Linux](https://arfgit.akinsoft.net/akinrobotics/servisler/yapayzeka/wiki/gitlab-badges/-/raw/main/badges/platforms/linux_only.svg)
![uv](https://arfgit.akinsoft.net/akinrobotics/servisler/yapayzeka/wiki/gitlab-badges/-/raw/main/badges/tooling/uv.svg)
![pytest](https://arfgit.akinsoft.net/akinrobotics/servisler/yapayzeka/wiki/gitlab-badges/-/raw/main/badges/tooling/pytest.svg)
![Pydantic](https://arfgit.akinsoft.net/akinrobotics/servisler/yapayzeka/wiki/gitlab-badges/-/raw/main/badges/dependencies/pydantic.svg)
![OpenAI](https://arfgit.akinsoft.net/akinrobotics/servisler/yapayzeka/wiki/gitlab-badges/-/raw/main/badges/dependencies/openai.svg)
![ONNX Runtime](https://arfgit.akinsoft.net/akinrobotics/servisler/yapayzeka/wiki/gitlab-badges/-/raw/main/badges/inference_engines/onnx.svg)
![NumPy](https://arfgit.akinsoft.net/akinrobotics/servisler/yapayzeka/wiki/gitlab-badges/-/raw/main/badges/dependencies/numpy.svg)
![portaudio](https://arfgit.akinsoft.net/akinrobotics/servisler/yapayzeka/wiki/gitlab-badges/-/raw/main/badges/dependencies/portaudio.svg)
![ffmpeg](https://arfgit.akinsoft.net/akinrobotics/servisler/yapayzeka/wiki/gitlab-badges/-/raw/main/badges/dependencies/ffmpeg.svg)
![pre-commit](https://arfgit.akinsoft.net/akinrobotics/servisler/yapayzeka/wiki/gitlab-badges/-/raw/main/badges/tooling/pre_commit.svg)
![Ruff](https://arfgit.akinsoft.net/akinrobotics/servisler/yapayzeka/wiki/gitlab-badges/-/raw/main/badges/tooling/ruff.svg)

</div>

Real-time voice dialog service for Akinrobotics robots: captures microphone audio (with VAD and echo cancellation), streams speech to text, drives a streaming LLM policy, and plays synthesized replies. Turn-taking, barge-in, and telemetry hooks are built around an internal event bus.

## Requirements

- **Python 3.11** only (the vendored `aec-audio-processing` wheel matches **CPython 3.11** on Linux x86_64.)
- **Linux** (dependencies and wheels are oriented toward POSIX/Linux)
- Working **audio I/O** (microphone and speakers)
- **OpenAI API** access for ASR, chat, and TTS (set `OPENAI_API_KEY` unless keys are supplied in config)

### System packages (Debian / Ubuntu)

Install these once so PortAudio-backed audio (`sounddevice`) and typical media tooling are available. Python itself is left to **`uv`** (`uv sync`, or `uv python install` if you want a pinned toolchain).

```bash
sudo apt update
sudo apt install -y ffmpeg libportaudio2 portaudio19-dev
```

- **`ffmpeg`** — common dependency for audio tooling and codecs.
- **`libportaudio2`** / **`portaudio19-dev`** — PortAudio runtime and headers for building or using native audio bindings.

## Install (uv)

From the repository root:

```bash
uv sync
```

To include development tools (pre-commit, pytest, coverage):

```bash
uv sync --group dev
```

## Configuration

- **YAML:** pass `--config path/to/config.yaml` (default: `config.yaml` if that file exists).
- **Environment:** create a `.env` in the project root for secrets such as `OPENAI_API_KEY`.
- **Overrides:** any setting can be layered with `AVC_`-prefixed variables (nested keys use `__`), merged on top of the YAML file—see `src/ar_voice_controller/config/loader.py` for the merge rules.

Examples of `AVC_` overrides:

```bash
AVC_LLM__API_KEY=sk-...
AVC_AUDIO__SAMPLE_RATE=16000
AVC_LLM__MODEL=gpt-4o
```

## Run

```bash
uv run ar-voice-controller
```

With an explicit config file:

```bash
uv run ar-voice-controller --config /path/to/config.yaml
```

## Extra tooling

- **`ar-voice-monitor`** — Tails JSON events from the FIFO used when the pipeline runs with the in-process bus (default path `/tmp/voice_bus`). Pretty-prints topics (audio, ASR, LLM, TTS, dialog state, errors, etc.) or `--json` for raw lines. Run in a second terminal while the controller is up:

  ```bash
  uv run ar-voice-monitor
  uv run ar-voice-monitor --path /tmp/my_bus
  uv run ar-voice-monitor --json
  ```

## Testing

Run the full unit test suite (coverage enforced at ≥ 65 %):

```bash
uv run pytest
```

Tests that require hardware or external services are gated behind markers and skipped by default:

```bash
# skip hardware/network-dependent tests
uv run pytest -m "not requires_audio_hw and not requires_onnx_model and not requires_openai"
```

Available markers:

| Marker | Description |
|---|---|
| `slow` | Deselect with `-m "not slow"` for a faster run |
| `integration` | Full pipeline integration tests |
| `requires_audio_hw` | Needs PortAudio / sounddevice runtime |
| `requires_onnx_model` | Needs Silero VAD ONNX model on disk |
| `requires_openai` | Needs a reachable OpenAI-compatible endpoint |

## Development

Pre-commit hooks enforce linting (`ruff`), formatting (`ruff-format`), complexity (`complexipy ≤ 20`), and basic hygiene. Install once and run before pushing:

```bash
uv run pre-commit install
uv run pre-commit run --all-files
```

To run ruff manually:

```bash
uv run ruff check src/ tests/
uv run ruff format src/ tests/
```

## Contributing

See [`CONTRIBUTING.md`](./CONTRIBUTING.md) for the full development workflow, commit-message conventions, architectural guardrails, and release process.

- Use **merge requests** against `main`; keep changes focused.
- Update `CHANGELOG.md` under `[Unreleased]` for every user-visible change.
- Report bugs via GitLab **issues**: include the command, relevant config (secrets redacted), and a recent `ar-voice-monitor` transcript.

## Changelog

See [`CHANGELOG.md`](./CHANGELOG.md) for release notes.
