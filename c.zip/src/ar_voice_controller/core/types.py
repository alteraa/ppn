from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, auto
from typing import Any, Protocol

from ..runtime.event_types import FinalTranscript
from .cancellation import CancellationToken


class TurnState(Enum):
    IDLE = auto()
    LISTENING = auto()
    PROCESSING = auto()
    SPEAKING = auto()
    COOLDOWN = auto()


@dataclass(slots=True)
class TurnContext:
    turn_id: int
    token: CancellationToken
    transcript: FinalTranscript


@dataclass(slots=True)
class PolicyResult:
    full_text: str
    emitted_segments: int


class DialogPolicy(Protocol):
    def run(self, ctx: TurnContext) -> PolicyResult: ...


class ToolRegistry:
    def __init__(self) -> None:
        self._tools: dict[str, Any] = {}

    def register(self, name: str, tool: Any) -> None:
        self._tools[name] = tool

    def list(self) -> list[Any]:
        return list(self._tools.values())

    def get(self, name: str) -> Any | None:
        return self._tools.get(name)
