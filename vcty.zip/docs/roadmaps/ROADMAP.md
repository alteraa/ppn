# Roadmap

This roadmap consolidates the architectural discussions around the AR Voice
Controller and prioritises work needed to support **MCP-driven tool calling**
and **real-time / asynchronous** operation.

Each item is annotated with:

- **Refactor size** — rough effort estimate: **S** (hours), **M** (days),
  **L** (weeks).
- **Fit** — how well the existing code already supports the work, on a
  **0-10** scale. Higher is better (closer to drop-in).

The order below is the recommended execution order.

---

## Tier 1 — Unblock MCP & async tool calls

These items are prerequisites for integrating MCP and tolerating slow,
asynchronous tools without breaking real-time conversational feel.

### 1. Fix counter carry-over across `PROCESSING → SPEAKING`
- **Refactor size:** S
- **Fit:** 9/10
- Problem: `InterruptDetector._counter` is shared between `update` (SPEAKING)
  and `update_vad_only` (PROCESSING). If the user keeps talking across an
  auto-promotion, the SPEAKING grace does not reset the counter and a
  barge-in can fire earlier than intended.
- Suggested change: add `InterruptDetector.clear_counter()` and call it in
  `TurnManager._maybe_promote_to_speaking()` and/or on every state
  transition. Alternatively, maintain a dedicated `_vad_counter`.
- Touched files: `src/ar_voice_controller/audio/interrupt.py`,
  `src/ar_voice_controller/core/manager.py`.

### 2. Introduce a turn-level timeout
- **Refactor size:** S
- **Fit:** 8/10
- Problem: there is no hard ceiling on how long a turn may live. A slow or
  hung MCP tool could keep the turn in `PROCESSING` indefinitely. Only
  external interrupts, HTTP timeouts, or SIGINT break the loop today.
- Suggested change:
  - Add `turn.max_turn_sec` and `tool.timeout_sec` to a new `TurnCfg`/`ToolCfg`
    section (or extend `InterruptCfg`).
  - In the `TurnManager` main loop, check `time.time() - active_turn_started_at`
    and call `active_token.cancel(InterruptCause.TIMEOUT)` when exceeded.
  - `InterruptCause.TIMEOUT` already exists but is unused.
- Touched files: `config/audio.py`, `core/manager.py`, `config.yaml`.

### 3. Cancellation contract with the LLM service
- **Refactor size:** M
- **Fit:** 7/10
- Problem: when the user barges in, voice-controller cancels the in-process
  `CancellationToken`. If the LLM service is remote and is in the middle of a
  tool call, it must also abort the tool and must not persist a half-written
  assistant reply.
- Suggested change:
  - Standardise on a per-turn correlation ID header (e.g. `X-Turn-ID`).
  - Implement one of:
    - Close HTTP stream → service treats closed connection as cancel.
    - Optional `POST /turns/{turn_id}/cancel` endpoint for explicit cancel.
  - Service-side rollback protocol: drop the partial assistant message from
    its own context when a cancel is observed.
- Touched files: `providers/llm.py`, LLM service (out of scope here) +
  integration glue in `core/policy.py`.

### 4. Filler / intermediate-text protocol during tool waits
- **Refactor size:** S-M
- **Fit:** 9/10
- Problem: while the LLM is waiting on a slow tool, the robot is silent
  because the LLM stream pauses. This produces dead air and undermines the
  conversational feel.
- Suggested change:
  - Require the LLM service to emit short filler text ("bir saniye
    bakıyorum…") during tool waits, as normal content deltas on the same
    stream.
  - No change to voice-controller needed — TTS already plays segments as they
    arrive. Document the contract and add minimal guarding in `policy.py` if
    filler segments should be de-duplicated in history.
  - Optionally expose a `/llm/keepalive` topic for observability.
- Touched files: `providers/llm.py` (docs only), telemetry event types.

### 5. Wire `ExternalStopSource` into the pipeline
- **Refactor size:** S
- **Fit:** 10/10
- Problem: `ExternalStopSource` exists in `audio/interrupt.py` but is not
  instantiated in `Pipeline`. External (non-voice) interrupts therefore
  cannot be fired by ROS topics, REST endpoints, or safety systems.
- Suggested change:
  - Instantiate `ExternalStopSource` inside `Pipeline.__init__` and expose it.
  - Add a small ROS bridge (or REST endpoint) that forwards chosen topics
    (e.g. `/camera/face_detected`, `/safety/stop`) into
    `external_stop.trigger(cause=...)`.
  - Consider adding a new `InterruptCause` per external source for clarity
    (unknown causes already fall back to `EXTERNAL_STOP`).
- Touched files: `pipeline.py`, optionally a new `runtime/external_bridge.py`.

### 6. Tool-event pass-through telemetry
- **Refactor size:** S-M
- **Fit:** 8/10
- Problem: `ToolCallRequested` / `ToolCallCompleted` event types exist but
  are never emitted. When the LLM service owns tool execution, the voice
  controller loses visibility of what the assistant did.
- Suggested change:
  - Add a secondary SSE/WebSocket channel (or a `tool_events` block inside
    the LLM stream) carrying tool start/finish events.
  - Parse these in `providers/llm.py` and publish to `/tools/requested` and
    `/tools/completed`.
  - `ar-voice-monitor` already pretty-prints arbitrary topics, so it will
    show up without UI changes.
- Touched files: `providers/llm.py`, `runtime/event_types.py` (no schema
  change needed).

---

## Tier 2 — Cleaner runtime around MCP

These are improvements that make MCP integration sustainable and easier to
reason about, even if the tools themselves live in the LLM service.

### 7. Refactor providers to HTTP clients for your existing services
- **Refactor size:** M
- **Fit:** 9/10
- Providers are already `Protocol`-typed, so swapping `OpenAiXxxClient` for
  `HttpXxxClient` implementations is mostly a contained change. Biggest
  reduction in code lives in `providers/llm.py` + `core/policy.py` once
  history/system-prompt/tool logic moves server-side.
- Care areas:
  - LLM streaming: preserve the `Iterator[LlmDelta]` shape using SSE or
    chunked JSON.
  - Cancellation: after each chunk call `token.raise_if_cancelled()`, mirror
    existing behaviour with `httpx` stream iteration.
  - TTS audio: prefer streamed PCM to avoid buffering complete WAVs.
- Touched files: `providers/sr.py`, `providers/llm.py`, `providers/tts.py`,
  `config/{asr,llm,tts}.py`.

### 8. Generalise `TurnContext` (trigger abstraction)
- **Refactor size:** M
- **Fit:** 6/10
- Problem: `TurnContext.transcript: FinalTranscript` hard-codes the idea
  that every turn starts from ASR. Tool-initiated follow-ups, vision
  triggers, or scheduled turns cannot reuse the pipeline.
- Suggested change:
  - Replace `transcript` with `trigger: TurnTrigger` (tagged union of
    `VoiceTrigger(transcript=...)`, `VisionTrigger(payload=...)`,
    `ExternalTextTrigger(text=...)`, etc.).
  - Update `DialogPolicy.run` and `AsrProcessingWorker` to accept the
    generic trigger; rename worker to `TurnWorker` with ASR as one source.
  - `StreamingLlmPolicy.run` builds prompts based on trigger type.
- Touched files: `core/types.py`, `core/worker.py`, `core/policy.py`,
  `core/manager.py`.

### 9. Expose a `/turn/external_request` channel in `TurnManager`
- **Refactor size:** M
- **Fit:** 6/10
- Problem: new turns can only be started by the VAD pipeline reaching
  `LISTENING`. To support vision-triggered greetings, scheduled messages,
  or tool-initiated follow-ups, an event-driven entry point is required.
- Suggested change:
  - Subscribe `TurnManager` to a new topic (e.g. `/turn/external_request`).
  - Allow direct transition `IDLE → PROCESSING` with a non-voice trigger.
  - Keep backward compatibility by leaving VAD path untouched.
- Depends on item 8.

### 10. Split `TTSPlayer` so synthesis can be reused standalone
- **Refactor size:** M
- **Fit:** 5/10
- Problem: `OpenAiTtsClient` is already clean and reusable, but `TTSPlayer`
  is pipeline-specific (depends on `AudioIO`, `EventBus`, `CancellationToken`,
  segment markers, three daemon threads).
- Suggested change:
  - Keep `TTSPlayer` as-is for the pipeline.
  - Extract a thin `tts.synthesize_to_pcm(text, cfg) -> np.ndarray` helper
    in `providers/tts.py` for external consumers. Document it in the README.
- Touched files: `providers/tts.py`, optional new tiny public module.

---

## Tier 3 — Long-horizon extensions

These stretch the system's role from "voice-controller" to a more general
conversational orchestrator. They become relevant once Tiers 1 and 2 are
stable.

### 11. Voice-controller as MCP orchestrator (alternative to LLM-side tools)
- **Refactor size:** L
- **Fit:** 4/10
- Only relevant if certain tools must live in the voice-controller process
  (e.g. robot motor control, camera access, RTOS-local state).
- Requires:
  - Real `ToolRegistry` backed by one or more `McpClient` transports
    (stdio/SSE/WebSocket).
  - Multi-round policy loop: stream → tool call → invoke → feed result
    back → stream (round N+1).
  - Parallel tool execution (likely an async-capable layer alongside the
    current thread-based pipeline).
  - In-process filler generation during tool awaits.
  - MCP cancel-request mapping from `CancellationToken`.
- Touched files: large; likely a new `providers/mcp/` subpackage plus
  significant rework in `core/policy.py`.

### 12. State machine extensibility
- **Refactor size:** M
- **Fit:** 6/10
- Problem: `TurnState` is an enum with ad-hoc `if/elif` dispatch. Adding
  states (e.g. `COOLDOWN` is defined but not handled, or a future
  `TOOL_WAITING`, `SUSPENDED`) is doable but brittle.
- Suggested change:
  - Replace `_dispatch_audio_chunk` if/elif with a dict `{State: handler}`.
  - Formalise valid transitions to catch invalid jumps in tests.
  - Add explicit support for `TOOL_WAITING` once tool-event telemetry is in
    place.

### 13. Testing & regression safety
- **Refactor size:** M
- **Fit:** 4/10 (repository currently lacks visible test coverage)
- High-value first targets:
  - Interrupt flow (voice + external + timeout) via stubbed VAD and bus.
  - `CaptureController` VAD debounce / silence / barge-in rewind.
  - Cancellation propagation through `CancellationToken.child()`.
  - Policy streaming with simulated LLM deltas.
- Suggested change:
  - Scaffold `tests/` with pytest, wire into the existing `pre-commit`.
  - Make providers fully injectable in `Pipeline` so fakes can be plugged
    during tests (already almost possible thanks to `Protocol` typing).

### 14. Multi-robot / fleet considerations
- **Refactor size:** L
- **Fit:** 5/10
- Current architecture is single-process, single-robot, with optional ROS
  bus. Running many robots against the same set of model services is
  supported at the provider layer but not at orchestration (history,
  telemetry, correlation).
- Likely changes:
  - Robot-ID / session-ID propagation end-to-end.
  - Centralised event ingestion (FIFO sink → message broker).
  - Context management fully externalised (matches the "history in LLM
    service" direction).

---

## Cross-cutting principles

- **Keep providers `Protocol`-based** — it is the single biggest reason the
  system can migrate smoothly.
- **Keep interrupts topic-driven** — any new interrupt source should publish
  to `/interrupt/requested`; never introduce side-channels.
- **Instrument before refactoring** — `ar-voice-monitor` plus FIFO sink
  makes large changes tractable; keep adding event types rather than logs.
- **Prefer event-bus fan-out to method calls** — new cross-cutting features
  (tool events, timeouts, external triggers) should ride the bus.

---

## Quick reference — priority order

1. Counter carry-over fix — **S, 9/10**
2. Turn-level timeout — **S, 8/10**
3. Cancellation contract with LLM service — **M, 7/10**
4. Filler / intermediate-text protocol — **S-M, 9/10**
5. Wire `ExternalStopSource` into pipeline — **S, 10/10**
6. Tool-event pass-through telemetry — **S-M, 8/10**
7. HTTP provider refactor — **M, 9/10**
8. Generalise `TurnContext` (trigger abstraction) — **M, 6/10**
9. `/turn/external_request` channel in `TurnManager` — **M, 6/10**
10. Split `TTSPlayer` for standalone synthesis — **M, 5/10**
11. In-process MCP orchestrator — **L, 4/10**
12. State machine extensibility — **M, 6/10**
13. Testing & regression safety — **M, 4/10**
14. Multi-robot / fleet orchestration — **L, 5/10**

---

## Future Integration

This section tracks the migration of the voice-controller onto the three
in-house REST services located alongside this project:

- **ASR:** `asr-api/` — FastAPI + `faster-whisper`, OpenAI-compatible
  `/v1/audio/transcriptions` and a minimal `/v1/audio/inference`.
- **LLM:** `service-robot-chatbot/` — FastAPI + Redis + AsyncOpenAI, custom
  routes (`/chat`, `/chat/stream` via SSE), server-side session / history /
  system-prompt / tool definitions, client-executed OpenAI tool calls.
- **TTS:** `tts-api/` — FastAPI + piper-tts + ONNX, OpenAI-compatible
  `/v1/audio/speech` plus a richer `/v1/audio/inference` (speaker, length,
  noise, Turkish verbalisation).

Execution order below is the recommended migration sequence — start with
the drop-in pieces (ASR, TTS) and tackle the LLM paradigm shift last.

### FI-1. ASR service migration
- **Refactor size:** S
- **Fit:** 9/10
- The `asr-api/` exposes an OpenAI-compatible `/v1/audio/transcriptions`
  endpoint. `OpenAiAsrClient` can talk to it with no code change — only
  config updates are needed.
- Suggested change:
  - Point `AsrCfg.base_url` at the service (e.g. `http://127.0.0.1:8008/v1`).
  - Set `AsrCfg.model` to a discovered model name (e.g. `large-v3`).
  - Drop the `OPENAI_API_KEY` requirement; the service accepts any token.
  - Keep `response_format="verbose_json"` to preserve language detection.
- Optional follow-up: prefer `/v1/audio/inference` (minimal schema) once the
  pipeline stops needing `language` metadata from the verbose response.
- Touched files: `config.yaml`, `config/asr.py` (defaults only).

### FI-2. TTS service migration
- **Refactor size:** S
- **Fit:** 9/10
- `tts-api/` exposes OpenAI-compatible `/v1/audio/speech` returning PCM
  bytes. `OpenAiTtsClient` already consumes PCM and resamples, so the swap
  is essentially a base-URL change.
- Suggested change:
  - Point `TtsCfg.base_url` at the TTS service.
  - Map `TtsCfg.voice_by_language` to the piper model IDs in the service
    (e.g. `{"tr": "tr_female_ada", "en": "en_male_ryan"}`).
  - Keep `response_format="pcm"`; honour `X-Sample-Rate` header if we start
    relying on it for resampling decisions.
- Touched files: `providers/tts.py` (header-aware resampling is optional),
  `config/tts.py`, `config.yaml`.

### FI-3. TTS verbalisation & richer synthesis parameters
- **Refactor size:** S
- **Fit:** 7/10
- `tts-api/` `/v1/audio/inference` exposes `verbalize` (Turkish number /
  date / unit normalisation via `text2verb`), `length_scale`, `noise_scale`,
  `speaker_id`. The OpenAI endpoint hides these.
- Suggested change:
  - Add a second client path (`synthesize_inference`) in `providers/tts.py`
    that targets `/v1/audio/inference` when enabled.
  - Surface `verbalize`, `length_scale`, etc. in `TtsCfg`.
  - Keep OpenAI path as the default for portability.
- Touched files: `providers/tts.py`, `config/tts.py`.

### FI-4. LLM streaming adapter (SSE → `LlmDelta`)
- **Refactor size:** M
- **Fit:** 7/10
- `service-robot-chatbot/` streams raw OpenAI chunk dicts as SSE frames on
  `POST /chat/stream`. The current `OpenAiLlmClient.chat_stream` yields
  `ContentDelta | ToolCallDelta | DoneDelta` from the OpenAI SDK.
- Suggested change:
  - Add `HttpLlmClient` in `providers/llm.py` using `httpx` SSE streaming.
  - Translate each chunk dict into `ContentDelta` / `ToolCallDelta` /
    `DoneDelta` so `StreamingLlmPolicy` does not change.
  - Preserve cancellation: call `token.raise_if_cancelled()` between chunks
    and on the connection's `finally` path.
  - Keep `OpenAiLlmClient` available for standalone / bypass modes.
- Touched files: `providers/llm.py`, `config/llm.py`.

### FI-5. LLM session + API-key lifecycle
- **Refactor size:** S-M
- **Fit:** 6/10
- `service-robot-chatbot/` requires an `x-session-id` header and expects the
  OpenAI API key to be registered once via `POST /session`. Without this,
  every `/chat` call fails with 401.
- Suggested change:
  - Generate a stable `session_id` per voice-controller instance (UUID per
    process or persisted to disk).
  - On startup, call `POST /session` with the API key from config/env.
  - Attach `x-session-id` to every LLM request.
  - Optional: support backup/restore via `/session/{id}/restore` and
    `/export` for robots that must resume conversations after a restart.
- Touched files: `providers/llm.py`, new small `providers/llm_session.py`
  helper, `config/llm.py`.

### FI-6. Context ownership migration
- **Refactor size:** M
- **Fit:** 5/10
- With server-side Redis history in `service-robot-chatbot/`, the
  voice-controller's `InMemoryHistory` becomes redundant and, worse,
  competing: both sides would prepend their own view of history.
- Suggested change:
  - Stop appending to `InMemoryHistory` in `StreamingLlmPolicy.run`; let
    the LLM service own history (it saves user and aggregated assistant
    messages automatically).
  - Replace `history.snapshot()` in `build_messages` with server-side
    behaviour — send only the new user message; the service prepends its
    own history and system prompt.
  - Keep `InMemoryHistory` as an optional local implementation for
    offline/testing mode (feature-flagged).
- Touched files: `core/policy.py`, `providers/llm.py`, possibly
  `providers/__init__.py` (stop wiring `InMemoryHistory` in `Pipeline`).

### FI-7. Tool execution bridge
- **Refactor size:** M-L
- **Fit:** 4/10
- `service-robot-chatbot/` returns OpenAI `tool_calls` in the stream but
  does **not** execute tools itself; it expects the client to run the tool
  and post back a `role="tool"` message. The voice-controller currently has
  no tool execution loop — `ToolCallDelta` is just surfaced, never handled.
- Two compatible paths:
  - **A. Move execution into the LLM service.** Add a tool-runner layer
    (MCP client or HTTP proxy) inside `service-robot-chatbot/`; the
    voice-controller sees only final content deltas. Minimal impact on
    voice-controller code.
  - **B. Execute tools in the voice-controller.** Build a real
    `ToolRegistry` + multi-round policy loop: stream → tool_call → invoke
    → `POST /chat` with `role="tool"` → continue stream. See Tier 3
    item 11 for the full-blown MCP version.
- Recommended: start with A for MCP simplicity, add B later only for
  tools that must run in-process (robot motors, camera, local state).
- Touched files: `core/policy.py`, `providers/llm.py`, optional new
  `providers/mcp/` (for B).

### FI-8. Per-turn cancellation + rollback with LLM service
- **Refactor size:** M
- **Fit:** 5/10
- Problem: `POST /chat/stream` auto-aggregates the assistant reply and
  persists it to Redis when the stream closes. If the user barges in
  mid-stream, a partial, possibly nonsensical assistant message ends up in
  the history. There is no turn-level cancel or rollback endpoint — only
  `DELETE /history` which nukes the whole session.
- Suggested change (coordinated with the LLM service):
  - Add an `x-turn-id` header on every streaming request.
  - Add a service endpoint like `POST /chat/{turn_id}/cancel` that aborts
    the in-flight LLM call **and** drops the partial assistant message
    before it is written to Redis.
  - Alternatively, defer the history write until the client acknowledges
    completion (`X-Commit: true` on final chunk), so closing mid-stream
    implicitly discards the partial reply.
  - On voice-controller side: in `_handle_cancelled_active_turn`, fire the
    cancel call when `cause == VOICE_BARGE_IN`.
- Depends on Tier 1 item 3. Touched files: `providers/llm.py`,
  `core/manager.py`, LLM service (out of scope for this repo but required).

### FI-9. Observability: surface model / session events
- **Refactor size:** S
- **Fit:** 8/10
- Each service exposes extra diagnostic headers and state:
  - ASR hot-swaps models → no event today, just a log.
  - TTS returns `X-Model-Id`, `X-Sample-Rate`.
  - LLM service exposes `/history`, `/tools`, `/export`.
- Suggested change:
  - Capture headers from ASR/TTS responses and publish lightweight events
    (`AsrModelLoaded`, `TtsModelUsed`) to the event bus.
  - Add a health probe that hits `/v1/audio/models` (ASR/TTS) and the
    LLM service health route on startup; emit `ServiceStateChanged` with
    per-provider readiness.
- Touched files: `providers/sr.py`, `providers/tts.py`, new event types in
  `runtime/event_types.py`, monitor pretty-printer (auto-renders).

### FI-10. Deployment alignment
- **Refactor size:** S
- **Fit:** 7/10
- All three services ship as `.deb` packages and / or Dockerfiles with
  well-defined ports. The voice-controller should standardise its own
  deployment story around them.
- Suggested change:
  - Document default ports (ASR :8008, LLM :8000, TTS :8020) in
    `config.yaml` and README.
  - Provide a `docker-compose.yaml` (or systemd bundle) that brings up all
    four services with shared model volumes.
  - Add network-readiness retries in provider clients so startup order
    does not require strict sequencing.
- Touched files: `config.yaml`, README, new `deploy/` directory.

---

### Quick reference — Future Integration order

1. **FI-1** ASR service migration — **S, 9/10**
2. **FI-2** TTS service migration — **S, 9/10**
3. **FI-3** TTS verbalisation & richer synthesis parameters — **S, 7/10**
4. **FI-4** LLM streaming adapter (SSE → `LlmDelta`) — **M, 7/10**
5. **FI-5** LLM session + API-key lifecycle — **S-M, 6/10**
6. **FI-6** Context ownership migration — **M, 5/10**
7. **FI-7** Tool execution bridge — **M-L, 4/10**
8. **FI-8** Per-turn cancellation + rollback with LLM service — **M, 5/10**
9. **FI-9** Observability: surface model / session events — **S, 8/10**
10. **FI-10** Deployment alignment — **S, 7/10**
