const ALL_TOPICS = [
  "/service/state",
  "/dialog/turn/state",
  "/audio/speech_detected",
  "/audio/speech_ended",
  "/asr/final",
  "/llm/text_delta",
  "/dialog/assistant/segment",
  "/dialog/assistant/done",
  "/tts/playback_started",
  "/tts/segment_started",
  "/tts/audio_frame",
  "/tts/playback_ended",
  "/interrupt/requested",
  "/interrupt/honored",
  "/metrics/turn",
  "/error",
  "/system/dropped",
];

const topicList = document.getElementById("topic-list");
const terminal = document.getElementById("terminal");
const selectionInfo = document.getElementById("selection-info");
const selectAllBtn = document.getElementById("select-all");
const clearAllBtn = document.getElementById("clear-all");
const clearTerminalBtn = document.getElementById("clear-terminal");
const toggleSimBtn = document.getElementById("toggle-sim");
const connectionStatus = document.getElementById("connection-status");

const selectedTopics = new Set(ALL_TOPICS);
let simulationOn = true;
let simulationTimer = null;
let eventSource = null;

function formatNow() {
  return new Date().toLocaleTimeString("tr-TR", { hour12: false });
}

function safeStringify(payload) {
  if (typeof payload === "string") {
    return payload;
  }
  try {
    return JSON.stringify(payload);
  } catch (error) {
    return String(payload);
  }
}

function topicColor(topic) {
  let hash = 0;
  for (let i = 0; i < topic.length; i += 1) {
    hash = (hash * 31 + topic.charCodeAt(i)) >>> 0;
  }
  const hue = hash % 360;
  return `hsl(${hue} 85% 72%)`;
}

function updateSelectionInfo() {
  selectionInfo.textContent = `${selectedTopics.size} topic secili`;
}

function setConnectionState(connected) {
  connectionStatus.classList.toggle("connected", connected);
  connectionStatus.classList.toggle("disconnected", !connected);
  connectionStatus.textContent = connected
    ? "Canli akis: bagli"
    : "Canli akis: bagli degil";
}

function addTerminalLine(topic, payload) {
  if (!selectedTopics.has(topic)) {
    return;
  }

  const line = document.createElement("div");
  line.className = "line";
  line.style.setProperty("--topic-color", topicColor(topic));
  line.innerHTML = `
    <span class="line-time">${formatNow()}</span>
    <span class="line-topic">${topic}</span>
    <span class="line-payload">${safeStringify(payload)}</span>
  `;
  terminal.appendChild(line);
  terminal.scrollTop = terminal.scrollHeight;
}

function renderTopics() {
  topicList.innerHTML = "";
  ALL_TOPICS.forEach((topic) => {
    const item = document.createElement("li");
    item.className = "topic-item";

    const id = `topic-${topic.replaceAll("/", "_")}`;
    item.innerHTML = `
      <input id="${id}" type="checkbox" ${selectedTopics.has(topic) ? "checked" : ""} />
      <label class="topic-name" for="${id}">${topic}</label>
    `;

    const input = item.querySelector("input");
    input.addEventListener("change", () => {
      if (input.checked) {
        selectedTopics.add(topic);
      } else {
        selectedTopics.delete(topic);
      }
      updateSelectionInfo();
    });

    topicList.appendChild(item);
  });
  updateSelectionInfo();
}

function randomTopic() {
  const idx = Math.floor(Math.random() * ALL_TOPICS.length);
  return ALL_TOPICS[idx];
}

function mockPayload(topic) {
  return {
    topic,
    turn_id: Math.floor(Math.random() * 100),
    at: Date.now(),
    message: "Ornek event",
  };
}

function startSimulation() {
  stopSimulation();
  simulationTimer = window.setInterval(() => {
    const topic = randomTopic();
    addTerminalLine(topic, mockPayload(topic));
  }, 750);
}

function stopSimulation() {
  if (simulationTimer !== null) {
    window.clearInterval(simulationTimer);
    simulationTimer = null;
  }
}

function toggleSimulation() {
  simulationOn = !simulationOn;
  toggleSimBtn.textContent = `Simulasyon: ${simulationOn ? "Acik" : "Kapali"}`;
  if (simulationOn) {
    startSimulation();
  } else {
    stopSimulation();
  }
}

function connectLiveStream() {
  if (!window.EventSource) {
    setConnectionState(false);
    return;
  }
  try {
    eventSource = new EventSource("/events");
  } catch (error) {
    setConnectionState(false);
    return;
  }

  eventSource.onopen = () => {
    setConnectionState(true);
    if (simulationOn) {
      simulationOn = false;
      toggleSimBtn.textContent = "Simulasyon: Kapali";
      stopSimulation();
    }
  };

  eventSource.onmessage = (message) => {
    try {
      const parsed = JSON.parse(message.data);
      const topic = parsed.topic || "/unknown";
      addTerminalLine(topic, parsed);
    } catch (error) {
      addTerminalLine("/decode/error", message.data);
    }
  };

  eventSource.onerror = () => {
    setConnectionState(false);
  };
}

selectAllBtn.addEventListener("click", () => {
  ALL_TOPICS.forEach((topic) => selectedTopics.add(topic));
  renderTopics();
});

clearAllBtn.addEventListener("click", () => {
  selectedTopics.clear();
  renderTopics();
});

clearTerminalBtn.addEventListener("click", () => {
  terminal.innerHTML = "";
});

toggleSimBtn.addEventListener("click", () => {
  toggleSimulation();
});

/**
 * Dis kaynaklardan ortak terminale event basmak icin global API.
 * Ornek: window.TopicMonitor.publish("/asr/final", { text: "Merhaba" });
 */
window.TopicMonitor = {
  publish(topic, payload) {
    addTerminalLine(topic, payload);
  },
  setTopics(topics) {
    if (!Array.isArray(topics) || topics.length === 0) {
      return;
    }
    ALL_TOPICS.length = 0;
    topics.forEach((topic) => {
      ALL_TOPICS.push(topic);
      selectedTopics.add(topic);
    });
    renderTopics();
  },
};

renderTopics();
startSimulation();
connectLiveStream();
