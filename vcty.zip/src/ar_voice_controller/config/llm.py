from __future__ import annotations

from pydantic import BaseModel


class LlmCfg(BaseModel):
    base_url: str | None = None
    api_key: str | None = None
    model: str = "gpt-4.1-mini"
    timeout_sec: float = 60.0
    max_history: int = 10
    min_tts_segment_chars: int = 40
    target_tts_segment_chars: int = 90
    max_tts_segment_chars: int = 140
    system_prompt_path: str = "src/ar_voice_controller/prompts/system_tr.md"
