from ..config import (
    AsrCfg,
    AudioCfg,
    InterruptCfg,
    LlmCfg,
    RuntimeCfg,
    Settings,
    TtsCfg,
    VadCfg,
    load_settings,
)
from .event_types import (
    EVENT_TYPES,
    AssistantDone,
    AssistantSegment,
    DroppedEvent,
    ErrorEvent,
    FinalTranscript,
    InterruptHonored,
    InterruptRequested,
    LlmTextDelta,
    ServiceStateChanged,
    ToolCallCompleted,
    ToolCallRequested,
    TtsAudioFrame,
    TtsPlaybackEnded,
    TtsPlaybackStarted,
    TurnMetrics,
    TurnStateChanged,
    UserSpeechDetected,
    UserSpeechEnded,
    decode_event,
    encode_event,
)
from .events import EventBus, InProcessBus


def make_event_bus(cfg: RuntimeCfg) -> EventBus:
    """Return a bus implementation according to ``cfg.bus``.

    ROS backend is imported lazily so the in-process default keeps working on
    machines without ROS Python bindings installed.
    """
    if cfg.bus == "ros":
        from .ros_bus import RosBus

        return RosBus(
            ros_version=cfg.ros_version,
            node_name=cfg.ros_node_name,
            namespace=cfg.ros_namespace,
        )
    return InProcessBus()


__all__ = [
    "AsrCfg",
    "AssistantDone",
    "AssistantSegment",
    "AudioCfg",
    "DroppedEvent",
    "EVENT_TYPES",
    "ErrorEvent",
    "EventBus",
    "FinalTranscript",
    "InProcessBus",
    "InterruptCfg",
    "InterruptHonored",
    "InterruptRequested",
    "LlmCfg",
    "LlmTextDelta",
    "RuntimeCfg",
    "ServiceStateChanged",
    "Settings",
    "ToolCallCompleted",
    "ToolCallRequested",
    "TtsAudioFrame",
    "TtsCfg",
    "TtsPlaybackEnded",
    "TtsPlaybackStarted",
    "TurnMetrics",
    "TurnStateChanged",
    "UserSpeechDetected",
    "UserSpeechEnded",
    "VadCfg",
    "decode_event",
    "encode_event",
    "load_settings",
    "make_event_bus",
]
