from __future__ import annotations

import threading
from collections.abc import Callable
from typing import Literal, Protocol, cast

RosVersion = Literal["auto", "ros1", "ros2"]


class _StdStringMsg(Protocol):
    data: str


class _RosStringPublisher(Protocol):
    def publish(self, msg: object) -> None: ...


class _Ros1SubscriptionHandle(Protocol):
    def unregister(self) -> None: ...


class _RosBackend(Protocol):
    version: str

    def make_publisher(self, topic: str, queue_size: int) -> object: ...

    def publish(self, publisher: _RosStringPublisher, payload: str) -> None: ...

    def subscribe(
        self, topic: str, callback: Callable[[str], None], queue_size: int
    ) -> object: ...

    def close_subscription(self, handle: object) -> None: ...

    def shutdown(self) -> None: ...


class _Ros1Backend:
    version = "ros1"

    def __init__(self, node_name: str) -> None:
        import rospy
        from std_msgs.msg import String

        self._rospy = rospy
        self._String = String
        if not rospy.core.is_initialized():
            rospy.init_node(node_name, anonymous=True, disable_signals=True)

    def make_publisher(self, topic: str, queue_size: int) -> object:
        return self._rospy.Publisher(topic, self._String, queue_size=queue_size)

    def publish(self, publisher: _RosStringPublisher, payload: str) -> None:
        publisher.publish(self._String(data=payload))

    def subscribe(
        self, topic: str, callback: Callable[[str], None], queue_size: int
    ) -> object:
        def wrapper(msg: _StdStringMsg) -> None:
            callback(msg.data)

        return self._rospy.Subscriber(
            topic, self._String, wrapper, queue_size=queue_size
        )

    def close_subscription(self, handle: object) -> None:
        try:
            cast(_Ros1SubscriptionHandle, handle).unregister()
        except Exception:
            pass

    def shutdown(self) -> None:
        try:
            if not self._rospy.core.is_shutdown():
                self._rospy.signal_shutdown("ar_voice_controller RosBus close")
        except Exception:
            pass


class _Ros2Backend:
    version = "ros2"

    def __init__(self, node_name: str) -> None:
        import rclpy
        from rclpy.executors import MultiThreadedExecutor
        from rclpy.node import Node
        from std_msgs.msg import String

        self._rclpy = rclpy
        self._String = String
        if not rclpy.ok():
            rclpy.init()
        self._node = Node(node_name)
        self._executor = MultiThreadedExecutor()
        self._executor.add_node(self._node)
        self._thread = threading.Thread(
            target=self._executor.spin, daemon=True, name="ros2-executor"
        )
        self._thread.start()

    def make_publisher(self, topic: str, queue_size: int) -> object:
        return self._node.create_publisher(self._String, topic, queue_size)

    def publish(self, publisher: _RosStringPublisher, payload: str) -> None:
        msg = self._String()
        msg.data = payload
        publisher.publish(msg)

    def subscribe(
        self, topic: str, callback: Callable[[str], None], queue_size: int
    ) -> object:
        def wrapper(msg: _StdStringMsg) -> None:
            callback(msg.data)

        return self._node.create_subscription(self._String, topic, wrapper, queue_size)

    def close_subscription(self, handle: object) -> None:
        try:
            self._node.destroy_subscription(handle)  # type: ignore[arg-type]
        except Exception:
            pass

    def shutdown(self) -> None:
        try:
            self._executor.shutdown()
        except Exception:
            pass
        try:
            self._node.destroy_node()
        except Exception:
            pass
        try:
            if self._rclpy.ok():
                self._rclpy.shutdown()
        except Exception:
            pass


def select_backend(version: RosVersion, node_name: str) -> _RosBackend:
    if version == "ros1":
        return _Ros1Backend(node_name)
    if version == "ros2":
        return _Ros2Backend(node_name)

    try:
        import rclpy  # noqa: F401

        return _Ros2Backend(node_name)
    except Exception:
        pass
    try:
        import rospy  # noqa: F401

        return _Ros1Backend(node_name)
    except Exception as exc:
        raise RuntimeError(
            "Neither rclpy (ROS 2) nor rospy (ROS 1) could be imported; "
            "install ROS Python bindings or switch runtime.bus to 'inprocess'."
        ) from exc
