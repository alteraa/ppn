from __future__ import annotations

import queue
import threading
import time
from typing import Iterator

from ..audio.utils import to_wav_bytes
from ..runtime.event_types import ErrorEvent, FinalTranscript
from ..runtime.events import EventBus
from .cancellation import CancellationError, CancellationToken
from .types import DialogPolicy, TurnContext


class AsrProcessingWorker:
    """Runs ASR + policy in a background thread.

    The main loop calls ``submit`` when a capture is complete, then calls
    ``drain_results`` each tick to consume finished items.
    """

    def __init__(
        self,
        asr_client,
        policy: DialogPolicy,
        bus: EventBus,
        *,
        channels: int,
        sample_rate: int,
    ) -> None:
        self._asr_client = asr_client
        self._policy = policy
        self._bus = bus
        self._channels = channels
        self._sample_rate = sample_rate
        self._work_queue: queue.Queue[tuple[int, list[bytes], CancellationToken]] = (
            queue.Queue()
        )
        self._result_queue: queue.Queue[tuple[str, int, object]] = queue.Queue()
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def submit(
        self, turn_id: int, audio_buffer: list[bytes], token: CancellationToken
    ) -> None:
        self._work_queue.put((turn_id, audio_buffer, token))

    def drain_results(self) -> Iterator[tuple[str, int, object]]:
        while True:
            try:
                yield self._result_queue.get_nowait()
            except queue.Empty:
                return

    def _loop(self) -> None:
        while True:
            turn_id, audio_buffer, token = self._work_queue.get()
            try:
                token.raise_if_cancelled()
                wav_bytes = to_wav_bytes(
                    audio_buffer,
                    channels=self._channels,
                    sample_rate=self._sample_rate,
                )
                sr_started_at = time.time()
                transcription = self._asr_client.transcribe(wav_bytes, token=token)
                token.raise_if_cancelled()
                sr_done_at = time.time()

                final = FinalTranscript(
                    turn_id=turn_id,
                    text=transcription.text,
                    language=transcription.language or "tr",
                    latency_ms=(sr_done_at - sr_started_at) * 1000,
                )
                self._bus.publish("/asr/final", final)

                if len(final.text) <= 2:
                    self._result_queue.put(("done", turn_id, {"spoken": False}))
                    continue

                result = self._policy.run(
                    TurnContext(turn_id=turn_id, token=token, transcript=final)
                )
                self._result_queue.put(
                    (
                        "done",
                        turn_id,
                        {
                            "spoken": result.emitted_segments > 0,
                            "text": result.full_text,
                        },
                    )
                )
            except CancellationError:
                self._result_queue.put(("cancelled", turn_id, None))
            except Exception as exc:
                self._bus.publish(
                    "/error",
                    ErrorEvent(
                        component="worker",
                        detail=str(exc),
                        recoverable=True,
                    ),
                )
                self._result_queue.put(("error", turn_id, str(exc)))
