from __future__ import annotations

import numpy as np
from aec_audio_processing import AudioProcessor

from ..config import AudioCfg


class AecProcessor:
    """Thin wrapper around AudioProcessor providing AEC + NS per-frame processing."""

    def __init__(self, config: AudioCfg) -> None:
        self._config = config
        self._processor = self._build()

    def _build(self) -> AudioProcessor:
        processor = AudioProcessor(enable_aec=True, enable_ns=True, enable_agc=False)
        processor.set_stream_format(
            self._config.sample_rate,
            self._config.channels,
            self._config.sample_rate,
            self._config.channels,
        )
        processor.set_reverse_stream_format(
            self._config.sample_rate, self._config.channels
        )
        processor.set_stream_delay(self._config.aec_delay_ms)
        return processor

    def reset(self) -> None:
        self._processor = self._build()

    def process(self, mic_chunk: np.ndarray, ref_chunk: np.ndarray) -> np.ndarray:
        out_parts: list[np.ndarray] = []
        frame_size = self._config.aec_frame_size

        for start in range(0, len(mic_chunk), frame_size):
            end = min(start + frame_size, len(mic_chunk))
            mic_frame = mic_chunk[start:end]
            ref_frame = ref_chunk[start:end]

            valid_len = len(mic_frame)
            if valid_len < frame_size:
                mic_frame = np.pad(
                    mic_frame, (0, frame_size - valid_len), constant_values=0
                )
                ref_frame = np.pad(
                    ref_frame, (0, frame_size - valid_len), constant_values=0
                )

            self._processor.process_reverse_stream(ref_frame.astype(np.int16).tobytes())
            cleaned = self._processor.process_stream(
                mic_frame.astype(np.int16).tobytes()
            )
            cleaned_arr = np.frombuffer(cleaned, dtype=np.int16).copy()
            out_parts.append(cleaned_arr[:valid_len])

        if not out_parts:
            return mic_chunk.copy()
        return np.concatenate(out_parts)
