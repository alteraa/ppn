from __future__ import annotations

import wave

import numpy as np

from ..config import Settings


def second_to_chunks(sec: float, *, sample_rate: int, num_samples: int) -> int:
    return int(sec * (sample_rate / num_samples))


def crest_factor(audio_chunk: bytes) -> float:
    arr = np.frombuffer(audio_chunk, np.int16).astype("float32")
    if len(arr) == 0:
        return 0.0
    chunk_rms = float(np.sqrt(np.mean(arr**2)))
    if chunk_rms < 1e-6:
        return 0.0
    peak = float(np.max(np.abs(arr)))
    return peak / chunk_rms


def is_speech_start(
    audio_chunk: bytes,
    *,
    baseline: float,
    vad_confidence: float,
    settings: Settings,
) -> bool:
    if vad_confidence <= settings.vad.speak_threshold:
        return False

    current_rms = rms(audio_chunk)
    rms_threshold = max(
        settings.vad.min_start_rms,
        baseline * settings.vad.start_rms_multiplier,
    )
    if current_rms <= rms_threshold:
        return False

    if crest_factor(audio_chunk) > settings.vad.max_start_crest_factor:
        return False

    return True


def rms(audio_chunk: bytes) -> float:
    arr = np.frombuffer(audio_chunk, np.int16).astype("float32")
    return float(np.sqrt(np.mean(arr**2))) if len(arr) > 0 else 0.0


def to_wav_bytes(audio: list[bytes], *, channels: int, sample_rate: int) -> bytes:
    from io import BytesIO

    buffer = BytesIO()
    with wave.open(buffer, "wb") as wf:
        wf.setnchannels(channels)
        wf.setsampwidth(2)
        wf.setframerate(sample_rate)
        wf.writeframes(b"".join(audio))
    return buffer.getvalue()


class Streamer:
    def __init__(self) -> None:
        self.audio_buffer: list[bytes] = []

    def add(self, chunk: bytes) -> None:
        self.audio_buffer.append(chunk)
