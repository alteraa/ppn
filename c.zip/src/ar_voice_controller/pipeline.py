from __future__ import annotations

from .audio import AudioIO, AudioInterruptSource, InterruptArbiter, InterruptDetector, VadDetector
from .core import StreamingLlmPolicy, TurnManager
from .providers import InMemoryHistory, OpenAiAsrClient, OpenAiLlmClient, OpenAiTtsClient, TTSPlayer
from .runtime import EventBus, InProcessBus, Settings, make_event_bus
from .telemetry.fifo_sink import FifoSink
from .telemetry.logger import TurnLogger


def _wire_face_anim(bus: EventBus, enabled: bool) -> None:
    if not enabled:
        return
    try:
        from chatbot.utils import package as pm
    except Exception:
        return

    face_pipe = pm.Pipe.chatbot("r")
    state_to_anim = {
        "idle": pm.face_anim.normal,
        "listening": pm.face_anim.static_thinking,
        "processing": pm.face_anim.static_thinking,
        "speaking": pm.face_anim.static_talking,
        "cooldown": pm.face_anim.normal,
    }
    current = {"value": None}

    def handler(topic, event) -> None:
        del topic
        anim = state_to_anim.get(event.current)
        if anim is None or current["value"] == anim:
            return
        face_pipe.writes(anim)
        current["value"] = anim

    bus.subscribe("/dialog/turn/state", handler)


class Pipeline:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.bus = make_event_bus(settings.runtime)
        self._fifo_sink: FifoSink | None = None
        if isinstance(self.bus, InProcessBus):
            self._fifo_sink = FifoSink()
            self.bus.set_spy(self._fifo_sink.write)
        self.audio_io = AudioIO(settings.audio)
        self.vad = VadDetector(settings.vad, sample_rate=settings.audio.sample_rate)
        self.asr = OpenAiAsrClient(settings.asr)
        self.llm = OpenAiLlmClient(settings.llm)
        self.history = InMemoryHistory(settings.llm.max_history)
        self.tts_player = TTSPlayer(
            self.audio_io,
            OpenAiTtsClient(settings.tts, settings.audio),
            self.bus,
        )
        detector = InterruptDetector(settings.interrupt, self.vad.confidence)
        self.audio_interrupt = AudioInterruptSource(detector)
        self.arbiter = InterruptArbiter(self.bus)
        self.policy = StreamingLlmPolicy(
            self.llm, self.tts_player, self.history, self.bus, settings
        )
        self.turn_manager = TurnManager(
            settings,
            self.audio_io,
            self.vad,
            self.asr,
            self.policy,
            self.arbiter,
            self.bus,
            self.audio_interrupt,
        )
        self.turn_logger = TurnLogger(self.bus)
        _wire_face_anim(self.bus, settings.face_anim.enabled)

    def run(self) -> None:
        self.turn_manager.run()

    def stop(self) -> None:
        self.tts_player.stop()
        self.audio_io.close()
        self.arbiter.close()
        self.bus.close()
        if self._fifo_sink is not None:
            self._fifo_sink.close()
