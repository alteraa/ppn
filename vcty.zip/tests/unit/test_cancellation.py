"""
Unit specs for the cancellation feature.

Feature under test: ``CancellationToken`` — the single cancellation primitive
used across turn orchestration, streaming LLM, and TTS playback. AGENTS.md
invariant #4 states cancellation must propagate through this token, so its
behavioral contract is expected to survive any future architecture change.

Source: ``ar_voice_controller.core.cancellation``
"""

from __future__ import annotations

import threading
import time

import pytest

from ar_voice_controller.core.cancellation import (
    CancellationError,
    CancellationToken,
    InterruptCause,
)


class TestFreshToken:
    """Feature: a newly constructed token is alive and has no cause."""

    def test_new_token_is_not_cancelled(self):
        token = CancellationToken()
        assert token.cancelled is False

    def test_new_token_has_no_cause(self):
        token = CancellationToken()
        assert token.cause is None

    def test_raise_if_cancelled_is_a_no_op_on_fresh_token(self):
        CancellationToken().raise_if_cancelled()


class TestCancel:
    """Feature: cancelling sets cancelled, records cause, and raises."""

    def test_cancel_sets_cancelled_flag(self):
        token = CancellationToken()
        token.cancel(InterruptCause.EXTERNAL_STOP)
        assert token.cancelled is True

    def test_cancel_records_the_cause(self):
        token = CancellationToken()
        token.cancel(InterruptCause.VOICE_BARGE_IN)
        assert token.cause is InterruptCause.VOICE_BARGE_IN

    def test_cancel_is_idempotent_first_cause_wins(self):
        token = CancellationToken()
        token.cancel(InterruptCause.VOICE_BARGE_IN)
        token.cancel(InterruptCause.SAFETY)
        assert token.cause is InterruptCause.VOICE_BARGE_IN

    def test_raise_if_cancelled_raises_cancellation_error(self):
        token = CancellationToken()
        token.cancel(InterruptCause.TIMEOUT)
        with pytest.raises(CancellationError) as exc_info:
            token.raise_if_cancelled()
        assert exc_info.value.cause is InterruptCause.TIMEOUT

    def test_cancellation_error_message_mentions_cause_value(self):
        err = CancellationError(InterruptCause.SHUTDOWN)
        assert InterruptCause.SHUTDOWN.value in str(err)


class TestParentChildPropagation:
    """Feature: child tokens observe parent cancellation."""

    def test_child_is_not_cancelled_when_parent_is_alive(self):
        parent = CancellationToken()
        child = parent.child()
        assert child.cancelled is False

    def test_child_becomes_cancelled_when_parent_is_cancelled(self):
        parent = CancellationToken()
        child = parent.child()
        parent.cancel(InterruptCause.CONTEXT_RESET)
        assert child.cancelled is True

    def test_child_inherits_parent_cause(self):
        parent = CancellationToken()
        child = parent.child()
        parent.cancel(InterruptCause.SAFETY)
        assert child.cause is InterruptCause.SAFETY

    def test_cancelling_child_does_not_cancel_parent(self):
        parent = CancellationToken()
        child = parent.child()
        child.cancel(InterruptCause.TIMEOUT)
        assert parent.cancelled is False

    def test_child_cause_is_preserved_even_if_parent_later_cancels(self):
        parent = CancellationToken()
        child = parent.child()
        child.cancel(InterruptCause.TIMEOUT)
        parent.cancel(InterruptCause.SHUTDOWN)
        assert child.cause is InterruptCause.TIMEOUT


class TestWait:
    """Feature: ``wait`` returns promptly when cancelled, honors timeout otherwise."""

    def test_wait_returns_true_immediately_if_already_cancelled(self):
        token = CancellationToken()
        token.cancel(InterruptCause.EXTERNAL_STOP)
        start = time.monotonic()
        result = token.wait(timeout=5.0)
        elapsed = time.monotonic() - start
        assert result is True
        assert elapsed < 0.5

    def test_wait_returns_false_on_timeout_without_cancellation(self):
        token = CancellationToken()
        assert token.wait(timeout=0.05) is False

    def test_wait_unblocks_when_cancelled_from_another_thread(self):
        token = CancellationToken()

        def _cancel_soon() -> None:
            time.sleep(0.05)
            token.cancel(InterruptCause.EXTERNAL_STOP)

        thread = threading.Thread(target=_cancel_soon, daemon=True)
        thread.start()
        try:
            assert token.wait(timeout=2.0) is True
        finally:
            thread.join(timeout=1.0)
