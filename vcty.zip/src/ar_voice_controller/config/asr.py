from __future__ import annotations

from pydantic import BaseModel


class AsrCfg(BaseModel):
    base_url: str | None = "http://127.0.0.1:8003/v1"
    api_key: str | None = None
    model: str = "whisper-1"
    timeout_sec: float = 60.0
