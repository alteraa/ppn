"""
Unit specs for ``InMemoryHistory``.

Feature under test: the in-memory message buffer used by the LLM provider.
Pure, deterministic, no model or I/O involvement. AGENTS.md notes that once
FI-6 lands the remote service will own history, so this spec locks the
current local-fallback contract: cap, FIFO eviction, snapshot isolation.

Source: ``ar_voice_controller.providers.llm.InMemoryHistory``
"""

from __future__ import annotations

import pytest

pytestmark = pytest.mark.requires_openai

pytest.importorskip("openai", reason="openai SDK not installed")

from ar_voice_controller.providers.llm import InMemoryHistory  # noqa: E402


class TestAddAndSnapshot:
    def test_new_history_is_empty(self):
        assert InMemoryHistory().snapshot() == []

    def test_added_messages_appear_in_snapshot_in_order(self):
        history = InMemoryHistory()
        history.add({"role": "user", "content": "one"})
        history.add({"role": "assistant", "content": "two"})
        assert history.snapshot() == [
            {"role": "user", "content": "one"},
            {"role": "assistant", "content": "two"},
        ]

    def test_snapshot_returns_a_copy(self):
        history = InMemoryHistory()
        history.add({"role": "user", "content": "x"})
        snapshot = history.snapshot()
        snapshot.clear()
        assert history.snapshot() == [{"role": "user", "content": "x"}]


class TestCapacity:
    def test_history_is_capped_at_max_messages(self):
        history = InMemoryHistory(max_messages=3)
        for i in range(5):
            history.add({"role": "user", "content": str(i)})
        assert len(history.snapshot()) == 3

    def test_oldest_messages_are_evicted_first(self):
        history = InMemoryHistory(max_messages=3)
        for i in range(5):
            history.add({"role": "user", "content": str(i)})
        contents = [m["content"] for m in history.snapshot()]
        assert contents == ["2", "3", "4"]


class TestClear:
    def test_clear_empties_the_history(self):
        history = InMemoryHistory()
        history.add({"role": "user", "content": "x"})
        history.clear()
        assert history.snapshot() == []
