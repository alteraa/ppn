from __future__ import annotations

import os
from typing import Protocol

import numpy as np
from openai import OpenAI

from ..core.cancellation import CancellationToken
from ..config import AudioCfg, TtsCfg


class TtsClient(Protocol):
    def synthesize(
        self,
        text: str,
        *,
        token: CancellationToken,
        language: str,
    ) -> np.ndarray | None: ...


class OpenAiTtsClient:
    def __init__(self, config: TtsCfg, audio_config: AudioCfg):
        self.config = config
        self.audio_config = audio_config
        self.client = OpenAI(
            base_url=self.config.base_url,
            api_key=self.config.api_key or os.getenv("OPENAI_API_KEY") or "not-needed",
            timeout=self.config.timeout_sec,
        )

    def _normalize_language(self, language: str) -> str:
        lang = (language or "").strip().lower()
        if lang.startswith("tr") or lang == "turkish":
            return "tr"
        if lang.startswith("en") or lang == "english":
            return "en"
        return self.config.default_language

    def _resample_to_output_rate(self, samples: np.ndarray) -> np.ndarray:
        if len(samples) == 0 or self.config.sample_rate == self.audio_config.sample_rate:
            return samples

        source_positions = np.arange(len(samples), dtype=np.float32)
        target_length = max(
            1,
            int(
                round(
                    len(samples)
                    * self.audio_config.sample_rate
                    / self.config.sample_rate
                )
            ),
        )
        target_positions = np.linspace(
            0, len(samples) - 1, num=target_length, dtype=np.float32
        )
        resampled = np.interp(
            target_positions, source_positions, samples.astype(np.float32)
        )
        return np.clip(np.round(resampled), -32768, 32767).astype(np.int16)

    def synthesize(
        self,
        text: str,
        *,
        token: CancellationToken,
        language: str,
    ) -> np.ndarray | None:
        token.raise_if_cancelled()
        normalized = self._normalize_language(language)
        voice = self.config.voice_by_language.get(
            normalized,
            self.config.voice_by_language[self.config.default_language],
        )
        response = self.client.audio.speech.create(
            model=self.config.model,
            voice=voice,
            input=text,
            response_format="pcm",
        )
        token.raise_if_cancelled()
        audio_bytes = response.read()
        if not audio_bytes:
            return None
        ref = np.frombuffer(audio_bytes, dtype=np.int16).copy()
        ref = self._resample_to_output_rate(ref)
        return ref if len(ref) > 0 else None
