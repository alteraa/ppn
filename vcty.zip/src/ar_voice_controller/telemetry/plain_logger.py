from __future__ import annotations

import sys
import threading

from .._ansi import CLEAR_LINE, CYAN, RESET

_LOG_LOCK = threading.Lock()
_STATUS_ACTIVE = False


def fmt_ms(seconds: float | None) -> str:
    if seconds is None:
        return "n/a"
    return f"{seconds * 1000:.0f} ms"


def _finish_status_locked() -> None:
    global _STATUS_ACTIVE
    if _STATUS_ACTIVE:
        sys.stderr.write("\n")
        sys.stderr.flush()
        _STATUS_ACTIVE = False


def log_plain(message: str, color: str | None = None, stream=None) -> None:
    target = stream or sys.stdout
    with _LOG_LOCK:
        _finish_status_locked()
        if color:
            target.write(f"{color}{message}{RESET}\n")
        else:
            target.write(f"{message}\n")
        target.flush()


def log_stage(stage: str, message: str, color: str = CYAN) -> None:
    log_plain(f"[{stage}] {message}", color=color)


def debug_status(message: str, color: str = CYAN) -> None:
    global _STATUS_ACTIVE
    with _LOG_LOCK:
        sys.stderr.write(f"\r{color}[DEBUG] {message}{RESET}{CLEAR_LINE}")
        sys.stderr.flush()
        _STATUS_ACTIVE = True


def finish_debug_status() -> None:
    with _LOG_LOCK:
        _finish_status_locked()
