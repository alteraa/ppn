from __future__ import annotations

import json
from dataclasses import asdict, dataclass, is_dataclass
from typing import Any


@dataclass(slots=True)
class ServiceStateChanged:
    previous: str
    current: str


@dataclass(slots=True)
class TurnStateChanged:
    turn_id: int | None
    previous: str
    current: str
    at: float


@dataclass(slots=True)
class UserSpeechDetected:
    turn_id: int | None
    at: float


@dataclass(slots=True)
class UserSpeechEnded:
    turn_id: int
    duration_ms: float


@dataclass(slots=True)
class FinalTranscript:
    turn_id: int
    text: str
    language: str
    latency_ms: float


@dataclass(slots=True)
class LlmTextDelta:
    turn_id: int
    text: str
    index: int


@dataclass(slots=True)
class AssistantSegment:
    turn_id: int
    text: str
    language: str
    index: int


@dataclass(slots=True)
class AssistantDone:
    turn_id: int
    full_text: str
    language: str


@dataclass(slots=True)
class TtsPlaybackStarted:
    turn_id: int
    at: float


@dataclass(slots=True)
class TtsPlaybackEnded:
    turn_id: int
    at: float


@dataclass(slots=True)
class TtsSegmentStarted:
    turn_id: int
    text: str
    index: int
    at: float


@dataclass(slots=True)
class TtsAudioFrame:
    turn_id: int | None
    rms: float
    frame_index: int


@dataclass(slots=True)
class InterruptRequested:
    source: str
    cause: str
    priority: int
    at: float


@dataclass(slots=True)
class InterruptHonored:
    turn_id: int | None
    cause: str
    at: float


@dataclass(slots=True)
class TurnMetrics:
    turn_id: int | None
    metrics: dict[str, float | int | None]


@dataclass(slots=True)
class ToolCallRequested:
    name: str
    arguments: dict[str, Any]


@dataclass(slots=True)
class ToolCallCompleted:
    name: str
    result: Any


@dataclass(slots=True)
class ErrorEvent:
    component: str
    detail: str
    recoverable: bool


@dataclass(slots=True)
class DroppedEvent:
    topic: str
    dropped_count: int


EVENT_TYPES: dict[str, type] = {
    cls.__name__: cls
    for cls in (
        ServiceStateChanged,
        TurnStateChanged,
        UserSpeechDetected,
        UserSpeechEnded,
        FinalTranscript,
        LlmTextDelta,
        AssistantSegment,
        AssistantDone,
        TtsPlaybackStarted,
        TtsPlaybackEnded,
        TtsSegmentStarted,
        TtsAudioFrame,
        InterruptRequested,
        InterruptHonored,
        TurnMetrics,
        ToolCallRequested,
        ToolCallCompleted,
        ErrorEvent,
        DroppedEvent,
    )
}


def encode_event(event: object) -> str:
    if is_dataclass(event) and not isinstance(event, type):
        return json.dumps(
            {"__type__": type(event).__name__, "data": asdict(event)},
            default=str,
        )
    return json.dumps({"__type__": "raw", "data": event}, default=str)


def decode_event(payload: str) -> object:
    obj = json.loads(payload)
    type_name = obj.get("__type__")
    data = obj.get("data")
    cls = EVENT_TYPES.get(type_name) if isinstance(type_name, str) else None
    if cls is None:
        return data
    try:
        return cls(**data)
    except TypeError:
        return data
