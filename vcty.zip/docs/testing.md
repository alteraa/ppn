# Testing — running specs with and without heavy deps

The unit suite lives under `tests/unit/`. Each spec targets a single feature
and stubs the model/service boundary so nothing reaches the network or
audio hardware at test time. A few specs still need a heavy library at
**import time** (not at call time). This document lists those libraries,
explains how much each one costs a CI/CD pipeline, and shows how to skip
them.

## Running the full suite

```bash
uv sync --group dev
uv run pytest tests/
```

Current status: **124 specs / ~87% branch coverage** on the covered modules.

## Heavy dependencies (test-stage install cost)

Ordered from most to least expensive to bring up in a clean CI runner.

| Package | Installed size | Extra cost | Needed by | Skip marker |
|---|---|---|---|---|
| `onnxruntime==1.23.2` | ~49 MB on disk (larger download, CPU-only) | none | `audio/vad.py` (Silero VAD runner) | `requires_onnx_model` |
| `numpy==2.4.4` | ~33 MB | none | many modules | not optional — keep installed |
| `openai==2.32.0` | ~11 MB (+ `httpx`, `anyio`, `distro`, `jiter` ≈ 10 MB) | none | all three `providers/*` API adapters | `requires_openai` |
| `aec-audio-processing==1.0.1` | ~4 MB (vendored wheel) | **CPython 3.11 only**, vendor dir required | `audio/aec.py` | `requires_audio_hw` |
| `sounddevice==0.5.5` | ~150 KB | **`apt install libportaudio2`** | `audio/io.py` | `requires_audio_hw` |
| `pydantic==2.13.3` | ~3 MB | none | `config/*` | not optional |

The big wins in CI are skipping **`onnxruntime`** (~49 MB) and the
`libportaudio2` apt install that `sounddevice` pulls in.

## Markers

Declared in `pytest.ini`:

- `requires_onnx_model` — real ONNX VAD model available on disk or
  `onnxruntime` installed.
- `requires_audio_hw` — `sounddevice` and `aec-audio-processing` available.
- `requires_openai` — `openai` SDK installed (the client itself is always
  mocked in unit tests; the import is what forces the dep).
- `slow` — long-running tests; deselect with `-m "not slow"`.
- `integration` — cross-module integration tests.

## Skip machinery

`tests/conftest.py` does two things:

1. **Collection-time module skip**: test modules whose top-level imports
   pull a heavy dep are listed in `_HARD_DEP_MODULES`. If any of their
   required packages isn't importable, pytest ignores the file during
   collection so the rest of the suite still runs.
2. **Runtime marker skip**: individual items carrying a `requires_*`
   marker are skipped with a clear reason when their dep is missing.

The effect: a developer running without `onnxruntime` installed can still
run every spec that does not depend on it.

## Fast lanes (developer)

Skip VAD specs only:

```bash
uv run pytest -m "not requires_onnx_model"
```

Skip all API-backed specs (no `openai` import):

```bash
uv run pytest -m "not requires_openai"
```

Chain markers:

```bash
uv run pytest -m "not requires_onnx_model and not requires_audio_hw"
```

## Fast lane (CI/CD)

To actually **skip installing** a heavy dep in CI, use
`uv sync`'s `--no-install-package` flag alongside the dep-lite marker
filter. Example for a GitLab job that skips `onnxruntime`:

```yaml
test:fast:
  stage: 🧪 test
  before_script:
    - pip install --upgrade uv
    - uv sync --group dev --no-install-package onnxruntime
  script:
    - uv run pytest -m "not requires_onnx_model"
```

> **Known limitation.** The package's `__init__.py` files eagerly re-export
> submodules, so importing, e.g., `ar_voice_controller.core.cancellation`
> triggers loading of `audio/io.py` (needs `sounddevice`) and `audio/vad.py`
> (needs `onnxruntime`). Until the re-exports are switched to PEP 562 lazy
> loading, the fast-lane job above still needs `onnxruntime` and
> `sounddevice` at install time for the *other* specs to collect. The
> marker-level skip still works locally when all deps are installed but
> you want to iterate without running a particular group.
>
> Tracking: move `providers/__init__.py`, `audio/__init__.py`, and
> `core/__init__.py` to `__getattr__`-based lazy exports. Small, isolated
> refactor — see ROADMAP FI-* follow-up.

## Adding a new marker

1. Declare it in `pytest.ini` under `markers`.
2. Map it to its import-time package(s) in `tests/conftest.py`'s
   `_OPTIONAL_DEPS`. If the marker corresponds to a whole test module that
   can't be collected without the dep, also add the module path to
   `_HARD_DEP_MODULES`.
3. Tag the relevant test module with `pytestmark = pytest.mark.<name>`.
4. Guard the top of the module with
   `pytest.importorskip("<pkg>", reason="...")` so a missing dep produces
   a clean skip instead of a collection error.
