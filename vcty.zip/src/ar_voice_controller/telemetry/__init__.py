"""Telemetry helpers for runtime logs and metrics."""

from __future__ import annotations

from typing import TYPE_CHECKING

from .plain_logger import (
    debug_status,
    finish_debug_status,
    fmt_ms,
    log_plain,
    log_stage,
)

if TYPE_CHECKING:
    from .turn_logger import TurnLogger

__all__ = [
    "TurnLogger",
    "debug_status",
    "finish_debug_status",
    "fmt_ms",
    "log_plain",
    "log_stage",
]


def __getattr__(name: str) -> object:
    if name == "TurnLogger":
        from .turn_logger import TurnLogger

        return TurnLogger
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
