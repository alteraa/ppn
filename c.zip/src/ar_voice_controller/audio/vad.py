from __future__ import annotations

import math
from pathlib import Path
from threading import Lock

import numpy as np
import torch

from ..config import VadCfg


class VadDetector:
    def __init__(self, config: VadCfg, *, sample_rate: int) -> None:
        self.config = config
        self.sample_rate = sample_rate
        self._model = None
        self._lock = Lock()
        torch.set_num_threads(self.config.torch_num_threads)

    def _ensure_model(self):
        if self._model is not None:
            return self._model
        with self._lock:
            if self._model is None:
                local_path = Path(self.config.model_path)
                if local_path.exists():
                    self._model, _ = torch.hub.load(
                        repo_or_dir=str(local_path),
                        source="local",
                        model="silero_vad",
                        trust_repo=True,
                    )
                else:
                    self._model, _ = torch.hub.load(
                        repo_or_dir="snakers4/silero-vad",
                        model="silero_vad",
                        trust_repo=True,
                    )
        return self._model

    @staticmethod
    def int2float(sound: bytes) -> np.ndarray:
        arr = np.frombuffer(sound, np.int16).astype("float32")
        peak = np.abs(arr).max() if len(arr) > 0 else 0
        if peak > 0:
            arr *= 1.0 / 32768.0
        return arr.squeeze()

    def confidence(self, audio_chunk: bytes) -> float:
        model = self._ensure_model()
        audio_float = self.int2float(audio_chunk)
        x = torch.from_numpy(audio_float).float()
        if x.dim() == 1:
            x = x.unsqueeze(0)

        expected = int(round((512 / 16000) * self.sample_rate))
        length = int(x.shape[-1])

        if length == expected:
            with torch.no_grad():
                return float(model(x, self.sample_rate).item())

        n = int(math.ceil(length / expected)) if expected > 0 else 0
        if n <= 0:
            return 0.0

        confidences = []
        with torch.no_grad():
            for i in range(n):
                start = i * expected
                end = min((i + 1) * expected, length)
                seg = x[..., start:end]
                if int(seg.shape[-1]) < expected:
                    pad = expected - int(seg.shape[-1])
                    seg = torch.nn.functional.pad(seg, (0, pad))
                confidences.append(float(model(seg, self.sample_rate).item()))

        if not confidences:
            return 0.0

        scores = np.array(confidences, dtype=np.float32)
        return float(max(np.mean(scores), np.percentile(scores, 75)))
