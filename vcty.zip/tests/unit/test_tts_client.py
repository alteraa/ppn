"""
Unit specs for the TTS provider feature.

Feature under test: ``OpenAiTtsClient`` — streams PCM audio from an
OpenAI-compatible speech endpoint (local ``tts-api`` or any HTTP TTS service)
and resamples each ~50 ms block to the pipeline's output rate. We mock the HTTP
boundary; the pinned contract is:
  * language normalization collapses variants to the supported set
  * resampling preserves length ratio and int16 dtype
  * voice selection uses ``voice_by_language`` with a default fallback
  * ``synthesize_stream`` yields resampled int16 chunks incrementally
  * small input is buffered until ~50 ms accumulates (minimum block size)
  * ``synthesize`` stays as a backward-compatible batch wrapper
  * empty / cancelled requests behave safely

Source: ``ar_voice_controller.providers.tts``
"""

from __future__ import annotations

import pytest

pytestmark = pytest.mark.requires_openai

pytest.importorskip("openai", reason="openai SDK not installed")

from typing import Iterable  # noqa: E402
from unittest.mock import MagicMock  # noqa: E402

import numpy as np  # noqa: E402

from ar_voice_controller.config import AudioCfg, TtsCfg  # noqa: E402
from ar_voice_controller.core.cancellation import (  # noqa: E402
    CancellationError,
    CancellationToken,
    InterruptCause,
)
from ar_voice_controller.providers.tts import OpenAiTtsClient  # noqa: E402


@pytest.fixture
def audio_config() -> AudioCfg:
    return AudioCfg(sample_rate=16000)


@pytest.fixture
def tts_config() -> TtsCfg:
    return TtsCfg(
        base_url="http://stub",
        api_key="stub-key",
        model="stub-tts",
        sample_rate=24000,
        default_language="tr",
        voice_by_language={"tr": "nova", "en": "alloy"},
    )


@pytest.fixture
def client(tts_config: TtsCfg, audio_config: AudioCfg) -> OpenAiTtsClient:
    instance = OpenAiTtsClient(tts_config, audio_config)
    instance.client = MagicMock()
    return instance


def _install_stream(client: OpenAiTtsClient, chunks: Iterable[bytes]) -> MagicMock:
    """Install a fake streaming response that yields ``chunks`` from ``iter_bytes``.

    ``chunks`` may be a generator with side effects; it is not materialized.
    """
    stream_response = MagicMock()
    stream_response.iter_bytes.return_value = iter(chunks)
    ctx = MagicMock()
    ctx.__enter__.return_value = stream_response
    ctx.__exit__.return_value = False
    client.client.audio.speech.with_streaming_response.create.return_value = ctx
    return stream_response


def _install_single_chunk(client: OpenAiTtsClient, samples: np.ndarray) -> MagicMock:
    data = samples.astype(np.int16).tobytes()
    chunks = [data] if data else []
    return _install_stream(client, chunks)


def _create_call_kwargs(client: OpenAiTtsClient) -> dict:
    return client.client.audio.speech.with_streaming_response.create.call_args.kwargs


class TestLanguageNormalization:
    """Pure feature — decoupled from any network call."""

    @pytest.mark.parametrize("value", ["tr", "TR", "tr-TR", "turkish", "Turkish"])
    def test_turkish_variants_collapse_to_tr(self, client: OpenAiTtsClient, value: str):
        assert client._normalize_language(value) == "tr"

    @pytest.mark.parametrize("value", ["en", "EN", "en-US", "english", "English"])
    def test_english_variants_collapse_to_en(self, client: OpenAiTtsClient, value: str):
        assert client._normalize_language(value) == "en"

    @pytest.mark.parametrize("value", ["", "  ", "xx", "unknown"])
    def test_unknown_language_falls_back_to_default(
        self, client: OpenAiTtsClient, value: str
    ):
        assert client._normalize_language(value) == "tr"

    def test_none_input_falls_back_to_default(self, client: OpenAiTtsClient):
        assert client._normalize_language(None) == "tr"  # type: ignore[arg-type]


class TestResampling:
    """Pure feature — no network involved."""

    def test_identity_when_rates_match(
        self, tts_config: TtsCfg, audio_config: AudioCfg
    ):
        tts_config.sample_rate = audio_config.sample_rate
        c = OpenAiTtsClient(tts_config, audio_config)
        c.client = MagicMock()
        samples = np.array([1, 2, 3, 4], dtype=np.int16)
        result = c._resample_to_output_rate(samples)
        assert np.array_equal(result, samples)

    def test_downsample_ratio_preserves_length(self, client: OpenAiTtsClient):
        # 24 kHz -> 16 kHz: expect 2/3 of the original length
        samples = np.arange(300, dtype=np.int16)
        out = client._resample_to_output_rate(samples)
        assert abs(len(out) - 200) <= 1

    def test_output_dtype_is_int16(self, client: OpenAiTtsClient):
        samples = np.arange(300, dtype=np.int16)
        out = client._resample_to_output_rate(samples)
        assert out.dtype == np.int16

    def test_empty_input_returns_empty_array(self, client: OpenAiTtsClient):
        out = client._resample_to_output_rate(np.array([], dtype=np.int16))
        assert len(out) == 0


class TestVoiceSelection:
    def test_voice_for_turkish_is_nova(self, client: OpenAiTtsClient):
        _install_single_chunk(client, np.zeros(1500, dtype=np.int16))
        client.synthesize("merhaba", token=CancellationToken(), language="tr")
        assert _create_call_kwargs(client)["voice"] == "nova"

    def test_voice_for_english_is_alloy(self, client: OpenAiTtsClient):
        _install_single_chunk(client, np.zeros(1500, dtype=np.int16))
        client.synthesize("hi", token=CancellationToken(), language="en")
        assert _create_call_kwargs(client)["voice"] == "alloy"

    def test_unknown_language_uses_default_language_voice(
        self, client: OpenAiTtsClient
    ):
        _install_single_chunk(client, np.zeros(1500, dtype=np.int16))
        client.synthesize("bonjour", token=CancellationToken(), language="fr")
        assert _create_call_kwargs(client)["voice"] == "nova"


class TestSynthesizeOutput:
    """Backward-compatible batch wrapper still returns the full resampled array."""

    def test_returns_int16_array_of_expected_length(self, client: OpenAiTtsClient):
        # 1500 samples @ 24k ≈ 62.5 ms → one block past the 50 ms accumulator.
        _install_single_chunk(client, np.arange(1500, dtype=np.int16))
        result = client.synthesize("hi", token=CancellationToken(), language="tr")
        assert result is not None
        assert result.dtype == np.int16
        assert abs(len(result) - 1000) <= 1  # 24k -> 16k downsample ratio 2/3

    def test_returns_none_when_api_returns_empty_payload(self, client: OpenAiTtsClient):
        _install_stream(client, [])
        result = client.synthesize("hi", token=CancellationToken(), language="tr")
        assert result is None

    def test_request_uses_pcm_response_format(self, client: OpenAiTtsClient):
        _install_single_chunk(client, np.zeros(1500, dtype=np.int16))
        client.synthesize("hi", token=CancellationToken(), language="tr")
        kwargs = _create_call_kwargs(client)
        assert kwargs["response_format"] == "pcm"
        assert kwargs["model"] == "stub-tts"
        assert kwargs["input"] == "hi"


class TestStreaming:
    """New feature — incremental yield and boundary handling."""

    def test_yields_multiple_chunks_when_total_exceeds_threshold(
        self, client: OpenAiTtsClient
    ):
        # MIN_BYTES @ 24kHz s16 mono ≈ 2400 bytes (1200 samples, ~50 ms).
        # Feed three 2400-byte chunks → expect three yields.
        block = np.zeros(1200, dtype=np.int16).tobytes()
        _install_stream(client, [block, block, block])
        out = list(
            client.synthesize_stream("hi", token=CancellationToken(), language="tr")
        )
        assert len(out) == 3
        for chunk in out:
            assert chunk.dtype == np.int16
            assert len(chunk) > 0

    def test_buffers_small_chunks_until_threshold(self, client: OpenAiTtsClient):
        # Six 400-byte chunks = 2400 bytes total; accumulator trips on the 6th.
        small = np.zeros(200, dtype=np.int16).tobytes()
        _install_stream(client, [small] * 6)
        out = list(
            client.synthesize_stream("hi", token=CancellationToken(), language="tr")
        )
        assert len(out) == 1
        assert len(out[0]) > 0

    def test_below_threshold_bytes_are_flushed_at_tail(self, client: OpenAiTtsClient):
        # 500 bytes total — never crosses MIN_BYTES — but must be flushed once.
        small = np.zeros(250, dtype=np.int16).tobytes()
        _install_stream(client, [small])
        out = list(
            client.synthesize_stream("hi", token=CancellationToken(), language="tr")
        )
        assert len(out) == 1
        assert len(out[0]) > 0

    def test_handles_odd_byte_boundary_without_sample_loss(
        self, client: OpenAiTtsClient
    ):
        # 2401 bytes at once: the lone trailing byte must be carried to the
        # tail flush where it is paired with a sibling byte (here: none), so
        # it is dropped silently — the preceding 2400 must still yield.
        chunk = np.zeros(1200, dtype=np.int16).tobytes() + b"\x00"
        _install_stream(client, [chunk])
        out = list(
            client.synthesize_stream("hi", token=CancellationToken(), language="tr")
        )
        assert len(out) == 1

    def test_stream_not_started_when_token_pre_cancelled(self, client: OpenAiTtsClient):
        _install_single_chunk(client, np.zeros(1500, dtype=np.int16))
        token = CancellationToken()
        token.cancel(InterruptCause.VOICE_BARGE_IN)
        gen = client.synthesize_stream("hi", token=token, language="tr")
        with pytest.raises(CancellationError):
            next(gen)
        client.client.audio.speech.with_streaming_response.create.assert_not_called()


class TestCancellation:
    def test_raises_before_api_call_when_already_cancelled(
        self, client: OpenAiTtsClient
    ):
        token = CancellationToken()
        token.cancel(InterruptCause.VOICE_BARGE_IN)
        with pytest.raises(CancellationError):
            client.synthesize("hi", token=token, language="tr")
        client.client.audio.speech.with_streaming_response.create.assert_not_called()

    def test_raises_mid_stream_when_cancelled_between_chunks(
        self, client: OpenAiTtsClient
    ):
        token = CancellationToken()
        block = np.zeros(1200, dtype=np.int16).tobytes()

        def _chunks():
            yield block
            token.cancel(InterruptCause.EXTERNAL_STOP)
            yield block

        _install_stream(client, _chunks())
        with pytest.raises(CancellationError):
            list(client.synthesize_stream("hi", token=token, language="tr"))
