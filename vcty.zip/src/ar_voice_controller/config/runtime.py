from __future__ import annotations

from typing import Literal

from pydantic import BaseModel


class RuntimeCfg(BaseModel):
    log_format: Literal["pretty", "json"] = "pretty"
    slow_subscriber_queue_size: int = 256
    bus: Literal["inprocess", "ros"] = "inprocess"
    ros_version: Literal["auto", "ros1", "ros2"] = "auto"
    ros_node_name: str = "ar_voice_controller"
    ros_namespace: str = "/ar_voice_controller"
