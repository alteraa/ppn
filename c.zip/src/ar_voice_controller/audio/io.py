from __future__ import annotations

import queue
import sys
import threading
import time
from collections import deque
from dataclasses import dataclass

import numpy as np
import sounddevice as sd

from ..config import AudioCfg
from .aec import AecProcessor


class AudioIO:
    def __init__(self, config: AudioCfg):
        self.config = config
        self._input_queue: queue.Queue[bytes] = queue.Queue(
            maxsize=self.config.input_queue_max_chunks
        )
        self._playback_lock = threading.Lock()
        self._playback_segments: deque[_PlaybackSegment] = deque()
        self._playback_cursor = 0
        self._playback_active = False
        self._started_segments: queue.SimpleQueue[tuple[int, float]] = queue.SimpleQueue()
        self._status_log_count = 0
        self._aec = AecProcessor(config)
        self._stream = sd.Stream(
            samplerate=self.config.sample_rate,
            blocksize=self.config.num_samples,
            dtype="int16",
            channels=self.config.channels,
            callback=self._callback,
            latency=self.config.stream_latency,
        )
        self._stream.start()

    def _queue_input_chunk(self, chunk: bytes) -> None:
        try:
            self._input_queue.put_nowait(chunk)
        except queue.Full:
            try:
                self._input_queue.get_nowait()
            except queue.Empty:
                pass
            try:
                self._input_queue.put_nowait(chunk)
            except queue.Full:
                pass

    def _consume_playback(self, frames: int) -> np.ndarray:
        started_markers: list[tuple[int, float]] = []
        with self._playback_lock:
            if not self._playback_active or not self._playback_segments:
                return np.zeros(frames, dtype=np.int16)

            out = np.zeros(frames, dtype=np.int16)
            written = 0

            while written < frames and self._playback_segments:
                current = self._playback_segments[0]
                if not current.started:
                    current.started = True
                    current.started_at = time.time()
                    if current.segment_id is not None:
                        started_markers.append((current.segment_id, current.started_at))
                available = len(current.samples) - self._playback_cursor
                take = min(frames - written, available)
                out[written : written + take] = current.samples[
                    self._playback_cursor : self._playback_cursor + take
                ]
                written += take
                self._playback_cursor += take

                if self._playback_cursor >= len(current.samples):
                    self._playback_segments.popleft()
                    self._playback_cursor = 0

            if not self._playback_segments:
                self._playback_active = False

        for marker in started_markers:
            self._started_segments.put(marker)
        return out

    def _callback(self, indata, outdata, frames, time_info, status) -> None:
        del time_info
        playback = self._consume_playback(frames)
        outdata[:, 0] = playback

        if status:
            is_startup_output_underflow = bool(
                getattr(status, "output_underflow", False) and not self.is_playing
            )
            if (
                not is_startup_output_underflow
                and self._status_log_count < self.config.max_status_logs
            ):
                self._status_log_count += 1
                print(
                    f"ERROR audio callback status: {status}",
                    file=sys.stderr,
                    flush=True,
                )

        mic = np.ascontiguousarray(indata[:, 0].copy(), dtype=np.int16)
        try:
            cleaned = self._aec.process(mic, playback)
        except Exception as exc:
            print(f"ERROR audio processing: {exc}", file=sys.stderr, flush=True)
            cleaned = np.zeros_like(mic)

        self._queue_input_chunk(cleaned.astype(np.int16).tobytes())

    def read_chunk(self, timeout: float | None = None) -> bytes:
        return self._input_queue.get(timeout=timeout)

    def clear_input_queue(self) -> None:
        while True:
            try:
                self._input_queue.get_nowait()
            except queue.Empty:
                break

    def start_playback(self, samples: np.ndarray) -> None:
        normalized = np.ascontiguousarray(samples.astype(np.int16))
        with self._playback_lock:
            self._playback_segments.clear()
            if len(normalized) > 0:
                self._playback_segments.append(_PlaybackSegment(samples=normalized))
            self._playback_cursor = 0
            self._playback_active = len(normalized) > 0
        self.clear_input_queue()
        self._aec.reset()

    def enqueue_playback(self, samples: np.ndarray, *, segment_id: int | None = None) -> None:
        normalized = np.ascontiguousarray(samples.astype(np.int16))
        if len(normalized) == 0:
            return

        should_reset = False
        with self._playback_lock:
            was_idle = not self._playback_active or not self._playback_segments
            if was_idle:
                self._playback_segments.clear()
                self._playback_cursor = 0
                should_reset = True
            self._playback_segments.append(
                _PlaybackSegment(samples=normalized, segment_id=segment_id)
            )
            self._playback_active = True

        if should_reset:
            self.clear_input_queue()
            self._aec.reset()

    def stop_playback(self) -> None:
        with self._playback_lock:
            self._playback_active = False
            self._playback_segments.clear()
            self._playback_cursor = 0
        self.clear_input_queue()
        self._aec.reset()

    @property
    def is_playing(self) -> bool:
        with self._playback_lock:
            return self._playback_active

    def close(self) -> None:
        self.stop_playback()
        self._stream.stop()
        self._stream.close()

    def poll_started_segment(self) -> tuple[int, float] | None:
        try:
            return self._started_segments.get_nowait()
        except queue.Empty:
            return None


@dataclass
class _PlaybackSegment:
    samples: np.ndarray
    segment_id: int | None = None
    started: bool = False
    started_at: float = 0.0
