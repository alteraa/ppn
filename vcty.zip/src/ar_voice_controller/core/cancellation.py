from __future__ import annotations

from contextlib import AbstractContextManager
from enum import Enum
from threading import Event, Lock


class InterruptCause(str, Enum):
    VOICE_BARGE_IN = "voice_barge_in"
    EXTERNAL_STOP = "external_stop"
    SAFETY = "safety"
    TIMEOUT = "timeout"
    CONTEXT_RESET = "context_reset"
    SHUTDOWN = "shutdown"


class CancellationError(RuntimeError):
    def __init__(self, cause: InterruptCause):
        super().__init__(f"operation cancelled: {cause.value}")
        self.cause = cause


class CancellationToken:
    def __init__(self, parent: CancellationToken | None = None) -> None:
        self._event = Event()
        self._lock = Lock()
        self._cause: InterruptCause | None = None
        self._parent = parent

    @property
    def cancelled(self) -> bool:
        if self._event.is_set():
            return True
        if self._parent and self._parent.cancelled:
            self.cancel(self._parent.cause or InterruptCause.SHUTDOWN)
            return True
        return False

    @property
    def cause(self) -> InterruptCause | None:
        if self._cause is not None:
            return self._cause
        if self._parent and self._parent.cancelled:
            return self._parent.cause
        return None

    def cancel(self, cause: InterruptCause) -> None:
        with self._lock:
            if self._event.is_set():
                return
            self._cause = cause
            self._event.set()

    def wait(self, timeout: float | None = None) -> bool:
        if self.cancelled:
            return True
        if self._event.wait(timeout):
            return True
        return self.cancelled

    def raise_if_cancelled(self) -> None:
        if self.cancelled:
            raise CancellationError(self.cause or InterruptCause.SHUTDOWN)

    def child(self) -> CancellationToken:
        return CancellationToken(parent=self)


class CancelScope(AbstractContextManager["CancelScope"]):
    def __init__(self, token: CancellationToken):
        self.token = token

    def __enter__(self) -> CancelScope:
        return self

    def __exit__(self, exc_type, exc_value, traceback) -> bool:
        return False
